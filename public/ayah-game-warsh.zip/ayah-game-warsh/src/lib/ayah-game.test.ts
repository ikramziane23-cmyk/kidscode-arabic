import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { buildQuestion, isSurahData, normalizeArabic, questionCount, ratingFor, shuffle, type Surah } from "./ayah-game";

const surahs = JSON.parse(readFileSync("public/data/warsh-ayat.json", "utf8")) as Surah[];

// مولّد عشوائي ثابت كي تكون الاختبارات قابلة للتكرار
function seeded(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 2 ** 32;
  };
}

describe("بيانات مصحف ورش", () => {
  it("تحتوي 114 سورة و6214 آية متسلسلة وبلا أرقام مدمجة", () => {
    expect(isSurahData(surahs)).toBe(true);
    expect(surahs.reduce((sum, s) => sum + s.ayat.length, 0)).toBe(6214);
    for (const s of surahs) {
      expect(s.pages).toHaveLength(s.ayat.length);
      for (const a of s.ayat) expect(a).not.toMatch(/[٠-٩0-9]/);
    }
  });

  it("الفاتحة 7 آيات والبقرة 285 (عدّ ورش) والكوثر 3", () => {
    expect(surahs[0]!.ayat).toHaveLength(7);
    expect(surahs[1]!.ayat).toHaveLength(285);
    expect(surahs[107]!.ayat).toHaveLength(3);
  });
});

describe("بناء الأسئلة", () => {
  it("لكل خطوة في كل سورة: 3 خيارات مختلفة والجواب هو الآية التالية فعلًا", () => {
    const rng = seeded(42);
    let count = 0;
    surahs.forEach((s, si) => {
      for (let step = 0; step < questionCount(s); step++) {
        const q = buildQuestion(surahs, si, step, rng);
        count++;
        expect(q.given).toBe(s.ayat[step]);
        expect(q.options).toHaveLength(3);
        expect(new Set(q.options).size).toBe(3);
        expect(q.options[q.answer]).toBe(s.ayat[step + 1]);
        expect(q.options.filter((o) => o === s.ayat[step + 1])).toHaveLength(1);
        expect(s.ayat[step + 1]!.startsWith(q.hintWord)).toBe(true);
      }
    });
    expect(count).toBe(6214 - 114);
  });

  it("السور القصيرة (3 آيات) تكمل الخيارات من السور المجاورة", () => {
    const kawthar = 107;
    for (let step = 0; step < 2; step++) {
      const q = buildQuestion(surahs, kawthar, step, seeded(step + 1));
      expect(new Set(q.options).size).toBe(3);
    }
  });

  it("يرفض خطوة خارج النطاق", () => {
    expect(() => buildQuestion(surahs, 107, 2)).toThrow(RangeError);
    expect(() => buildQuestion(surahs, 200, 0)).toThrow(RangeError);
  });

  it("الآيات المكررة (الرحمن) لا تُنتج جوابين صحيحين", () => {
    const rahman = 54;
    const rng = seeded(7);
    for (let step = 0; step < questionCount(surahs[rahman]!); step++) {
      const q = buildQuestion(surahs, rahman, step, rng);
      const correct = surahs[rahman]!.ayat[step + 1]!;
      expect(q.options.filter((o) => o === correct)).toHaveLength(1);
    }
  });
});

describe("أدوات مساعدة", () => {
  it("shuffle يحافظ على العناصر", () => {
    expect(shuffle([1, 2, 3, 4, 5], seeded(1)).sort()).toEqual([1, 2, 3, 4, 5]);
  });

  it("normalizeArabic يوحّد الألف ويزيل التشكيل", () => {
    expect(normalizeArabic("الإسراء")).toBe(normalizeArabic("الاسراء"));
    expect(normalizeArabic("البَقَرَة")).toBe(normalizeArabic("البقره"));
  });

  it("ratingFor يعطي تقديرًا حسب النسبة", () => {
    expect(ratingFor(10, 10).emoji).toBe("🌟");
    expect(ratingFor(0, 10).emoji).toBe("💪");
  });
});
