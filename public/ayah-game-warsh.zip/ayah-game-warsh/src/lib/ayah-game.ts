// منطق لعبة «أكمل الآية التي بعدها» — برواية ورش عن نافع.
// البيانات: public/data/warsh-ayat.json (مبنية من ملف مجمّع الملك فهد KFGQPC warshData_v10).

export type Surah = {
  n: number;
  name: string;
  /** نص كل آية (بدون رقم الآية)، الفهرس 0 = الآية 1 */
  ayat: string[];
  /** رقم صفحة المصحف المطبوع لكل آية */
  pages: number[];
};

export type Question = {
  /** الآية المعروضة */
  given: string;
  /** ثلاثة خيارات مختلفة النص */
  options: string[];
  /** فهرس الخيار الصحيح داخل options */
  answer: number;
  /** أول كلمة من الجواب (للتلميح) */
  hintWord: string;
};

export const DATA_URL = "/data/warsh-ayat.json";
export const TOTAL_SURAHS = 114;

export function isSurahData(value: unknown): value is Surah[] {
  return (
    Array.isArray(value) &&
    value.length === TOTAL_SURAHS &&
    value.every(
      (s, i) =>
        s &&
        s.n === i + 1 &&
        typeof s.name === "string" &&
        Array.isArray(s.ayat) &&
        s.ayat.length >= 2 &&
        s.ayat.every((a: unknown) => typeof a === "string" && a.length > 0),
    )
  );
}

let cache: Promise<Surah[]> | null = null;

/** يحمّل بيانات السور مرة واحدة ويحتفظ بها؛ عند الفشل يمكن إعادة المحاولة. */
export function loadSurahs(): Promise<Surah[]> {
  if (!cache) {
    cache = fetch(DATA_URL)
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.json() as Promise<unknown>;
      })
      .then((data) => {
        if (!isSurahData(data)) throw new Error("بيانات المصحف غير صالحة");
        return data;
      })
      .catch((error) => {
        cache = null;
        throw error;
      });
  }
  return cache;
}

/** عدد الأسئلة في السورة: سؤال لكل انتقال من آية إلى التي بعدها. */
export function questionCount(surah: Surah): number {
  return surah.ayat.length - 1;
}

export function shuffle<T>(items: readonly T[], rng: () => number = Math.random): T[] {
  const out = [...items];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j]!, out[i]!];
  }
  return out;
}

/**
 * يبني سؤال «ما الآية التي بعد هذه؟» للخطوة step (0-based) من السورة surahs[surahIndex].
 * المشتتات تُؤخذ من نفس السورة، وإن لم تكفِ (سور قصيرة) فمن السور المجاورة.
 * لا يتكرر نص الجواب الصحيح بين الخيارات أبدًا (بعض الآيات تتكرر في السورة نفسها).
 */
export function buildQuestion(
  surahs: Surah[],
  surahIndex: number,
  step: number,
  rng: () => number = Math.random,
): Question {
  const surah = surahs[surahIndex];
  if (!surah) throw new RangeError(`surahIndex ${surahIndex} خارج النطاق`);
  if (step < 0 || step >= questionCount(surah)) throw new RangeError(`step ${step} خارج النطاق`);

  const given = surah.ayat[step]!;
  const correct = surah.ayat[step + 1]!;

  const taken = new Set<string>([correct]);
  const pool: string[] = [];
  const addToPool = (text: string) => {
    if (taken.has(text)) return;
    taken.add(text);
    pool.push(text);
  };

  surah.ayat.forEach((text, i) => {
    if (i !== step && i !== step + 1) addToPool(text);
  });

  for (let d = 1; pool.length < 6 && d < surahs.length; d++) {
    for (const idx of [surahIndex + d, surahIndex - d]) {
      surahs[idx]?.ayat.forEach(addToPool);
    }
  }

  // نفضّل الآيات القريبة في الطول من الجواب كي لا يُعرف الجواب من الطول فقط
  const ranked = pool
    .map((text) => ({ text, score: Math.abs(text.length - correct.length) + rng() * 12 }))
    .sort((a, b) => a.score - b.score)
    .slice(0, 2)
    .map((x) => x.text);

  const options = shuffle([correct, ...ranked], rng);
  return {
    given,
    options,
    answer: options.indexOf(correct),
    hintWord: correct.split(/\s+/)[0] ?? "",
  };
}

export function ratingFor(stars: number, total: number): { emoji: string; text: string } {
  const ratio = total === 0 ? 1 : stars / total;
  if (ratio >= 0.9) return { emoji: "🌟", text: "ممتاز! حفظٌ متقن" };
  if (ratio >= 0.7) return { emoji: "👏", text: "أحسنت! أنت على الطريق الصحيح" };
  if (ratio >= 0.4) return { emoji: "👍", text: "جيد! أعد السورة لتتقنها أكثر" };
  return { emoji: "💪", text: "لا بأس! التكرار سرّ الحفظ، حاول مرة أخرى" };
}

/** إزالة التشكيل وتوحيد الألف لتسهيل البحث في أسماء السور. */
export function normalizeArabic(text: string): string {
  return text
    .replace(/[ً-ٰٟۖ-ۭـ]/g, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .trim();
}

// ---------- حفظ التقدّم محليًا (localStorage اختياري؛ تفشل القراءة/الكتابة بهدوء) ----------

export type Progress = { step: number; stars: number };
const PROGRESS_KEY = (n: number) => `ayah-game:v1:progress:${n}`;
const DONE_KEY = "ayah-game:v1:done";

function storage(): Storage | null {
  try {
    return typeof window === "undefined" ? null : window.localStorage;
  } catch {
    return null;
  }
}

export function loadProgress(n: number, total: number): Progress | null {
  try {
    const raw = storage()?.getItem(PROGRESS_KEY(n));
    if (!raw) return null;
    const p = JSON.parse(raw) as Partial<Progress>;
    if (
      Number.isInteger(p.step) &&
      Number.isInteger(p.stars) &&
      p.step! > 0 &&
      p.step! < total &&
      p.stars! >= 0 &&
      p.stars! <= p.step!
    ) {
      return { step: p.step!, stars: p.stars! };
    }
  } catch {
    /* تجاهل */
  }
  return null;
}

export function saveProgress(n: number, p: Progress): void {
  try {
    storage()?.setItem(PROGRESS_KEY(n), JSON.stringify(p));
  } catch {
    /* تجاهل */
  }
}

export function clearProgress(n: number): void {
  try {
    storage()?.removeItem(PROGRESS_KEY(n));
  } catch {
    /* تجاهل */
  }
}

export function loadDone(): number[] {
  try {
    const raw = storage()?.getItem(DONE_KEY);
    const list = raw ? (JSON.parse(raw) as unknown) : [];
    return Array.isArray(list) ? list.filter((x): x is number => Number.isInteger(x)) : [];
  } catch {
    return [];
  }
}

export function markDone(n: number): void {
  try {
    const done = new Set(loadDone());
    done.add(n);
    storage()?.setItem(DONE_KEY, JSON.stringify([...done].sort((a, b) => a - b)));
  } catch {
    /* تجاهل */
  }
}
