// أصوات اللعبة: نغمات قصيرة بـ WebAudio + تصفيق احتفالي من ملف الموقع.
// كل الدوال آمنة: إن لم يدعم المتصفح الصوت أو مُنع التشغيل فلا يحدث خطأ.

const APPLAUSE_URL = "/pwlpl-applause-sound-effect-521104.mp3";

let ctx: AudioContext | null = null;
let applause: HTMLAudioElement | null = null;

function audioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  try {
    const Ctor: typeof AudioContext | undefined =
      window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    ctx ??= new Ctor();
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

function tone(freq: number, delay: number, duration: number, type: OscillatorType = "sine", peak = 0.16) {
  const ac = audioContext();
  if (!ac) return;
  try {
    const t0 = ac.currentTime + delay;
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(peak, t0 + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
    osc.connect(gain).connect(ac.destination);
    osc.start(t0);
    osc.stop(t0 + duration + 0.05);
  } catch {
    /* تجاهل */
  }
}

/** إجابة صحيحة: نغمتان صاعدتان */
export function playCorrect() {
  tone(660, 0, 0.18);
  tone(990, 0.12, 0.28);
}

/** إجابة خاطئة: نغمة هادئة منخفضة (لطيفة على الأطفال) */
export function playWrong() {
  tone(260, 0, 0.22, "triangle", 0.12);
  tone(196, 0.14, 0.3, "triangle", 0.12);
}

/** إتمام السورة: تصفيق + فانفير */
export function playCelebration() {
  const notes = [523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5, 1318.5];
  notes.forEach((f, i) => tone(f, i * 0.14, 0.32, "triangle", 0.18));
  tone(1568, notes.length * 0.14, 0.9, "sine", 0.14);
  if (typeof window === "undefined") return;
  try {
    stopCelebration();
    applause = new Audio(APPLAUSE_URL);
    applause.volume = 0.85;
    void applause.play().catch(() => {});
  } catch {
    /* تجاهل */
  }
}

export function stopCelebration() {
  try {
    if (applause) {
      applause.pause();
      applause = null;
    }
  } catch {
    /* تجاهل */
  }
}
