// بناء المجسّمات: تُجمع مثلثات ملوّنة (لون الرأس + توهّج + تمايل + uv) في مصفوفة واحدة ثم تُرفع إلى GPU.
import { mat4, mul, mT, mRY, mRX, mRZ, mS, xform } from './math.js';

function boxPrim() {
  const p = [], n = [], uv = [], idx = [];
  const faces = [[0, 0, 1, [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]], [0, 0, -1, [1, -1, -1], [-1, -1, -1], [-1, 1, -1], [1, 1, -1]],
    [1, 0, 0, [1, -1, 1], [1, -1, -1], [1, 1, -1], [1, 1, 1]], [-1, 0, 0, [-1, -1, -1], [-1, -1, 1], [-1, 1, 1], [-1, 1, -1]],
    [0, 1, 0, [-1, 1, 1], [1, 1, 1], [1, 1, -1], [-1, 1, -1]], [0, -1, 0, [-1, -1, -1], [1, -1, -1], [1, -1, 1], [-1, -1, 1]]];
  faces.forEach((f, fi) => {
    for (let k = 3; k < 7; k++) { p.push(f[k][0] / 2, f[k][1] / 2, f[k][2] / 2); n.push(f[0], f[1], f[2]); }
    uv.push(0, 0, 1, 0, 1, 1, 0, 1); const b = fi * 4; idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
  });
  return { p, n, uv, idx };
}
function cylPrim(seg, rTop, rBot, caps = true) {
  const p = [], n = [], uv = [], idx = [];
  const slope = (rBot - rTop); const ny = slope, nl = Math.hypot(1, ny) || 1;
  for (let i = 0; i <= seg; i++) {
    const a = i / seg * Math.PI * 2, c = Math.cos(a), s = Math.sin(a);
    p.push(c * rTop, .5, s * rTop, c * rBot, -.5, s * rBot);
    n.push(c / nl, ny / nl, s / nl, c / nl, ny / nl, s / nl); uv.push(.5, .5, .5, .5);
  }
  for (let i = 0; i < seg; i++) { const a = i * 2; idx.push(a, a + 1, a + 3, a, a + 3, a + 2); }
  if (caps) for (const [y, r, ny2] of [[.5, rTop, 1], [-.5, rBot, -1]]) {
    if (r <= 0) continue; const base = p.length / 3; p.push(0, y, 0); n.push(0, ny2, 0); uv.push(.5, .5);
    for (let i = 0; i <= seg; i++) { const a = i / seg * Math.PI * 2; p.push(Math.cos(a) * r, y, Math.sin(a) * r); n.push(0, ny2, 0); uv.push(.5, .5); }
    for (let i = 0; i < seg; i++) ny2 > 0 ? idx.push(base, base + 2 + i, base + 1 + i) : idx.push(base, base + 1 + i, base + 2 + i);
  }
  return { p, n, uv, idx };
}
function spherePrim(seg, rings) {
  const p = [], n = [], uv = [], idx = [];
  for (let y = 0; y <= rings; y++) { const v = y / rings, th = v * Math.PI; for (let x = 0; x <= seg; x++) { const a = x / seg * Math.PI * 2; const nx = Math.cos(a) * Math.sin(th), ny = Math.cos(th), nz = Math.sin(a) * Math.sin(th); p.push(nx * .5, ny * .5, nz * .5); n.push(nx, ny, nz); uv.push(.5, .5); } }
  for (let y = 0; y < rings; y++) for (let x = 0; x < seg; x++) { const a = y * (seg + 1) + x, b = a + seg + 1; idx.push(a, b, a + 1, a + 1, b, b + 1); }
  return { p, n, uv, idx };
}
const PRIMS = { box: boxPrim(), sph: spherePrim(8, 6), sphLow: spherePrim(6, 4), sphHi: spherePrim(16, 12) };
const cylCache = {};
function cyl(seg, rt, rb) { const k = seg + '_' + rt + '_' + rb; return cylCache[k] || (cylCache[k] = cylPrim(seg, rt, rb)); }

export class Geo {
  constructor() { this.v = []; this.idx = []; this.n = 0; this.min = [1e9, 1e9, 1e9]; this.max = [-1e9, -1e9, -1e9]; this.rand = 1; }
  _r() { this.rand = (this.rand * 16807) % 2147483647; return this.rand / 2147483647; }
  /** يضيف مجسّمًا أوليًا بعد تحويله بمصفوفة M. color=[r,g,b], o: {e توهج, jit تباين لوني, sway, uvMode} */
  add(prim, M, color, o = {}) {
    const e = o.e || 0, jit = o.jit === undefined ? .08 : o.jit, sw = o.sway || 0, j = 1 + (this._r() - .5) * 2 * jit;
    const base = this.n, pn = prim.p.length / 3;
    const len = Math.hypot(M[0], M[1], M[2]) || 1, len2 = Math.hypot(M[4], M[5], M[6]) || 1, len3 = Math.hypot(M[8], M[9], M[10]) || 1;
    for (let i = 0; i < pn; i++) {
      const lx = prim.p[i * 3], ly = prim.p[i * 3 + 1], lz = prim.p[i * 3 + 2];
      const w = xform(M, lx, ly, lz);
      const nx = prim.n[i * 3], ny = prim.n[i * 3 + 1], nz = prim.n[i * 3 + 2];
      let tx = M[0] / len * nx + M[4] / len2 * ny + M[8] / len3 * nz, ty = M[1] / len * nx + M[5] / len2 * ny + M[9] / len3 * nz, tz = M[2] / len * nx + M[6] / len2 * ny + M[10] / len3 * nz;
      const tl = Math.hypot(tx, ty, tz) || 1; tx /= tl; ty /= tl; tz /= tl;
      const shade = o.grad ? 1 + (ly) * o.grad : 1;     // تدرّج لوني رأسي داخل المجسم
      this.v.push(w[0], w[1], w[2], tx, ty, tz, Math.min(1, color[0] * j * shade), Math.min(1, color[1] * j * shade), Math.min(1, color[2] * j * shade), e, sw ? Math.max(0, ly + .5) * sw : 0, o.soft ? 2 : prim.uv[i * 2], o.soft ? 2 : prim.uv[i * 2 + 1]);
      for (let k = 0; k < 3; k++) { if (w[k] < this.min[k]) this.min[k] = w[k]; if (w[k] > this.max[k]) this.max[k] = w[k]; }
    }
    for (const i of prim.idx) this.idx.push(base + i);
    this.n += pn; return this;
  }
  box(cx, cy, cz, sx, sy, sz, color, o = {}) { return this.add(PRIMS.box, mul(mT(cx, cy, cz), mRY(o.ry || 0), mRX(o.rx || 0), mRZ(o.rz || 0), mS(sx, sy, sz)), color, o); }
  /** أسطوانة/مخروط: نصف قطر علوي وسفلي وارتفاع، المركز في منتصف الارتفاع */
  cyl(cx, cy, cz, rt, rb, h, color, o = {}) { const seg = o.seg || 7, m = Math.max(rt, rb, 1e-4); return this.add(cyl(seg, rt / m, rb / m), mul(mT(cx, cy, cz), mRY(o.ry || 0), mRX(o.rx || 0), mRZ(o.rz || 0), mS(m, h, m)), color, o); }
  cone(cx, cy, cz, r, h, color, o = {}) { const seg = o.seg || 7; return this.add(cyl(seg, 0, 1), mul(mT(cx, cy, cz), mRY(o.ry || 0), mRX(o.rx || 0), mRZ(o.rz || 0), mS(r, h, r)), color, o); }
  sph(cx, cy, cz, rx, ry, rz, color, o = {}) { return this.add(o.low ? PRIMS.sphLow : o.hi ? PRIMS.sphHi : PRIMS.sph, mul(mT(cx, cy, cz), mRY(o.ry || 0), mRX(o.rx || 0), mRZ(o.rz || 0), mS(rx * 2, ry * 2, rz * 2)), color, o); }
  /** شبكة مسطحة أفقية مقسّمة (ماء) */
  grid(x0, z0, w, d, nx, nz, y, color = [1, 1, 1]) {
    const base = this.n;
    for (let j = 0; j <= nz; j++) for (let i = 0; i <= nx; i++) {
      const x = x0 + w * i / nx, z = z0 + d * j / nz; this.v.push(x, y, z, 0, 1, 0, color[0], color[1], color[2], 0, 0, i / nx, j / nz);
      if (x < this.min[0]) this.min[0] = x; if (x > this.max[0]) this.max[0] = x; if (z < this.min[2]) this.min[2] = z; if (z > this.max[2]) this.max[2] = z;
    }
    this.min[1] = Math.min(this.min[1], y - 1); this.max[1] = Math.max(this.max[1], y + 1);
    for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) { const a = base + j * (nx + 1) + i, b = a + nx + 1; this.idx.push(a, b, a + 1, a + 1, b, b + 1); }
    this.n += (nx + 1) * (nz + 1); return this;
  }
  /** سطح ارتفاعات (تضاريس) بألوان حسب دالة */
  terrain(x0, z0, w, d, nx, nz, hf, colf) {
    const base = this.n, dx = w / nx, dz = d / nz;
    for (let j = 0; j <= nz; j++) for (let i = 0; i <= nx; i++) {
      const x = x0 + dx * i, z = z0 + dz * j, y = hf(x, z);
      const hl = hf(x - dx, z), hr = hf(x + dx, z), hd = hf(x, z - dz), hu = hf(x, z + dz);
      let nxv = hl - hr, nyv = 2 * dx, nzv = hd - hu; const l = Math.hypot(nxv, nyv, nzv); nxv /= l; nyv /= l; nzv /= l;
      const c = colf(x, y, z, nyv); this.v.push(x, y, z, nxv, nyv, nzv, c[0], c[1], c[2], c[3] || 0, 0, .5, .5);
      for (let k = 0; k < 3; k++) { const q = [x, y, z][k]; if (q < this.min[k]) this.min[k] = q; if (q > this.max[k]) this.max[k] = q; }
    }
    for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) { const a = base + j * (nx + 1) + i, b = a + nx + 1; this.idx.push(a, b, a + 1, a + 1, b, b + 1); }
    this.n += (nx + 1) * (nz + 1); return this;
  }
  bounds() { const c = [(this.min[0] + this.max[0]) / 2, (this.min[1] + this.max[1]) / 2, (this.min[2] + this.max[2]) / 2]; return { c, r: Math.hypot(this.max[0] - this.min[0], this.max[1] - this.min[1], this.max[2] - this.min[2]) / 2 }; }
  get empty() { return this.n === 0; }
}
export { PRIMS };
