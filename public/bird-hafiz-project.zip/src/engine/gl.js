// المحرّك: WebGL2 — برامج التظليل، الشبكات، الجسيمات، الماء، السماء، الأضواء.
import { mat4, perspective, lookAt, multiply, frustumPlanes, sphereVisible, identity } from './math.js';

const STRIDE = 13 * 4;
const LIT_VS = `#version 300 es
layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNrm; layout(location=2) in vec3 aCol; layout(location=3) in float aEmi; layout(location=4) in float aSway; layout(location=5) in vec2 aUV;
uniform mat4 uVP, uModel; uniform float uTime; uniform vec3 uCam;
out vec3 vCol; out vec3 vN; out vec3 vW; out float vEmi; out float vDist;
void main(){
  vec4 w = uModel*vec4(aPos,1.);
  float s = aSway;
  if(s>0.){ w.x += sin(uTime*1.3+w.x*.6+w.z*.4)*s*.07 + sin(uTime*2.7+w.z*1.1)*s*.025; w.z += cos(uTime*1.1+w.z*.5+w.x*.3)*s*.06; }
  vW = w.xyz; vN = normalize(mat3(uModel)*aNrm); vCol = aCol; vEmi = aEmi; vDist = length(w.xyz-uCam);
  gl_Position = uVP*w;
}`;
const LIT_FS = `#version 300 es
precision highp float;
in vec3 vCol; in vec3 vN; in vec3 vW; in float vEmi; in float vDist;
uniform vec3 uSunDir, uSunCol, uAmbSky, uAmbGnd, uFogCol; uniform float uFog, uTime; uniform vec4 uPL[8]; uniform vec3 uPC[8]; uniform int uNL; uniform float uTint;
out vec4 o;
float h(vec3 p){ return fract(sin(dot(p,vec3(12.9898,78.233,37.719)))*43758.5453); }
void main(){
  vec3 n = normalize(vN);
  float hemi = n.y*.5+.5;
  vec3 amb = mix(uAmbGnd,uAmbSky,hemi);
  float nd = max(dot(n,-uSunDir),0.);
  vec3 lit = amb + uSunCol*nd;
  for(int i=0;i<8;i++){ if(i>=uNL) break; vec3 d = uPL[i].xyz-vW; float dist=length(d); float r=uPL[i].w; float a = clamp(1.-dist/r,0.,1.); a*=a; float nl = max(dot(n,d/max(dist,.001)),0.)*.7+.3; lit += uPC[i]*a*nl; }
  float g = (h(floor(vW*6.))-.5)*.07;
  vec3 c = vCol*(lit+g);
  c += vCol*vEmi*1.6 + (vEmi>.5? vCol*.3:vec3(0.));
  float f = 1.-exp(-uFog*uFog*vDist*vDist);
  c = mix(c,uFogCol,clamp(f,0.,1.));
  o = vec4(c,1.);
}`;
const WATER_VS = `#version 300 es
layout(location=0) in vec3 aPos; layout(location=5) in vec2 aUV;
uniform mat4 uVP; uniform float uTime; uniform vec3 uCam; uniform vec2 uFlowDir;
out vec3 vW; out vec2 vUV; out float vDist; out float vH;
void main(){ vec3 p=aPos; float w = sin(p.x*1.7+uTime*1.6+p.z*.8)*.03+sin(p.z*2.3-uTime*1.9+p.x*.6)*.025; p.y+=w; vH=w; vW=p; vUV=aUV; vDist=length(p-uCam); gl_Position=uVP*vec4(p,1.); }`;
const WATER_FS = `#version 300 es
precision highp float;
in vec3 vW; in vec2 vUV; in float vDist; in float vH;
uniform vec3 uCam, uColA, uColB, uFogCol, uSkyCol; uniform float uFog, uTime, uAlpha; uniform vec2 uFlowDir;
out vec4 o;
float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
float noise(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f); return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y); }
void main(){
  vec2 q = vW.xz*1.3 - uFlowDir*uTime*.6;
  float n = noise(q*2.)*.6+noise(q*5.+3.)*.3;
  vec3 V = normalize(uCam-vW); float fr = pow(1.-max(V.y,0.),3.);
  vec3 base = mix(uColA,uColB,n);
  float streak = smoothstep(.62,.8,noise(q*vec2(1.,4.)+uTime*.2));
  vec3 c = mix(base,uSkyCol,fr*.55) + vec3(streak)*uColB*.6 + vec3(smoothstep(.04,.06,vH))*uColB*.4;
  float f = 1.-exp(-uFog*uFog*vDist*vDist);
  c = mix(c,uFogCol,clamp(f,0.,1.));
  o = vec4(c,uAlpha);
}`;
const FX_VS = `#version 300 es
layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNrm; layout(location=2) in vec3 aCol; layout(location=3) in float aEmi; layout(location=5) in vec2 aUV;
uniform mat4 uVP, uModel; uniform float uTime; uniform vec3 uCam; uniform float uPulse;
out vec3 vC; out float vA; out float vDist; out float vFace;
void main(){ vec4 w=uModel*vec4(aPos,1.); vC=aCol; vA=aEmi*(1.+uPulse*sin(uTime*2.+w.x+w.z)*.3); vDist=length(w.xyz-uCam);
  vFace = aUV.x>1.5 ? pow(abs(dot(normalize(mat3(uModel)*aNrm), normalize(uCam-w.xyz))),1.6) : 1.; gl_Position=uVP*w; }`;
const FX_FS = `#version 300 es
precision highp float;
in vec3 vC; in float vA; in float vDist; in float vFace; uniform float uFog; uniform vec3 uFogCol; uniform float uShadow;
out vec4 o;
void main(){ float f=1.-exp(-uFog*uFog*vDist*vDist); float a=vA*vFace*(1.-f*.8); o=vec4(uShadow>.5?vec3(0.):vC,a); }`;
const PT_VS = `#version 300 es
layout(location=0) in vec3 aPos; layout(location=1) in float aSize; layout(location=2) in vec3 aCol; layout(location=3) in vec2 aPh;
uniform mat4 uVP; uniform float uTime, uScale; uniform vec3 uCam; uniform vec3 uRange;
out vec3 vC; out float vA;
void main(){
  float ph=aPh.x, kind=aPh.y; vec3 p=aPos; float a=1.;
  if(kind<.5){ p.y+=sin(uTime*.8+ph*6.28)*.35+.2; p.x+=sin(uTime*.5+ph*17.)*.5; p.z+=cos(uTime*.43+ph*11.)*.5; a=.35+.65*pow(.5+.5*sin(uTime*2.+ph*40.),2.); }
  else if(kind<1.5){ float t=fract(uTime*.08*(.5+ph)+ph*3.7); p.y+=t*uRange.y; p.x+=sin(t*6.+ph*9.)*.7; p.z+=cos(t*5.+ph*7.)*.7; a=sin(t*3.14159); }
  else { float t=fract(uTime*.1*(.5+ph)+ph*2.3); p.y+=uRange.y*(1.-t); p.x+=sin(t*5.+ph*9.)*.6; a=sin(t*3.14159); }
  vec4 c=uVP*vec4(p,1.); gl_Position=c; float d=length(p-uCam); gl_PointSize=clamp(aSize*uScale/(d*.12+.4),1.,64.); vC=aCol; vA=a;
}`;
const PT_FS = `#version 300 es
precision highp float;
in vec3 vC; in float vA; out vec4 o;
void main(){ vec2 d=gl_PointCoord-.5; float r=length(d)*2.; float a=smoothstep(1.,.0,r); a*=a; o=vec4(vC,a*vA); }`;
const SKY_VS = `#version 300 es
out vec2 vP; void main(){ vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2); vP=p*2.-1.; gl_Position=vec4(vP,.9999,1.); }`;
const SKY_FS = `#version 300 es
precision highp float;
in vec2 vP; uniform vec3 uR,uU,uF; uniform vec2 uTan; uniform vec3 uTop,uMid,uBot,uSun; uniform vec3 uSunDir; uniform float uStars, uTime;
out vec4 o;
float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
void main(){
  vec3 d=normalize(uF+uR*vP.x*uTan.x+uU*vP.y*uTan.y);
  float t=clamp(d.y*1.5+.1,0.,1.);
  vec3 c=mix(uBot,uMid,smoothstep(0.,.35,t)); c=mix(c,uTop,smoothstep(.3,1.,t));
  float s=max(dot(d,-uSunDir),0.); c+=uSun*(pow(s,40.)*.8+pow(s,6.)*.18);
  if(uStars>0.){ vec2 g=floor(vec2(atan(d.x,d.z)*40.,d.y*80.)); float h=hash(g); float st=step(.985,h)*smoothstep(.1,.5,d.y)*(.5+.5*sin(uTime*2.+h*50.)); c+=vec3(st)*uStars; }
  o=vec4(c,1.);
}`;

function compile(gl, type, src) { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('Shader: ' + gl.getShaderInfoLog(s)); return s; }
function program(gl, vs, fs) { const p = gl.createProgram(); gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, vs)); gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p); if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('Link: ' + gl.getProgramInfoLog(p)); const u = {}; const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS); for (let i = 0; i < n; i++) { const a = gl.getActiveUniform(p, i); const nm = a.name.replace('[0]', ''); u[nm] = gl.getUniformLocation(p, a.name); } return { p, u }; }

export class Mesh {
  constructor(r, geo, kind = 'lit') {
    const gl = r.gl; this.gl = gl; this.kind = kind; this.count = geo.idx.length; this.b = geo.bounds(); this.model = null; this.visible = true;
    this.vao = gl.createVertexArray(); gl.bindVertexArray(this.vao);
    this.vb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.vb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(geo.v), gl.STATIC_DRAW);
    this.ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, geo.n > 65535 ? new Uint32Array(geo.idx) : new Uint16Array(geo.idx), gl.STATIC_DRAW);
    this.itype = geo.n > 65535 ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT;
    const L = [[0, 3, 0], [1, 3, 12], [2, 3, 24], [3, 1, 36], [4, 1, 40], [5, 2, 44]]; for (const [i, n, o] of L) { gl.enableVertexAttribArray(i); gl.vertexAttribPointer(i, n, gl.FLOAT, false, STRIDE, o); }
    gl.bindVertexArray(null); r.meshes.push(this);
  }
  draw() { const gl = this.gl; gl.bindVertexArray(this.vao); gl.drawElements(gl.TRIANGLES, this.count, this.itype, 0); }
}

export class Renderer {
  constructor(canvas, opts = {}) {
    const gl = canvas.getContext('webgl2', { antialias: opts.aa !== false, alpha: false, powerPreference: 'high-performance', preserveDrawingBuffer: !!opts.preserve });
    if (!gl) throw new Error('NO_WEBGL2');
    this.gl = gl; this.canvas = canvas; this.meshes = []; this.time = 0; this.lost = false;
    canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); this.lost = true; this.onLost && this.onLost(); });
    this.lit = program(gl, LIT_VS, LIT_FS); this.water = program(gl, WATER_VS, WATER_FS); this.fx = program(gl, FX_VS, FX_FS); this.pt = program(gl, PT_VS, PT_FS); this.sky = program(gl, SKY_VS, SKY_FS);
    this.vp = mat4(); this.proj = mat4(); this.view = mat4(); this.ident = mat4(); this.cam = [0, 0, 0]; this.fov = 1.0;
    this.env = { sunDir: [-.4, -.8, -.3], sunCol: [1, .9, .7], ambSky: [.4, .45, .6], ambGnd: [.2, .2, .25], fogCol: [.1, .15, .2], fog: .02, top: [.05, .1, .2], mid: [.1, .2, .3], bot: [.2, .3, .35], sun: [.5, .4, .3], stars: 0 };
    this.lights = []; this.pscale = 1; this.dpr = 1; this.ptVAO = gl.createVertexArray();
    gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE); gl.clearColor(0, 0, 0, 1);
    this.fxDraws = []; this.waterDraws = []; this.shadowMesh = null; this.shadowGeoBuf = null;
  }
  resize(q = 1) { const c = this.canvas, d = Math.min(window.devicePixelRatio || 1, 2) * q; const w = Math.max(2, Math.floor(c.clientWidth * d)), h = Math.max(2, Math.floor(c.clientHeight * d)); if (c.width !== w || c.height !== h) { c.width = w; c.height = h; } this.dpr = d; this.aspect = w / h; this.gl.viewport(0, 0, w, h); this.pscale = h / 800; }
  setCamera(eye, target) {
    this.cam = eye; perspective(this.proj, this.fov, this.aspect || 1, .2, 260); lookAt(this.view, eye, target, [0, 1, 0]); multiply(this.vp, this.proj, this.view); this.planes = frustumPlanes(this.vp);
    const v = this.view; this.basis = { r: [v[0], v[4], v[8]], u: [v[1], v[5], v[9]], f: [-v[2], -v[6], -v[10]] };
  }
  uniformsLit(P) {
    const gl = this.gl, e = this.env, u = P.u;
    gl.uniformMatrix4fv(u.uVP, false, this.vp); gl.uniform1f(u.uTime, this.time); gl.uniform3fv(u.uCam, this.cam);
    if (u.uSunDir) { gl.uniform3fv(u.uSunDir, e.sunDir); gl.uniform3fv(u.uSunCol, e.sunCol); gl.uniform3fv(u.uAmbSky, e.ambSky); gl.uniform3fv(u.uAmbGnd, e.ambGnd); }
    gl.uniform3fv(u.uFogCol, e.fogCol); gl.uniform1f(u.uFog, e.fog);
  }
  /** يحسب أقرب 8 أضواء نقطية للكاميرا/اللاعب */
  pickLights(focus) {
    const L = this.lights.filter(l => l.on !== false).map(l => ({ l, d: Math.hypot(l.x - focus[0], l.y - focus[1], l.z - focus[2]) - l.r * .4 })).sort((a, b) => a.d - b.d).slice(0, 8);
    this.pl = new Float32Array(32); this.pc = new Float32Array(24); this.npl = L.length;
    L.forEach(({ l }, i) => { const f = l.flick ? 1 + Math.sin(this.time * 9 + l.x * 3) * l.flick : 1; this.pl.set([l.x, l.y, l.z, l.r], i * 4); this.pc.set([l.c[0] * f * (l.i || 1), l.c[1] * f * (l.i || 1), l.c[2] * f * (l.i || 1)], i * 3); });
  }
  beginFrame(dt) { this.time += dt; const gl = this.gl; gl.clearColor(...this.env.fogCol, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); this.stats = { draws: 0, tris: 0 }; }
  drawSky() {
    const gl = this.gl, e = this.env, u = this.sky.u, b = this.basis; gl.useProgram(this.sky.p); gl.depthMask(false); gl.disable(gl.CULL_FACE);
    gl.uniform3fv(u.uR, b.r); gl.uniform3fv(u.uU, b.u); gl.uniform3fv(u.uF, b.f); const t = Math.tan(this.fov / 2); gl.uniform2f(u.uTan, t * this.aspect, t);
    gl.uniform3fv(u.uTop, e.top); gl.uniform3fv(u.uMid, e.mid); gl.uniform3fv(u.uBot, e.bot); gl.uniform3fv(u.uSun, e.sun); gl.uniform3fv(u.uSunDir, e.sunDir); gl.uniform1f(u.uStars, e.stars); gl.uniform1f(u.uTime, this.time);
    gl.bindVertexArray(this.ptVAO); gl.drawArrays(gl.TRIANGLES, 0, 3); gl.depthMask(true); gl.enable(gl.CULL_FACE);
  }
  /** يرسم قائمة شبكات ثابتة (مع قص الرؤية) */
  drawLit(list, focus) {
    const gl = this.gl, P = this.lit, u = P.u; gl.useProgram(P.p); this.uniformsLit(P); this.pickLights(focus);
    gl.uniform4fv(u.uPL, this.pl); gl.uniform3fv(u.uPC, this.pc); gl.uniform1i(u.uNL, this.npl);
    gl.uniformMatrix4fv(u.uModel, false, this.ident);
    for (const m of list) { if (!m.visible) continue; if (!m.model && !sphereVisible(this.planes, m.b.c, m.b.r)) continue; m.draw(); this.stats.draws++; this.stats.tris += m.count / 3; }
  }
  drawModel(mesh, M) { const gl = this.gl; gl.uniformMatrix4fv(this.lit.u.uModel, false, M); mesh.draw(); this.stats.draws++; this.stats.tris += mesh.count / 3; gl.uniformMatrix4fv(this.lit.u.uModel, false, this.ident); }
  drawWater(list, p) {
    const gl = this.gl, P = this.water, u = P.u; gl.useProgram(P.p); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
    gl.uniformMatrix4fv(u.uVP, false, this.vp); gl.uniform1f(u.uTime, this.time); gl.uniform3fv(u.uCam, this.cam); gl.uniform3fv(u.uFogCol, this.env.fogCol); gl.uniform1f(u.uFog, this.env.fog);
    gl.uniform3fv(u.uColA, p.a); gl.uniform3fv(u.uColB, p.b); gl.uniform3fv(u.uSkyCol, this.env.mid); gl.uniform1f(u.uAlpha, p.alpha || .85);
    for (const m of list) { gl.uniform2fv(u.uFlowDir, m.flow || [0, 0]); if (!sphereVisible(this.planes, m.b.c, m.b.r)) continue; m.draw(); this.stats.draws++; }
    gl.depthMask(true); gl.disable(gl.BLEND);
  }
  /** توهّج إضافي (additive) أو ظلال (alpha) */
  drawFx(list, { shadow = false, pulse = 0, model = null } = {}) {
    const gl = this.gl, P = this.fx, u = P.u; gl.useProgram(P.p); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, shadow ? gl.ONE_MINUS_SRC_ALPHA : gl.ONE); gl.depthMask(false);
    if (shadow) gl.enable(gl.POLYGON_OFFSET_FILL), gl.polygonOffset(-1, -1);
    gl.uniformMatrix4fv(u.uVP, false, this.vp); gl.uniformMatrix4fv(u.uModel, false, model || this.ident); gl.uniform1f(u.uTime, this.time); gl.uniform3fv(u.uCam, this.cam); gl.uniform1f(u.uFog, this.env.fog); gl.uniform1f(u.uShadow, shadow ? 1 : 0); gl.uniform1f(u.uPulse, pulse);
    gl.disable(gl.CULL_FACE);
    for (const m of list) { if (!m.model && !sphereVisible(this.planes, m.b.c, m.b.r)) continue; if (m.model) gl.uniformMatrix4fv(u.uModel, false, m.model); m.draw(); this.stats.draws++; if (m.model) gl.uniformMatrix4fv(u.uModel, false, this.ident); }
    gl.enable(gl.CULL_FACE); gl.depthMask(true); gl.disable(gl.BLEND); if (shadow) gl.disable(gl.POLYGON_OFFSET_FILL);
  }
  makeParticles(arr) {
    const gl = this.gl, vao = gl.createVertexArray(); gl.bindVertexArray(vao); const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(arr), gl.STATIC_DRAW);
    const S = 9 * 4; [[0, 3, 0], [1, 1, 12], [2, 3, 16], [3, 2, 28]].forEach(([i, n, o]) => { gl.enableVertexAttribArray(i); gl.vertexAttribPointer(i, n, gl.FLOAT, false, S, o); }); gl.bindVertexArray(null);
    const o = { vao, b, n: arr.length / 9, range: [0, 6, 0] }; (this.pv = this.pv || []).push(o); return o;
  }
  mark() { return { m: this.meshes.length, p: (this.pv = this.pv || []).length }; }
  disposeFrom(k) { const gl = this.gl; for (const m of this.meshes.splice(k.m)) { gl.deleteVertexArray(m.vao); gl.deleteBuffer(m.vb); gl.deleteBuffer(m.ib); } for (const v of this.pv.splice(k.p)) { gl.deleteVertexArray(v.vao); gl.deleteBuffer(v.b); } }
  drawParticles(list, scale = 1) {
    const gl = this.gl, P = this.pt, u = P.u; gl.useProgram(P.p); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE); gl.depthMask(false);
    gl.uniformMatrix4fv(u.uVP, false, this.vp); gl.uniform1f(u.uTime, this.time); gl.uniform3fv(u.uCam, this.cam); gl.uniform1f(u.uScale, this.pscale * 90 * scale);
    for (const p of list) { gl.uniform3fv(u.uRange, p.range); gl.bindVertexArray(p.vao); gl.drawArrays(gl.POINTS, 0, p.n); this.stats.draws++; }
    gl.depthMask(true); gl.disable(gl.BLEND);
  }
}
