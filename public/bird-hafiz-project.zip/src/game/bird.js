// الطائر: مجسّم ناعم (كرات وأقماع) بأجنحة ترفرف + متحكّم طيران سلس (3D).
import { Geo } from '../engine/geo.js';
import { Mesh } from '../engine/gl.js';
import { mul, mT, mRY, mRX, mRZ, mS, clamp, lerp, lerpAngle } from '../engine/math.js';
const BLUE = [.28, .62, 1], BLUE2 = [.18, .46, .95], CREAM = [1, .95, .82], ORANGE = [1, .62, .15], PINK = [1, .55, .62], YEL = [1, .85, .3];
export function createBird(r) {
  const mk = f => { const g = new Geo(); f(g); return new Mesh(r, g); };
  const P = {
    body: mk(g => { g.sph(0, 0, 0, .56, .5, .72, BLUE, { hi: 1, jit: 0, grad: .35 }); g.sph(0, -.16, .14, .44, .36, .56, CREAM, { hi: 1, jit: 0 }); g.sph(-.2, -.45, .1, .07, .12, .07, ORANGE, { jit: 0, low: 1 }); g.sph(.2, -.45, .1, .07, .12, .07, ORANGE, { jit: 0, low: 1 }); }),
    head: mk(g => { g.sph(0, 0, 0, .46, .44, .44, BLUE, { hi: 1, jit: 0 }); g.sph(0, -.08, .1, .38, .3, .34, CREAM, { hi: 1, jit: 0 });
      for (const s of [-1, 1]) { g.sph(s * .2, .06, .34, .13, .13, .06, [1, 1, 1], { hi: 1, jit: 0 }); g.sph(s * .2, .06, .39, .085, .095, .04, [.05, .04, .08], { hi: 1, jit: 0 }); g.sph(s * .22, .1, .42, .03, .03, .02, [1, 1, 1], { jit: 0, e: .5, low: 1 }); g.sph(s * .32, -.1, .3, .1, .07, .05, PINK, { jit: 0, low: 1 }); }
      g.cone(0, -.02, .5, .1, .3, ORANGE, { seg: 10, rx: Math.PI / 2, jit: 0 }); g.cone(0, -.1, .46, .08, .2, [1, .5, .12], { seg: 8, rx: Math.PI / 2, jit: 0 });
      for (let i = -1; i <= 1; i++) g.cone(i * .08, .46, -.02, .05, .26, YEL, { seg: 5, rz: -i * .35, rx: -.25, jit: 0 }); }),
    tail: mk(g => { for (let i = -1; i <= 1; i++) g.cone(i * .12, 0, -.35, .1, .7, i ? BLUE2 : [.12, .35, .85], { seg: 6, rx: -Math.PI / 2 + .1, rz: i * .25, jit: 0 }); }),
    wingL: mk(g => { g.sph(-.62, 0, -.02, .72, .07, .4, BLUE2, { hi: 1, jit: 0 }); for (let i = 0; i < 4; i++) g.cone(-1.2 - i * .08, 0, .22 - i * .17, .09, .5, i % 2 ? [.95, .98, 1] : YEL, { seg: 5, rz: Math.PI / 2 + .08 * i, rx: .1 * i, jit: 0 }); }),
    wingR: mk(g => { g.sph(.62, 0, -.02, .72, .07, .4, BLUE2, { hi: 1, jit: 0 }); for (let i = 0; i < 4; i++) g.cone(1.2 + i * .08, 0, .22 - i * .17, .09, .5, i % 2 ? [.95, .98, 1] : YEL, { seg: 5, rz: -Math.PI / 2 - .08 * i, rx: .1 * i, jit: 0 }); }),
  };
  const sh = (() => { const g = new Geo(), n = 14; for (let i = 0; i < n; i++) { const a = i / n * 6.283, b = (i + 1) / n * 6.283, base = g.n; g.v.push(0, 0, 0, 0, 1, 0, 0, 0, 0, .45, 0, 0, 0, Math.cos(a) * .5, 0, Math.sin(a) * .5, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, Math.cos(b) * .5, 0, Math.sin(b) * .5, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0); g.idx.push(base, base + 2, base + 1); g.n += 3; } g.min = [-.5, 0, -.5]; g.max = [.5, 0, .5]; return new Mesh(r, g, 'fx'); })();
  const glow = (() => { const g = new Geo(); g.sph(0, 0, 0, 1.4, 1.4, 1.4, [1, .95, .6], { e: .22, soft: 1, jit: 0 }); return new Mesh(r, g, 'fx'); })();
  const B = { x: 0, y: 12, z: -45, yaw: 0, vx: 0, vy: 0, vz: 0, speed: 0, roll: 0, pitch: 0, boost: 0, t: 0, sparkle: 0 };
  B.update = function (dt, mx, mz, up, down, boost, H, bounds) {
    const len = Math.min(1, Math.hypot(mx, mz)), top = boost ? 19 : 11; this.boost = boost;
    const tx = mx * top, tz = mz * top, ty = (up ? 7 : 0) - (down ? 7 : 0), k = 1 - Math.exp(-3.2 * dt);
    this.vx += (tx - this.vx) * k; this.vz += (tz - this.vz) * k; this.vy += (ty - this.vy) * (1 - Math.exp(-4 * dt));
    if (!up && !down && len < .05) this.vy += Math.sin(this.t * 2) * .02;
    this.x += this.vx * dt; this.y += this.vy * dt; this.z += this.vz * dt; this.speed = Math.hypot(this.vx, this.vz);
    if (len > .1 || this.speed > 1.5) { const ty2 = Math.atan2(this.vx, this.vz); const old = this.yaw; this.yaw = lerpAngle(this.yaw, ty2, 1 - Math.exp(-6 * dt)); let d = this.yaw - old; d = Math.atan2(Math.sin(d), Math.cos(d)); this.roll += (clamp(-d / Math.max(dt, .001) * .35, -.7, .7) - this.roll) * Math.min(1, dt * 6); } else this.roll *= .9;
    this.pitch += (clamp(-this.vy * .05, -.5, .5) + this.speed * .012 - this.pitch) * Math.min(1, dt * 5);
    const g = H(this.x, this.z) + .9; if (this.y < g) { this.y = g; if (this.vy < 0) this.vy = 0; }
    const d = Math.hypot(this.x, this.z); if (d > bounds) { this.x *= bounds / d; this.z *= bounds / d; }
    if (this.y > 120) { this.y = 120; this.vy = 0; } this.t += dt;
  };
  /** طيران على مسار مستقيم: يتقدّم تلقائيًا؛ الطفل يوجّه يمينًا/يسارًا وأعلى/أسفل فقط */
  B.updateRail = function (dt, mx, up, down, fwd, pullX, H, pullY) {
    const k = 1 - Math.exp(-3 * dt);
    this.vz += (fwd - this.vz) * k; this.vx += ((mx * 8) + (-this.x) * pullX - this.vx) * k;
    const ty = (up ? 7 : 0) - (down ? 7 : 0) + (!up && !down ? (pullY - this.y) * .6 : 0); this.vy += (ty - this.vy) * (1 - Math.exp(-4 * dt));
    this.x = clamp(this.x + this.vx * dt, -16, 16); this.y += this.vy * dt; this.z += this.vz * dt; this.speed = Math.hypot(this.vx, this.vz);
    const g = H(this.x, this.z) + 3; if (this.y < g) { this.y = g; if (this.vy < 0) this.vy = 0; } this.y = Math.min(this.y, 36);
    this.yaw = lerpAngle(this.yaw, Math.atan2(this.vx * .6, Math.max(this.vz, 3)), 1 - Math.exp(-6 * dt)); this.roll += (clamp(-this.vx * .06, -.5, .5) - this.roll) * Math.min(1, dt * 5);
    this.pitch += (clamp(-this.vy * .05, -.4, .4) + .04 - this.pitch) * Math.min(1, dt * 5); this.t += dt; this.boost = 0;
  };
  B.draw = function (rd) {
    const flapF = this.boost ? 16 : 10 + this.speed * .3 + Math.max(0, this.vy) * .6, amp = .55 + (this.boost ? .25 : 0) + (this.vy > 1 ? .2 : 0) - (this.vy < -1 ? .35 : 0), fl = Math.sin(this.t * flapF) * amp, bob = Math.sin(this.t * 2.2) * .06;
    const root = mul(mT(this.x, this.y + bob, this.z), mRY(this.yaw), mRX(this.pitch), mRZ(this.roll)), D = (m, M) => rd.drawModel(P[m], M);
    D('body', root); D('head', mul(root, mT(0, .5, .45), mRX(-this.pitch * .5 + Math.sin(this.t * 1.7) * .04), mRZ(-this.roll * .4)));
    D('tail', mul(root, mT(0, .02, -.55), mRX(Math.sin(this.t * 4) * .08 - this.pitch * .6)));
    D('wingL', mul(root, mT(-.35, .22, .05), mRZ(fl + .15), mRY(.12))); D('wingR', mul(root, mT(.35, .22, .05), mRZ(-fl - .15), mRY(-.12)));
  };
  B.drawFx = function (rd, ground) { const h = Math.max(0, this.y - ground), s = 1 / (1 + h * .08); rd.drawFx([Object.assign(sh, { model: mul(mT(this.x, ground + .05, this.z), mS(1.6 * s, 1, 1.6 * s)) })], { shadow: true }); sh.model = null; if (this.sparkle > 0) { rd.drawFx([Object.assign(glow, { model: mT(this.x, this.y, this.z) })], { pulse: 1 }); glow.model = null; } };
  return B;
}
