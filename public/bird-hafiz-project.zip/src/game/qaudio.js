// التلاوة: تسجيلات القارئ ياسين الجزائري المرسَلة من صاحبة المشروع (ملفات سور كاملة 095–114، في assets/audio).
// تُقتطع الآيات بالمواضع الزمنية (segments.json) — تقدير آلي من الصمت/الطاقة يمكن للمعلمة تصحيحه. لا يُستخدم أي توليد صوتي للقرآن.
const OV = 'bird-seg-override';
export class QAudio {
  constructor(P) { this.P = P; this.auto = {}; try { this.auto = JSON.parse(document.getElementById('seg-data').textContent); } catch (e) { } try { this.ov = JSON.parse(localStorage.getItem(OV) || '{}'); } catch (e) { this.ov = {}; } this.el = null; this.timer = 0; this.base = document.documentElement.dataset.audioBase || 'audio/'; }
  has(s) { return !!(this.ov[s] || this.auto[s]); }
  segs(s) { return (this.ov[s] && this.ov[s].segs) || (this.auto[s] && this.auto[s].segs) || null; }
  conf(s) { if (this.ov[s]) return 'teacher'; const a = this.auto[s]; return a ? (a.dev > .5 ? 'low' : 'auto') : 'none'; }
  setOverride(s, segs) { this.ov[s] = { segs }; try { localStorage.setItem(OV, JSON.stringify(this.ov)); } catch (e) { } }
  clearOverride(s) { delete this.ov[s]; try { localStorage.setItem(OV, JSON.stringify(this.ov)); } catch (e) { } }
  get enabled() { return this.P.d.audio.on !== false; }
  available(s) { return this.enabled && this.has(s); }
  file(s) { return this.base + String(s).padStart(3, '0') + '.mp3'; }
  stop() { clearInterval(this.timer); if (this.el) { try { this.el.pause(); } catch (e) { } } this.token = (this.token || 0) + 1; }
  /** يشغّل الآية a من السورة s؛ يعيد وعدًا يتحقق عند الانتهاء */
  play(s, a) { return new Promise(res => { const sg = this.segs(s); if (!this.available(s) || !sg || !sg[a - 1]) return res(false); this.stop(); const tok = this.token, [st, en] = sg[a - 1];
    const el = this.el = new Audio(this.file(s)); el.preload = 'auto'; const fin = ok => { if (tok !== this.token) return res(false); clearInterval(this.timer); try { el.pause(); } catch (e) { } res(ok); };
    el.onerror = () => { this.err && this.err(); fin(false); }; el.onloadedmetadata = () => { el.currentTime = Math.max(0, st - .05); el.play().then(() => { this.timer = setInterval(() => { if (el.currentTime >= en + .08) fin(true); }, 30); }).catch(() => { this.err && this.err(); fin(false); }); };
    el.load(); }); }
  playFull(s, from) { return new Promise(res => { this.stop(); const el = this.el = new Audio(this.file(s)); el.onloadedmetadata = () => { el.currentTime = from || 0; el.play().catch(() => res(false)); res(true); }; el.load(); }); }
}
export const PRAISE = ['أحسنت!', 'ممتاز!', 'واصل يا بطل!', 'ما شاء الله!', 'رائع!'], TRY = ['حاول مرة أخرى', 'لا بأس، فكّر من جديد'];
let voice = null;
// كلام التشجيع فقط (عبارات ثابتة غير قرآنية)
export function speak(t, on = true) { try { if (!on || !window.speechSynthesis) return; speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(t); u.lang = 'ar-SA'; u.rate = .95; u.pitch = 1.2; if (!voice) voice = speechSynthesis.getVoices().find(v => v.lang.startsWith('ar')); if (voice) u.voice = voice; speechSynthesis.speak(u); } catch (e) { } }
