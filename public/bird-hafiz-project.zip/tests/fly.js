const { chromium } = require('playwright'); const S = process.argv[2];
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await b.newPage({ viewport: { width: 1100, height: 650 } }); p.setDefaultTimeout(20000); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type() === 'error' && errs.push(m.text()));
  await p.goto('file:///home/claude/bird-game/dist/bird-hafiz.html'); await p.waitForSelector('#title.on'); await p.screenshot({ path: S + '/b_title.png' }); await p.click('text=هيّا نطير'); await p.waitForTimeout(2500);
  await p.screenshot({ path: S + '/b_start.png' });
  const pos = () => p.evaluate(() => { const b = __game.bird; return [b.x, b.y, b.z, b.speed].map(v => +v.toFixed(1)); });
  const a = await pos(); await p.keyboard.down('KeyW'); await p.waitForTimeout(3000); const w = await pos(); await p.keyboard.down('Space'); await p.waitForTimeout(2500); const u = await pos(); await p.keyboard.up('Space'); await p.keyboard.up('KeyW');
  console.log(JSON.stringify({ a, fwd: w, up: u }), 'stars', await p.evaluate(() => __game.P.d.stars)); await p.screenshot({ path: S + '/b_fly.png' });
  console.log('errors', JSON.stringify(errs.slice(0, 5)), 'fps', await p.evaluate(() => __game.fps)); await b.close();
})();
