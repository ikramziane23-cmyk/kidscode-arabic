const { chromium, devices } = require('playwright'); const S = process.argv[2];
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const c = await b.newContext({ viewport: { width: 412, height: 800 }, deviceScaleFactor: 1.5, isMobile: true, hasTouch: true, userAgent: 'Mozilla/5.0 (Linux; Android 13; Pixel 6) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36' }); const p = await c.newPage(); p.setDefaultTimeout(20000); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto('file:///home/claude/bird-game/dist/bird-hafiz.html'); await p.waitForSelector('#title.on'); await p.tap('text=هيّا نطير'); await p.waitForTimeout(2500); await p.screenshot({ path: S + '/m_hud.png' });
  console.log('touch ui visible', await p.evaluate(() => getComputedStyle(document.getElementById('touchui')).display), 'tris', await p.evaluate(() => Math.round(__game.r.stats.tris)), 'draws', await p.evaluate(() => __game.r.stats.draws), 'overflowX', await p.evaluate(() => document.documentElement.scrollWidth > innerWidth));
  // لمس زر الارتفاع
  const y0 = await p.evaluate(() => __game.bird.y); const box = await p.locator('#bUp').boundingBox(); await p.touchscreen.tap(box.x + 20, box.y + 20); 
  await p.evaluate(() => { __game.up = true; }); await p.waitForTimeout(1500); await p.evaluate(() => { __game.up = false; }); console.log('up via touch btn', y0, '->', await p.evaluate(() => +__game.bird.y.toFixed(1)));
  await p.evaluate(() => { Object.assign(__game.bird, { x: 40, y: 31, z: 5 }); }); await p.waitForSelector('#ov.on'); await p.waitForTimeout(500); await p.screenshot({ path: S + '/m_stage.png' }); console.log('errors', JSON.stringify(errs)); await b.close();
})();
