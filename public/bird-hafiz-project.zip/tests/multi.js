const { chromium } = require('playwright');
(async () => {
  const [,, file, outPrefix, ...views] = process.argv;
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await b.newPage({ viewport: { width: 1000, height: 600 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await p.goto('file://' + file); await p.waitForTimeout(2500);
  let i = 0; for (const v of views) { await p.evaluate(v); await p.waitForTimeout(2200); await p.screenshot({ path: `${outPrefix}${i++}.png` }); }
  console.log('errors', JSON.stringify(errs.slice(0, 4)), 'fps~', await p.evaluate(() => window.frames)); await b.close();
})();
