const { chromium } = require('playwright'); const S = process.argv[2];
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await b.newPage({ viewport: { width: 1100, height: 650 } }); p.setDefaultTimeout(20000); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type() === 'error' && errs.push(m.text()));
  await p.goto('file:///home/claude/bird-game/dist/bird-hafiz.html'); await p.waitForSelector('#title.on'); await p.click('text=هيّا نطير'); await p.waitForTimeout(800);
  const R = await p.evaluate(() => 0); const tp = (x, y, z) => p.evaluate(([x, y, z]) => { Object.assign(__game.bird, { x, y, z }); }, [x, y, z]);
  // المرحلة 1 عبر الحلقة الخضراء
  await tp(0, 10, -34); await p.waitForSelector('#ov.on'); await p.evaluate(() => __game.noRender = true); await p.click('.kbtn.big'); await p.click('.kbtn.big'); for (let i = 0; i < 6; i++) { if (await p.locator('#ov.on').count() === 0) break; await p.click('.kbtn.big').catch(() => { }); } console.log('stage1 stars', await p.evaluate(() => __game.P.d.stars));
  await p.evaluate(() => { __game.noRender = false; }); await tp(0, 30, 80); await p.waitForTimeout(500);
  // مرحلة 2 (مع خطأ أول مرة) و3
  const solve = async (wrongFirst) => { await p.evaluate(() => __game.noRender = true); for (let g = 0; g < 8; g++) { if (!await p.locator('#ov.on').count()) break; const q = await p.evaluate(() => window.__q); const opts = p.locator('.kopt .kbtn.opt'); if (wrongFirst && g === 0) { await opts.nth((q.ans + 1) % 3).click(); } await opts.nth(q.ans).click(); await p.click('.kfb .kbtn'); } await p.evaluate(() => __game.noRender = false); };
  await tp(40, 31, 5); await p.evaluate(() => { __game.ringCool = 0; }); await p.waitForSelector('#ov.on'); await p.screenshot({ path: S + '/b_st2.png' }); await p.waitForTimeout(500); console.log('ERRS', JSON.stringify(errs), await p.evaluate(() => document.getElementById('ov').innerHTML.slice(0,200))); await solve(true); console.log('after stage2', await p.evaluate(() => __game.P.d.stars));
  await tp(-35, 43, 45); await p.evaluate(() => { __game.ringCool = 0; }); await p.waitForSelector('#ov.on'); await p.screenshot({ path: S + '/b_st3.png' }); await solve(false);
  console.log(JSON.stringify(await p.evaluate(() => ({ stars: __game.P.d.stars, seg: __game.P.d.seg, res: __game.P.d.results.slice(0, 8).map(r => r.stage + (r.ok ? '✔' : '✘')) }))));
  // وضع شفهي + لوحة المعلمة
  await p.keyboard.press('KeyT'); await p.waitForTimeout(500); await p.evaluate(() => { __game.P.d.set.hide = true; __game.P.save(); }); await p.keyboard.press('Digit3'); await p.waitForSelector('#ov.on'); await p.screenshot({ path: S + '/b_oral.png' });
  await p.click('.kbtn.good'); await p.click('.kbtn.good'); await p.click('.kbtn.bad').catch(() => { }); await p.waitForTimeout(500);
  await p.evaluate(() => { __game.noRender = false; }); await p.click('.ttab >> nth=2'); await p.screenshot({ path: S + '/b_teacher.png' });
  // صندوق
  await p.evaluate(() => { const c = __game.W.items.find(i => i.k === 'chest'); Object.assign(__game.bird, { x: c.x, y: c.y + 2, z: c.z - 1 }); }); await p.waitForTimeout(800); await p.keyboard.press('KeyE'); await p.waitForTimeout(800); await p.screenshot({ path: S + '/b_chest.png' });
  console.log('final', JSON.stringify(await p.evaluate(() => ({ stars: __game.P.d.stars, gems: __game.P.d.gems, ch: __game.P.d.chests }))), 'errors', JSON.stringify(errs.slice(0, 4))); await b.close();
})();
