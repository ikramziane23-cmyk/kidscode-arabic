// تحميل النص القرآني (رواية ورش عن نافع، طريق الأزرق — مصدر KFGQPC) المضمَّن في الصفحة، مع فحص السلامة.
export const Q = { surahs: [], total: 0, ok: false, sha: '' };
const MARKS = /^[ؐ-ًؚ-ٰٟۖ-ۭ࣓-ࣿ‌‍⁠ ۞۩۞۩]+$/;
export function words(s) { const out = []; for (const t of s.split(/[\s ]+/)) { if (!t) continue; if (MARKS.test(t) && out.length) out[out.length - 1] += ' ' + t; else if (!MARKS.test(t)) out.push(t); } return out; }
export async function loadQuran() {
  const el = document.getElementById('quran-data'); if (!el) throw new Error('بيانات المصحف غير مضمَّنة');
  const raw = el.textContent.trim(); const expect = (document.getElementById('quran-sha') || {}).textContent;
  if (window.crypto && crypto.subtle && expect) { const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw)); const hex = [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join(''); if (hex !== expect.trim()) throw new Error('فشل فحص سلامة النص القرآني'); Q.sha = hex; }
  const d = JSON.parse(raw); let total = 0;
  Q.surahs = d.map((s, i) => { total += s[1].length; return { n: i + 1, name: s[0], ayat: s[1], w: s[1].map(words) }; });
  if (Q.surahs.length !== 114 || total !== 6214) throw new Error('عدد السور/الآيات غير مطابق لرواية ورش (' + total + ')');
  Q.total = total; Q.ok = true; return Q;
}
export const surah = n => Q.surahs[n - 1];
