// صوت مُولَّد بـ WebAudio: أجواء بيئية (ماء/ريح/صدى) ومؤثرات (خطوة، قفز، التقاط، نجاح، خطأ). بلا موسيقى.
export class Sfx {
  constructor() { this.ctx = null; this.vol = 1; this.on = true; this.amb = null; }
  init() { if (this.ctx) { this.ctx.state === 'suspended' && this.ctx.resume(); return; } try { const A = window.AudioContext || window.webkitAudioContext; this.ctx = new A(); this.master = this.ctx.createGain(); this.master.gain.value = this.vol; this.master.connect(this.ctx.destination); this._noise(); } catch (e) { this.ctx = null; } }
  setVol(v) { this.vol = v; if (this.master) this.master.gain.value = v; }
  _noise() { const c = this.ctx, b = c.createBuffer(1, c.sampleRate * 2, c.sampleRate), d = b.getChannelData(0); let l = 0; for (let i = 0; i < d.length; i++) { l = (l + .02 * (Math.random() * 2 - 1)) / 1.02; d[i] = l * 3.5; } this.nb = b; }
  ambience(kind) {
    if (!this.ctx || !this.on) return; this.stopAmb(); const c = this.ctx, g = c.createGain(); g.gain.value = 0; g.connect(this.master);
    const src = c.createBufferSource(); src.buffer = this.nb; src.loop = true; const f = c.createBiquadFilter(); src.connect(f); f.connect(g);
    const cfg = { forest: [500, .12, 'lowpass'], maze: [200, .1, 'lowpass'], crystal: [900, .05, 'bandpass'], time: [700, .07, 'bandpass'], cave: [160, .13, 'lowpass'] }[kind] || [400, .08, 'lowpass'];
    f.type = cfg[2]; f.frequency.value = cfg[0]; g.gain.linearRampToValueAtTime(cfg[1], c.currentTime + 2); src.start();
    const lfo = c.createOscillator(), lg = c.createGain(); lfo.frequency.value = .15; lg.gain.value = cfg[0] * .3; lfo.connect(lg); lg.connect(f.frequency); lfo.start();
    this.amb = { src, g, lfo };
  }
  stopAmb() { if (this.amb) { try { this.amb.g.gain.linearRampToValueAtTime(0, this.ctx.currentTime + .5); this.amb.src.stop(this.ctx.currentTime + .6); this.amb.lfo.stop(this.ctx.currentTime + .6); } catch (e) { } this.amb = null; } }
  tone(f, d, type = 'sine', v = .2, slide = 0, delay = 0) { if (!this.ctx || !this.on) return; const c = this.ctx, o = c.createOscillator(), g = c.createGain(), t = c.currentTime + delay; o.type = type; o.frequency.setValueAtTime(f, t); if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f + slide), t + d); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v, t + .01); g.gain.exponentialRampToValueAtTime(.001, t + d); o.connect(g); g.connect(this.master); o.start(t); o.stop(t + d + .05); }
  noiseBurst(d, f, v = .15) { if (!this.ctx || !this.on) return; const c = this.ctx, s = c.createBufferSource(); s.buffer = this.nb; const fl = c.createBiquadFilter(); fl.type = 'bandpass'; fl.frequency.value = f; const g = c.createGain(); g.gain.setValueAtTime(v, c.currentTime); g.gain.exponentialRampToValueAtTime(.001, c.currentTime + d); s.connect(fl); fl.connect(g); g.connect(this.master); s.start(); s.stop(c.currentTime + d + .05); }
  play(n) {
    switch (n) {
      case 'step': this.noiseBurst(.07, 300 + Math.random() * 200, .09); break;
      case 'splash': this.noiseBurst(.18, 1200, .12); break;
      case 'jump': this.tone(260, .16, 'triangle', .12, 220); break;
      case 'land': this.noiseBurst(.1, 160, .2); break;
      case 'pick': this.tone(660, .12, 'sine', .18); this.tone(990, .2, 'sine', .15, 0, .08); break;
      case 'key': this.tone(784, .15, 'triangle', .18); this.tone(1175, .3, 'triangle', .16, 0, .1); break;
      case 'door': this.tone(110, .5, 'sawtooth', .08, -40); this.noiseBurst(.4, 250, .12); break;
      case 'ok': [523, 659, 784].forEach((f, i) => this.tone(f, .25, 'sine', .16, 0, i * .09)); break;
      case 'bad': case 'try': this.tone(440, .2, 'sine', .08); this.tone(392, .3, 'sine', .07, 0, .15); break;
      case 'crystal': [523, 659, 784, 1047, 1319].forEach((f, i) => this.tone(f, .6, 'sine', .15, 0, i * .12)); break;
      case 'ui': this.tone(520, .06, 'sine', .08); break;
      case 'fall': this.tone(500, .5, 'sine', .08, -380); break;
      case 'rumble': this.noiseBurst(.6, 90, .2); break;
    }
  }
}
