// الشخصية الرئيسية: مجسّم بشري مبسّط مبني من أجزاء مفصلية ومتحركة (مشي/جري/قفز/تسلق/وقوف).
import { Geo } from './geo.js';
import { Mesh } from './gl.js';
import { mul, mT, mRY, mRX, mRZ, mS, lerp } from './math.js';
const SK = [.93, .74, .58];
export function createAvatar(r, pal = {}) {
  const tunic = pal.tunic || [.12, .58, .62], trim = pal.trim || [.95, .78, .3], pants = pal.pants || [.3, .22, .18], hair = pal.hair || [.1, .07, .06], hood = pal.hood || [.08, .4, .45];
  const mk = f => { const g = new Geo(); f(g); return new Mesh(r, g); };
  const P = {
    torso: mk(g => { g.box(0, .1, 0, .46, .62, .28, tunic, { jit: .02 }); g.box(0, -.18, 0, .5, .12, .3, trim, { jit: 0 }); g.box(0, .38, 0, .5, .08, .3, trim, { jit: 0 }); g.box(0, 0, -.17, .34, .5, .1, [.45, .3, .15], { jit: .03 }); g.box(.2, -.2, 0, .12, .16, .26, [.45, .3, .15]); }),
    head: mk(g => { g.sph(0, .22, 0, .21, .23, .21, SK, { jit: 0 }); g.sph(0, .3, -.03, .23, .2, .22, hood, { jit: .02 }); g.box(0, .14, .17, .32, .06, .04, hood, { jit: 0 }); g.sph(-.07, .2, .19, .03, .035, .02, [.05, .03, .03], { jit: 0, low: 1 }); g.sph(.07, .2, .19, .03, .035, .02, [.05, .03, .03], { jit: 0, low: 1 }); g.sph(0, .46, -.04, .06, .06, .06, trim, { e: .1 }); }),
    arm: mk(g => { g.box(0, -.22, 0, .15, .44, .15, tunic, { jit: .02 }); g.sph(0, -.48, 0, .09, .09, .09, SK, { jit: 0, low: 1 }); g.box(0, -.04, 0, .17, .1, .17, trim, { jit: 0 }); }),
    leg: mk(g => { g.box(0, -.25, 0, .18, .5, .2, pants, { jit: .02 }); g.box(0, -.55, .04, .2, .12, .3, [.25, .15, .1], { jit: 0 }); }),
    tail: mk(g => { g.box(0, -.15, 0, .16, .3, .04, trim, { sway: 1, jit: 0 }); }),
    lantern: mk(g => { g.box(0, 0, 0, .12, .16, .12, [1, .85, .4], { e: 1.3, jit: 0 }); g.box(0, .11, 0, .15, .04, .15, [.3, .2, .1], { jit: 0 }); }),
  };
  const glow = (() => { const g = new Geo(); g.sph(0, 0, 0, .55, .55, .55, [1, .8, .35], { e: .5, soft: 1, jit: 0 }); return new Mesh(r, g, 'fx'); })();
  const shadow = (() => { const g = new Geo(); const n = 14; for (let i = 0; i < n; i++) { const a = i / n * 6.283, b = (i + 1) / n * 6.283; const base = g.n; g.v.push(0, 0, 0, 0, 1, 0, 0, 0, 0, .5, 0, 0, 0); g.v.push(Math.cos(a) * .5, 0, Math.sin(a) * .5, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0); g.v.push(Math.cos(b) * .5, 0, Math.sin(b) * .5, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0); g.idx.push(base, base + 2, base + 1); g.n += 3; } g.min = [-.5, 0, -.5]; g.max = [.5, 0, .5]; return new Mesh(r, g, 'fx'); })();
  let phase = 0, jumpBlend = 0, climbPh = 0;
  const api = {
    lanternPos: [0, 0, 0],
    update(ch, dt) { phase += ch.speed * dt * 2.1; jumpBlend += ((ch.onGround ? 0 : 1) - jumpBlend) * Math.min(1, dt * 12); if (ch.climbing) climbPh += Math.abs(ch.vy) * dt * 3.5; },
    draw(ch, t) {
      const S = Math.sin, sp = Math.min(1, ch.speed / 6), amp = sp * (ch.speed > 5 ? .95 : .6), ph = phase;
      const bob = ch.onGround && !ch.climbing ? Math.abs(S(ph)) * .07 * sp : 0, idle = S(t * 1.8) * .012;
      const base = [ch.x, ch.y + 1.0 + bob + idle, ch.z]; const lean = ch.climbing ? 0 : sp * .12 + (ch.speed > 5 ? .1 : 0);
      const root = mul(mT(base[0], base[1], base[2]), mRY(ch.yaw), mRX(lean));
      const swing = (o) => S(ph + o) * amp, J = jumpBlend, cl = ch.climbing ? 1 : 0;
      const legA = a => lerp(lerp(swing(a), -.7 + (a ? .4 : 0), J), S(climbPh + a) * .6, cl);
      const armA = a => lerp(lerp(-swing(a) * .9, -2.4 + (a ? .3 : 0), J * .9), -2.6 + S(climbPh + a) * .5, cl);
      const D = (m, M) => r.drawModel(P[m], M);
      D('torso', root); D('head', mul(root, mT(0, .45, 0), mRX(-lean * .5 + S(t * 1.1) * .01)));
      D('leg', mul(root, mT(-.12, -.32, 0), mRX(legA(0)))); D('leg', mul(root, mT(.12, -.32, 0), mRX(legA(Math.PI))));
      D('arm', mul(root, mT(-.32, .32, 0), mRX(armA(Math.PI)), mRZ(.08))); D('arm', mul(root, mT(.32, .32, 0), mRX(J || cl ? armA(0) : -.9 + S(t * 2) * .02), mRZ(-.08)));
      D('tail', mul(root, mT(0, .4, -.2), mRX(.2 + sp * .7 + S(ph * .5) * .1)));
      const lp = mul(root, mT(.34, -.12, .34)); r.drawModel(P.lantern, lp);
      api.lanternPos = [lp[12], lp[13], lp[14]];
    },
    drawFx(ch) { const g = shadow; const h = Math.max(0, ch.y - (ch.groundY ?? ch.y)); const s = 1 / (1 + h * .25); r.drawFx([Object.assign(shadow, { model: mul(mT(ch.x, (ch.groundY ?? ch.y) + .03, ch.z), mS(1.1 * s, 1, 1.1 * s)) })], { shadow: true }); shadow.model = null; r.drawFx([Object.assign(glow, { model: mT(api.lanternPos[0], api.lanternPos[1], api.lanternPos[2]) })]); glow.model = null; },
  };
  return api;
}
