import { clamp, lerp } from './math.js';
export class FollowCam {
  constructor(phys) { this.ph = phys; this.yaw = 0; this.pitch = .35; this.dist = 6.5; this.d = 6.5; this.pos = [0, 5, -6]; this.tgt = [0, 1, 0]; this.minD = 2.5; this.maxD = 11; }
  rotate(dx, dy) { this.yaw -= dx; this.pitch = clamp(this.pitch + dy, -.25, 1.2); }
  update(dt, ch, snap) {
    const k = snap ? 1 : 1 - Math.exp(-9 * dt);
    const tx = ch.x, ty = ch.y + 1.45, tz = ch.z; this.tgt[0] = lerp(this.tgt[0], tx, k); this.tgt[1] = lerp(this.tgt[1], ty, snap ? 1 : 1 - Math.exp(-6 * dt)); this.tgt[2] = lerp(this.tgt[2], tz, k);
    const cp = Math.cos(this.pitch), sp = Math.sin(this.pitch), dir = [Math.sin(this.yaw) * cp, sp, Math.cos(this.yaw) * cp];
    let best = this.dist; // تصادم بسيط: ننقص المسافة حتى تخرج النقطة من التضاريس/الصناديق
    for (let t = 1; t <= 10; t++) { const d = this.dist * t / 10, x = this.tgt[0] - dir[0] * d, y = this.tgt[1] + dir[1] * d, z = this.tgt[2] - dir[2] * d;
      let hit = y < this.ph.terrain(x, z) + .35; if (!hit) for (const b of this.ph.near(x, z, .3)) { if (b.active && b.solid !== false && !b.nocam && x > b.minx - .2 && x < b.maxx + .2 && z > b.minz - .2 && z < b.maxz + .2 && y > b.miny - .2 && y < b.maxy + .2) { hit = true; break; } }
      if (hit) { best = Math.max(this.minD * .5, d - .5); break; } }
    this.d = snap ? best : (best < this.d ? best : lerp(this.d, best, 1 - Math.exp(-3 * dt)));
    this.pos = [this.tgt[0] - dir[0] * this.d, Math.max(this.tgt[1] + dir[1] * this.d, this.ph.terrain(this.tgt[0] - dir[0] * this.d, this.tgt[2] - dir[2] * this.d) + .4), this.tgt[2] - dir[2] * this.d];
  }
}
