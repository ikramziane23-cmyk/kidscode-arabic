// إدخال: لوحة مفاتيح، فأرة (سحب للكاميرا)، لمس (عصا تحكم + سحب كاميرا + أزرار).
export class Input {
  constructor(root) {
    this.keys = {}; this.mx = 0; this.mz = 0; this.run = false; this.jumpP = false; this.actP = false; this.climb = false; this.dragDX = 0; this.dragDY = 0; this.enabled = true; this.touch = false;
    this.joy = { id: null, x: 0, y: 0, ox: 0, oy: 0 }; this.cam = { id: null, x: 0, y: 0 }; this.root = root; this.onMenu = null;
    addEventListener('keydown', e => { if (!this.enabled) return; if (e.target.closest && e.target.closest('input,textarea')) return; this.keys[e.code] = true; if (e.code === 'Space') { this.jumpP = true; e.preventDefault(); } if (e.code === 'KeyE' || e.code === 'Enter') this.actP = true; if (e.code === 'Escape' || e.code === 'KeyM') this.onMenu && this.onMenu(); });
    addEventListener('keyup', e => { this.keys[e.code] = false; }); addEventListener('blur', () => { this.keys = {}; });
    const c = root; let md = false, lx = 0, ly = 0;
    c.addEventListener('mousedown', e => { md = true; lx = e.clientX; ly = e.clientY; }); addEventListener('mouseup', () => md = false);
    addEventListener('mousemove', e => { if (md && this.enabled) { this.dragDX += (e.clientX - lx) * .006; this.dragDY += (e.clientY - ly) * .005; lx = e.clientX; ly = e.clientY; } });
    c.addEventListener('wheel', e => { this.wheel = (this.wheel || 0) + e.deltaY * .004; e.preventDefault(); }, { passive: false });
    c.addEventListener('touchstart', e => this._ts(e), { passive: false }); c.addEventListener('touchmove', e => this._tm(e), { passive: false }); c.addEventListener('touchend', e => this._te(e)); c.addEventListener('touchcancel', e => this._te(e));
  }
  _ts(e) { this.touch = true; e.preventDefault(); if (!this.enabled) return; const W = this.root.clientWidth; for (const t of e.changedTouches) { if (t.clientX < W * .5 && this.joy.id === null) { this.joy = { id: t.identifier, ox: t.clientX, oy: t.clientY, x: 0, y: 0 }; this.onJoy && this.onJoy(this.joy, true); } else if (this.cam.id === null) { this.cam = { id: t.identifier, x: t.clientX, y: t.clientY }; } } }
  _tm(e) { e.preventDefault(); for (const t of e.changedTouches) { if (t.identifier === this.joy.id) { let dx = t.clientX - this.joy.ox, dy = t.clientY - this.joy.oy; const m = 55, l = Math.hypot(dx, dy); if (l > m) { dx = dx / l * m; dy = dy / l * m; } this.joy.x = dx / m; this.joy.y = dy / m; this.onJoy && this.onJoy(this.joy, true); } else if (t.identifier === this.cam.id) { this.dragDX += (t.clientX - this.cam.x) * .008; this.dragDY += (t.clientY - this.cam.y) * .006; this.cam.x = t.clientX; this.cam.y = t.clientY; } } }
  _te(e) { for (const t of e.changedTouches) { if (t.identifier === this.joy.id) { this.joy = { id: null, x: 0, y: 0, ox: 0, oy: 0 }; this.onJoy && this.onJoy(this.joy, false); } if (t.identifier === this.cam.id) this.cam.id = null; } }
  /** يعيد اتجاه الحركة بالنسبة للكاميرا (yaw) */
  poll(camYaw) {
    const k = this.keys; let fx = (k.KeyD || k.ArrowRight ? 1 : 0) - (k.KeyA || k.ArrowLeft ? 1 : 0), fz = (k.KeyW || k.ArrowUp ? 1 : 0) - (k.KeyS || k.ArrowDown ? 1 : 0);
    if (this.joy.id !== null) { fx += this.joy.x; fz += -this.joy.y; }
    const l = Math.hypot(fx, fz); if (l > 1) { fx /= l; fz /= l; }
    const s = Math.sin(camYaw), c = Math.cos(camYaw); // الكاميرا تنظر نحو (sin,cos)
    this.mx = fz * s - fx * c; this.mz = fz * c + fx * s;
    this.run = !!(k.ShiftLeft || k.ShiftRight) || (this.joy.id !== null && Math.hypot(this.joy.x, this.joy.y) > .85);
    this.climb = !!(k.KeyW || k.ArrowUp || (this.joy.id !== null && this.joy.y < -.3));
    const o = { mx: this.mx, mz: this.mz, run: this.run, jump: this.jumpP, act: this.actP, climb: this.climb, dx: this.dragDX, dy: this.dragDY, wheel: this.wheel || 0 };
    this.jumpP = false; this.actP = false; this.dragDX = this.dragDY = 0; this.wheel = 0;
    if (k.KeyQ) o.dx -= .03; if (k.KeyZ || k.KeyR) o.dx += .03; return o;
  }
}
