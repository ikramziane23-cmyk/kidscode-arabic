// رياضيات 3D مصغّرة: مصفوفات 4x4 (عمودية الترتيب كما في WebGL) ومتجهات.
export const mat4 = () => { const m = new Float32Array(16); m[0] = m[5] = m[10] = m[15] = 1; return m; };
export function identity(o) { o.fill(0); o[0] = o[5] = o[10] = o[15] = 1; return o; }
export function multiply(o, a, b) {
  const a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3], a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7],
    a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11], a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15];
  for (let i = 0; i < 4; i++) {
    const b0 = b[i * 4], b1 = b[i * 4 + 1], b2 = b[i * 4 + 2], b3 = b[i * 4 + 3];
    o[i * 4] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
    o[i * 4 + 1] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
    o[i * 4 + 2] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
    o[i * 4 + 3] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
  }
  return o;
}
export function perspective(o, fovy, aspect, near, far) {
  const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
  o.fill(0); o[0] = f / aspect; o[5] = f; o[10] = (far + near) * nf; o[11] = -1; o[14] = 2 * far * near * nf; return o;
}
export function lookAt(o, e, t, up) {
  let zx = e[0] - t[0], zy = e[1] - t[1], zz = e[2] - t[2]; let l = Math.hypot(zx, zy, zz) || 1; zx /= l; zy /= l; zz /= l;
  let xx = up[1] * zz - up[2] * zy, xy = up[2] * zx - up[0] * zz, xz = up[0] * zy - up[1] * zx; l = Math.hypot(xx, xy, xz) || 1; xx /= l; xy /= l; xz /= l;
  const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
  o[0] = xx; o[1] = yx; o[2] = zx; o[3] = 0; o[4] = xy; o[5] = yy; o[6] = zy; o[7] = 0; o[8] = xz; o[9] = yz; o[10] = zz; o[11] = 0;
  o[12] = -(xx * e[0] + xy * e[1] + xz * e[2]); o[13] = -(yx * e[0] + yy * e[1] + yz * e[2]); o[14] = -(zx * e[0] + zy * e[1] + zz * e[2]); o[15] = 1; return o;
}
export const mT = (x, y, z) => { const m = mat4(); m[12] = x; m[13] = y; m[14] = z; return m; };
export const mS = (x, y, z) => { const m = mat4(); m[0] = x; m[5] = y; m[10] = z; return m; };
export const mRX = a => { const m = mat4(), c = Math.cos(a), s = Math.sin(a); m[5] = c; m[6] = s; m[9] = -s; m[10] = c; return m; };
export const mRY = a => { const m = mat4(), c = Math.cos(a), s = Math.sin(a); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; return m; };
export const mRZ = a => { const m = mat4(), c = Math.cos(a), s = Math.sin(a); m[0] = c; m[1] = s; m[4] = -s; m[5] = c; return m; };
export function mul(...ms) { let r = ms[0]; for (let i = 1; i < ms.length; i++) r = multiply(mat4(), r, ms[i]); return r; }
/** T * Ry * Rx * Rz * S */
export function trs(p, ry = 0, rx = 0, rz = 0, s = [1, 1, 1]) { return mul(mT(p[0], p[1], p[2]), mRY(ry), mRX(rx), mRZ(rz), mS(s[0], s[1], s[2])); }
export function xform(m, x, y, z) { return [m[0] * x + m[4] * y + m[8] * z + m[12], m[1] * x + m[5] * y + m[9] * z + m[13], m[2] * x + m[6] * y + m[10] * z + m[14]]; }
export const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
export const lerp = (a, b, t) => a + (b - a) * t;
export const smooth = (a, b, t) => { const x = clamp((t - a) / (b - a), 0, 1); return x * x * (3 - 2 * x); };
export function lerpAngle(a, b, t) { let d = ((b - a + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI; return a + d * t; }
// مولّد عشوائي ثابت لبناء العوالم بشكل متكرر
export function rng(seed) { let s = seed >>> 0 || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }
export function hexColor(h) { return [((h >> 16) & 255) / 255, ((h >> 8) & 255) / 255, (h & 255) / 255]; }
// أطر المستوى للقص (Frustum)
export function frustumPlanes(m) {
  const p = [];
  const r0 = [m[0], m[4], m[8], m[12]], r1 = [m[1], m[5], m[9], m[13]], r2 = [m[2], m[6], m[10], m[14]], r3 = [m[3], m[7], m[11], m[15]];
  const add = (a, s) => [r3[0] + s * a[0], r3[1] + s * a[1], r3[2] + s * a[2], r3[3] + s * a[3]];
  for (const pl of [add(r0, 1), add(r0, -1), add(r1, 1), add(r1, -1), add(r2, 1), add(r2, -1)]) {
    const l = Math.hypot(pl[0], pl[1], pl[2]) || 1; p.push([pl[0] / l, pl[1] / l, pl[2] / l, pl[3] / l]);
  }
  return p;
}
export function sphereVisible(planes, c, r) { for (const p of planes) if (p[0] * c[0] + p[1] * c[1] + p[2] * c[2] + p[3] < -r) return false; return true; }
