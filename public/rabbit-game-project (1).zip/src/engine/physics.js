// فيزياء حركية: محرّك شخصية (كبسولة) مقابل صناديق AABB وتضاريس، مع منصات متحركة وأرضيات هشّة ومناطق تسلّق.
import { clamp } from './math.js';
const CELL = 4;
export class Physics {
  constructor() { this.boxes = []; this.grid = new Map(); this.terrain = () => 0; this.killY = -30; this.climbs = []; this.waterY = -99; this.waterZones = []; }
  addBox(b) { b.active = b.active !== false; this.boxes.push(b); this._index(b); return b; }
  _keys(b) { const k = []; for (let x = Math.floor(b.minx / CELL); x <= Math.floor(b.maxx / CELL); x++) for (let z = Math.floor(b.minz / CELL); z <= Math.floor(b.maxz / CELL); z++) k.push(x + ',' + z); return k; }
  _index(b) { for (const k of this._keys(b)) { let a = this.grid.get(k); if (!a) this.grid.set(k, a = []); a.push(b); } }
  reindex(b) { for (const [, a] of this.grid) { const i = a.indexOf(b); if (i >= 0) a.splice(i, 1); } this._index(b); }
  near(x, z, r) { const out = new Set(); for (let i = Math.floor((x - r) / CELL); i <= Math.floor((x + r) / CELL); i++) for (let j = Math.floor((z - r) / CELL); j <= Math.floor((z + r) / CELL); j++) { const a = this.grid.get(i + ',' + j); if (a) for (const b of a) out.add(b); } return out; }
  box(cx, cy, cz, sx, sy, sz, o = {}) { return this.addBox({ minx: cx - sx / 2, maxx: cx + sx / 2, miny: cy - sy / 2, maxy: cy + sy / 2, minz: cz - sz / 2, maxz: cz + sz / 2, ...o }); }
  groundAt(x, z, y, step, r = .25) {
    let g = this.terrain(x, z), on = null;
    for (const b of this.near(x, z, r)) { if (!b.active || b.solid === false || b.nowalk) continue; if (x > b.minx - r && x < b.maxx + r && z > b.minz - r && z < b.maxz + r && b.maxy <= y + step && b.maxy > g) { g = b.maxy; on = b; } }
    return { y: g, box: on };
  }
}
export class Character {
  constructor(phys) {
    this.ph = phys; this.x = 0; this.y = 0; this.z = 0; this.vx = 0; this.vy = 0; this.vz = 0; this.r = .35; this.h = 1.6; this.yaw = 0;
    this.onGround = false; this.coyote = 0; this.jumpBuf = 0; this.climbing = false; this.speed = 0; this.ground = null; this.swim = 0; this.checkpoint = [0, 5, 0]; this.fall = 0;
    this.walk = 3.6; this.run = 6.4; this.jump = 7.6; this.events = [];
  }
  teleport(x, y, z) { this.x = x; this.y = y; this.z = z; this.vx = this.vy = this.vz = 0; }
  update(dt, mx, mz, run, jumpPressed, wantClimb) {
    dt = Math.min(dt, .05); const ph = this.ph;
    // كشف التسلق
    let zone = null; for (const c of ph.climbs) if (this.x > c.minx - .5 && this.x < c.maxx + .5 && this.z > c.minz - .5 && this.z < c.maxz + .5 && this.y < c.maxy) { zone = c; break; }
    this.climbing = !!zone && (wantClimb || this.climbing) && this.y < zone.maxy;
    if (this.climbing) { this.vy = (mz < -.1 || jumpPressed ? 3.2 : mz > .1 ? -3 : 0); this.y += this.vy * dt; if (this.y >= zone.maxy - .1 && zone.exit) { this.x = zone.exit[0]; this.z = zone.exit[1]; this.y = zone.maxy + .05; this.climbing = false; } this.speed = 0; this.vx = this.vz = 0; this.onGround = false; return; }
    const g = ph.groundAt(this.x, this.z, this.y, .6, this.r * .7);
    const wet = g.y < ph.waterY - .25 && this.y < ph.waterY; this.swim = wet ? 1 : 0;
    const sp = (run ? this.run : this.walk) * (wet ? .6 : 1), len = Math.hypot(mx, mz), k = Math.min(1, len);
    const tx = len > .01 ? mx / len * sp * k : 0, tz = len > .01 ? mz / len * sp * k : 0, acc = this.onGround ? 14 : 5;
    this.vx += (tx - this.vx) * Math.min(1, acc * dt); this.vz += (tz - this.vz) * Math.min(1, acc * dt);
    if (len > .1) this.yaw = Math.atan2(tx, tz) ; this.speed = Math.hypot(this.vx, this.vz);
    // حركة أفقية مع تصادم
    let nx = this.x + this.vx * dt, nz = this.z + this.vz * dt;
    const stepUp = this.onGround ? .6 : .25;
    for (const b of ph.near(nx, nz, this.r + 1)) {
      if (!b.active || b.solid === false) continue;
      if (b.maxy <= this.y + stepUp || b.miny >= this.y + this.h) continue;
      const cx = clamp(nx, b.minx, b.maxx), cz = clamp(nz, b.minz, b.maxz); let dx = nx - cx, dz = nz - cz, d = Math.hypot(dx, dz);
      if (d < this.r) {
        if (d < 1e-4) { const l = nx - b.minx, rr = b.maxx - nx, f = nz - b.minz, bk = b.maxz - nz, m = Math.min(l, rr, f, bk); if (m === l) nx = b.minx - this.r; else if (m === rr) nx = b.maxx + this.r; else if (m === f) nz = b.minz - this.r; else nz = b.maxz + this.r; }
        else { nx = cx + dx / d * this.r; nz = cz + dz / d * this.r; }
      }
    }
    { const md = Math.hypot(nx - this.x, nz - this.z); if (md > 1e-5) { const slope = (ph.terrain(nx, nz) - ph.terrain(this.x, this.z)) / md; if (slope > 1.15 && (this.onGround || this.y < ph.terrain(nx, nz) - .3)) { nx = this.x; nz = this.z; this.vx *= .2; this.vz *= .2; } } }
    this.x = nx; this.z = nz;
    // قفز
    this.coyote = this.onGround ? .12 : this.coyote - dt; this.jumpBuf = jumpPressed ? .13 : this.jumpBuf - dt;
    if (this.jumpBuf > 0 && this.coyote > 0) { this.vy = this.jump; this.onGround = false; this.coyote = 0; this.jumpBuf = 0; this.events.push('jump'); }
    this.vy -= 22 * dt; if (wet && this.vy < -3) this.vy = -3;
    const ny = this.y + this.vy * dt; const gg = ph.groundAt(this.x, this.z, Math.max(this.y, ny) , .6, this.r * .7);
    // سقف
    for (const b of ph.near(this.x, this.z, this.r)) { if (!b.active || b.solid === false) continue; if (this.vy > 0 && b.miny >= this.y + this.h - .1 && b.miny < ny + this.h && this.x > b.minx - this.r && this.x < b.maxx + this.r && this.z > b.minz - this.r && this.z < b.maxz + this.r) { this.vy = 0; } }
    const wasAir = !this.onGround;
    if (this.vy <= 0 && ny <= gg.y + .02) { if (wasAir && this.fall < -9) this.events.push('land'); this.y = gg.y; this.vy = 0; this.onGround = true; this.fall = 0;
      if (gg.box !== this.ground) { this.ground = gg.box; if (gg.box && gg.box.onStand) gg.box.onStand(gg.box); } if (gg.box && gg.box.checkpoint) this.checkpoint = gg.box.checkpoint; }
    else { this.y = ny; this.onGround = false; this.ground = null; this.fall = this.vy; }
    if (this.ground && this.ground.dx !== undefined) { this.x += this.ground.dx; this.z += this.ground.dz; this.y = this.ground.maxy; }
    if (this.y < ph.killY) { this.respawn(); this.events.push('respawn'); }
  }
  respawn() { const c = this.checkpoint; this.teleport(c[0], c[1] + .3, c[2]); }
}
