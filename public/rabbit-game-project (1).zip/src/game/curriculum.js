// المنهج: يُشتق من manifest الصوتي (لا تُعرض سورة بلا تسجيل) — وحدات ≤4 آيات، ثم مناطق (مراحل) من 5 بوابات.
// الترتيب من الأقصر/الأسهل إلى الأطول. السور ذات الثقة المنخفضة (risky) تُستبعد حتى تُعتمَد بعد المراجعة.
export const ORDER = [114, 113, 112, 111, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101, 100, 99, 98, 97, 96, 95, 94, 87, 86, 85, 89, 88, 78];
export const JUZ = Array.from({ length: 37 }, (_, i) => 78 + i);
export const ICON = { 114: '🛡️', 113: '🌅', 112: '💛', 111: '🔥', 110: '🏆', 109: '🕊️', 108: '🌊', 107: '🤲', 106: '🐪', 105: '🐘', 104: '🔍', 103: '⏳', 102: '🌱', 101: '🔔', 100: '🐎', 99: '🌍', 98: '📖', 97: '🌙', 96: '📜', 95: '🫒', 94: '💖', 87: '⭐', 86: '✨', 85: '🌌', 89: '🌄', 88: '☁️', 78: '📰' };
const AP = 'ikram-rabbit.approved';
export const approved = () => { try { return JSON.parse(localStorage.getItem(AP) || '[]'); } catch (e) { return []; } };
export const setApproved = (n, on) => { const a = new Set(approved()); on ? a.add(n) : a.delete(n); try { localStorage.setItem(AP, JSON.stringify([...a])); } catch (e) { } };
export function splitUnits(cnt, max = 4) { const k = Math.ceil(cnt / max), base = Math.floor(cnt / k), extra = cnt % k, out = []; let s = 0; for (let i = 0; i < k; i++) { const len = base + (i < extra ? 1 : 0); out.push([s, s + len - 1]); s += len; } return out; }
export function curriculum(man, opts = {}) {
  const ap = new Set(opts.approved || approved()), S = man.surahs, units = [], skipped = [], missing = [];
  const list = ORDER.filter(n => S[n]).concat(Object.keys(S).map(Number).filter(n => !ORDER.includes(n)).sort((a, b) => b - a));
  for (const n of list) { const s = S[n]; if (!s || !s.file || !s.segs) continue; if (s.risky && !ap.has(n)) { skipped.push(n); continue; } const us = splitUnits(s.segs.length); us.forEach(([from, to], k) => units.push({ id: n + ':' + from, surah: n, from, to, k, of: us.length, icon: ICON[n] || '📖' })); }
  for (const n of JUZ) if (!S[n]) missing.push(n);
  const per = opts.perZone || 5, nz = Math.max(1, Math.ceil(units.length / per)), zones = []; let i = 0;
  for (let z = 0; z < nz; z++) { const take = Math.round((units.length - i) / (nz - z)); zones.push({ idx: z, gates: units.slice(i, i + take), last: z === nz - 1 }); i += take; }
  return { units, zones, skipped, missing, surahs: list.filter(n => !skipped.includes(n)) };
}
