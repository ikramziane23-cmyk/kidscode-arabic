// تجربة البوابة: اسم السورة (صوت) ← استماع للتلاوة ← تكرار ← تحدٍّ صوتي ← مكافأة.
// لا انتقال تلقائي بين المراحل: كل مرحلة تنتظر فعلًا من الطفل (أو المعلمة).
import { SAY } from './voice.js';
export function h(tag, a = {}, ...kids) { const e = document.createElement(tag); for (const k in a) { if (k.startsWith('on')) e.addEventListener(k.slice(2), a[k]); else if (k === 'class') e.className = a[k]; else e.setAttribute(k, a[k]); } for (const c of kids.flat()) if (c != null) e.append(c.nodeType ? c : document.createTextNode(c)); return e; }
const PAIRS = [['🐥', '🐢'], ['🌙', '☀️'], ['🍎', '🍌'], ['🦋', '🐞']];
import { ICON as SURAH_ICON } from './curriculum.js';
const wait = ms => new Promise(r => setTimeout(r, ms));
export class GateSession {
  constructor(c) { this.c = c; this.el = c.root; this.tok = 0; this.stage = null; this.n = 0; this.on = false; this.oral = false; }
  get QA() { return this.c.QA; } get V() { return this.c.Voice; }
  open(n, from = 0, to = null, o = {}) {
    const cnt = this.QA.count(n); this.n = n; this.from = from; this.to = to == null ? cnt - 1 : Math.min(to, cnt - 1); this.on = true; this.oral = !!o.oral; this.unit = o.unit || null; this.review = o.review || null; this.c.onOpen && this.c.onOpen(); this.el.classList.add('on');
    this.q = { done: 0, firstTry: 0, total: 0 }; this.go(this.review ? 'quiz' : (o.stage || 'intro'));
  }
  close(reason) { this.tok++; this.QA.stop(); this.V.stop(); this.on = false; this.el.classList.remove('on'); this.el.innerHTML = ''; this.stage = null; this.c.onClose && this.c.onClose(reason); }
  stopAll() { this.tok++; this.QA.stop(); this.V.stop(); }
  go(stage) { this.stopAll(); this.stage = stage; this.c.sfx && this.c.sfx('ui'); this['_' + stage](); this.c.onStage && this.c.onStage(stage); }
  _frame(title, body, foot) { const sn = this.c.Q.surahs[this.n - 1].name; const ttl = this.review ? '🔁 مراجعة' : h('span', {}, h('span', { class: 'gicon' }, SURAH_ICON[this.n] || '📖'), ' سورة ' + sn + (this.unit && this.unit.of > 1 ? ' ' + (this.unit.k + 1) + '/' + this.unit.of : '')); this.el.innerHTML = ''; this.el.append(h('div', { class: 'gpanel' }, h('div', { class: 'ghead' }, h('button', { class: 'bx', 'aria-label': 'إغلاق', onclick: () => this.close('x') }, '✖'), h('div', { class: 'gtitle' }, ttl), h('div', { class: 'steps' }, ...['intro', 'listen', 'repeat', 'quiz', 'reward'].map(s => h('i', { class: s === this.stage ? 'on' : '' })))), h('div', { class: 'gbody' }, body), h('div', { class: 'gfoot' }, foot))); }
  text(i) { return this.c.Q.surahs[this.n - 1].ayat[i]; }
  // ---------- مقدّمة ----------
  _intro() {
    const sn = this.c.Q.surahs[this.n - 1].name, say = () => this.V.say('سورة ' + sn, 'surah_' + this.n);
    this._frame('', [h('div', { class: 'bigicon' }, SURAH_ICON[this.n] || '📖'), h('div', { class: 'sname q' }, 'سورة ' + sn), h('button', { class: 'bb snd', id: 'bName', onclick: say, 'aria-label': 'اسمع الاسم' }, '🔊')],
      [h('button', { class: 'bb go', id: 'bGo', onclick: () => this.go('listen') }, '▶  هيا نستمع')]);
    const t = ++this.tok; setTimeout(() => { if (t === this.tok) say(); }, 350);
  }
  // ---------- استماع ----------
  _listen() {
    const S = { playing: false, heard: false, cur: -1 }; this.S = S; const dots = [];
    for (let i = this.from; i <= this.to; i++) dots.push(h('i', { class: 'dot', 'data-i': i }));
    const txt = h('div', { class: 'ayah q', id: 'ayahText' }, '🎧'), play = h('button', { class: 'bb snd big', id: 'bPlay', 'aria-label': 'تشغيل' }, '▶'), next = h('button', { class: 'bb go', id: 'bNext', disabled: '', onclick: () => this.go('repeat') }, '➡  هيا نكرّر');
    const lit = i => { S.cur = i; dots.forEach((d, k) => d.classList.toggle('on', this.from + k === i)); txt.textContent = this.text(i); };
    const run = async () => { const my = ++this.tok; S.playing = true; play.textContent = '⏸'; const r = await this.QA.playRange(this.n, this.from, this.to, i => { if (my === this.tok) lit(i); }); if (my !== this.tok) return; S.playing = false; play.textContent = '🔁'; if (r === 'ended') { S.heard = true; next.removeAttribute('disabled'); next.classList.add('pulse'); this.c.P.note(this.n, 'listens'); this.V.say(SAY.again); } };
    play.onclick = () => { if (S.playing && !this.QA.paused) { this.QA.pause(); play.textContent = '▶'; } else if (S.playing && this.QA.paused) { this.QA.resume(); play.textContent = '⏸'; } else run(); };
    this._frame('', [h('div', { class: 'dots' }, dots), txt, h('div', { class: 'row' }, play, h('button', { class: 'bb alt', id: 'bAgain', 'aria-label': 'من البداية', onclick: () => run() }, '🔁'))], [next]);
    this.listenAPI = { run, S };
    const t = this.tok; this.V.say(SAY.listen).then(() => { if (t === this.tok) { /* لا تشغيل تلقائي للتلاوة: الطفل/المعلمة يضغط */ } });
  }
  // ---------- تكرار ----------
  _repeat() {
    let i = this.from; const dots = []; for (let k = this.from; k <= this.to; k++) dots.push(h('i', { class: 'dot', 'data-i': k }));
    const txt = h('div', { class: 'ayah q' }), mic = h('button', { class: 'bb mic', id: 'bMic', disabled: '', 'aria-label': 'كرّرت' }, '🎤'), hear = h('button', { class: 'bb snd', id: 'bHear', 'aria-label': 'اسمع' }, '🔊');
    const step = async () => { const my = ++this.tok; dots.forEach((d, k) => d.classList.toggle('on', this.from + k === i)); txt.textContent = this.text(i); mic.setAttribute('disabled', ''); mic.classList.remove('pulse'); const r = await this.QA.play(this.n, i); if (my !== this.tok || r === 'stopped') return; await this.V.say(SAY.yourturn); if (my !== this.tok) return; mic.removeAttribute('disabled'); mic.classList.add('pulse'); };
    hear.onclick = () => step();
    mic.onclick = () => { if (mic.hasAttribute('disabled')) return; this.c.P.note(this.n, 'repeats'); this.c.cheer && this.c.cheer(1.2); this.c.sfx && this.c.sfx('ok'); this.c.confetti && this.c.confetti(10); if (i < this.to) { i++; step(); } else { this.go('quiz'); } };
    this._frame('', [h('div', { class: 'dots' }, dots), txt, h('div', { class: 'row' }, hear, mic)], []);
    { const t0 = this.tok; this.V.say(SAY.repeat).then(() => { if (t0 === this.tok) step(); }); }
  }
  // ---------- تحدٍّ صوتي ----------
  _buildReview() {
    const R = a => a[(Math.random() * a.length) | 0], Q = [], pool = this.review.slice(); while (Q.length < 3 && pool.length) { const u = pool.splice((Math.random() * pool.length) | 0, 1)[0], others = this.review.filter(x => x !== u), oth = others.length ? R(others) : null, i = u.from + ((Math.random() * (u.to - u.from + 1)) | 0), j = oth ? oth.from + ((Math.random() * (oth.to - oth.from + 1)) | 0) : null;
      if (i < u.to && Math.random() < .6) Q.push({ t: 'next', p: [u.surah, i], ok: [u.surah, i + 1], bad: oth ? [oth.surah, j] : null }); else Q.push({ t: 'same', p: [u.surah, i], ok: [u.surah, i], bad: oth ? [oth.surah, j] : (u.to > u.from ? [u.surah, i === u.from ? i + 1 : i - 1] : null) }); }
    return Q.filter(q => q.bad && !(q.bad[0] === q.ok[0] && q.bad[1] === q.ok[1]));
  }
  _build() {
    if (this.review) return this._buildReview();
    const n = this.n, pool = Object.keys(this.c.QA.man.surahs).map(Number).filter(s => s !== n && this.QA.has(s) && !this.QA.meta(s).risky), Q = [], R = a => a[(Math.random() * a.length) | 0];
    const dis = () => { const s = pool.length ? R(pool) : null; return s ? [s, R([...Array(this.QA.count(s)).keys()])] : null; };
    for (let i = this.from; i < this.to && Q.length < 2; i++) Q.push({ t: 'next', p: [n, i], ok: [n, i + 1], bad: dis() || [n, i] });
    const others = []; for (let i = this.from; i <= this.to; i++) if (i !== this.to) others.push([n, i]);
    Q.push({ t: 'same', p: [n, this.to], ok: [n, this.to], bad: others.length ? R(others) : dis() });
    return Q.filter(q => q.bad && !(q.bad[0] === q.ok[0] && q.bad[1] === q.ok[1]));
  }
  _quiz() { this.Qs = this._build(); this.qi = 0; this.q = { done: 0, firstTry: 0, total: this.Qs.length }; this._ask(); }
  async _ask() {
    const q = this.Qs[this.qi], my = ++this.tok, pair = PAIRS[(Math.random() * PAIRS.length) | 0], flip = Math.random() < .5; let tries = 0, sel = null;
    const opts = [{ c: q.ok, ok: true, icon: pair[0] }, { c: q.bad, ok: false, icon: pair[1] }]; if (flip) opts.reverse();
    const cards = opts.map((o, k) => { const ok = h('button', { class: 'bb go chk', 'aria-label': 'اختر', disabled: '' }, '✔'); const card = h('div', { class: 'opt', 'data-ok': o.ok ? 1 : 0 }, h('button', { class: 'ocard', 'aria-label': 'استمع', onclick: async () => { sel = o; cards.forEach(c => c.classList.remove('sel')); card.classList.add('sel'); cards.forEach(c => c.querySelector('.chk').setAttribute('disabled', '')); ok.removeAttribute('disabled'); await this.QA.play(o.c[0], o.c[1]); } }, h('span', { class: 'oi' }, this.oral ? (k + 1 === 1 ? '١' : '٢') : o.icon), h('span', { class: 'sp' }, '🔊')), ok); ok.onclick = () => answer(o, card); return card; });
    const prompt = h('button', { class: 'bb snd big', id: 'bQ', 'aria-label': 'استمع للسؤال', onclick: () => ask1() }, '🔊'), msg = h('div', { class: 'msg', id: 'msg' }, '');
    const ask1 = async () => { const m = ++this.tok; await this.QA.play(q.p[0], q.p[1]); if (m !== this.tok) return; await this.V.say(q.t === 'next' ? SAY.next : SAY.same); };
    const answer = async (o, card) => {
      this.QA.stop(); if (o.ok) { const first = tries === 0; this.c.P.note(this.n, 'correct'); this.qFirst = (this.qFirst || 0) + (first ? 1 : 0); card.classList.add('good'); this.c.cheer && this.c.cheer(1.6); this.c.sfx && this.c.sfx('ok'); this.c.confetti && this.c.confetti(14); this.c.stars && this.c.stars(first ? 2 : 1); this.q.done++; this.q.firstTry += first ? 1 : 0; msg.textContent = '⭐'.repeat(first ? 2 : 1); const m = ++this.tok; await this.V.say(this.V.pick(SAY.good)); if (m !== this.tok) return; this.qi++; if (this.qi < this.Qs.length) this._ask(); else this.go('reward'); }
      else { tries++; this.c.P.note(this.n, 'wrong'); card.classList.add('soft'); msg.textContent = '🌸'; this.c.sfx && this.c.sfx('try'); const m = ++this.tok; cards.forEach(c => c.querySelector('.chk').setAttribute('disabled', '')); await this.V.say(this.V.pick(SAY.retry)); if (m !== this.tok) return; card.classList.remove('soft', 'sel'); if (tries >= 2) { const good = cards.find(c => c.dataset.ok === '1'); good.classList.add('hint'); await this.V.say(SAY.hint); if (m !== this.tok) return; const co = opts.find(x => x.ok); await this.QA.play(co.c[0], co.c[1]); } else await ask1(); }
    };
    this._frame('', [h('div', { class: 'qprog' }, ...this.Qs.map((_, k) => h('i', { class: 'dot' + (k < this.qi ? ' on' : k === this.qi ? ' cur' : '') }))), h('div', { class: 'row' }, prompt), h('div', { class: 'opts' }, cards), msg], []);
    this.c.P.note(this.n, 'tries'); setTimeout(() => { if (my === this.tok) ask1(); }, 400);
  }
  // ---------- مكافأة ----------
  _reward() {
    const stars = this.q.total && this.q.firstTry === this.q.total ? 3 : (this.q.firstTry * 2 >= this.q.total ? 2 : 1); if (!this.review) { this.c.P.complete(this.n, stars); } this.c.onComplete && this.c.onComplete(this.unit, stars, !!this.review);
    this._frame('', [h('div', { class: 'bigstars' }, ...[1, 2, 3].map(k => h('span', { class: 'st' + (k <= stars ? ' on' : '') }, '⭐'))), h('div', { class: 'bigicon' }, '💎'), h('div', { class: 'msg' }, '')], [h('button', { class: 'bb go', id: 'bFinish', onclick: () => this.close('done') }, '✔')]);
    this.c.confetti && this.c.confetti(60); this.c.cheer && this.c.cheer(3); this.c.sfx && this.c.sfx('crystal'); this.V.say(SAY.done);
  }
}
