// أدوات بناء العوالم: ضجيج، مُنشئ العالم (قطع ثابتة + فيزياء + أضواء + جسيمات)، ومجسّمات جاهزة (أشجار، حجارة، أعمدة، أقواس، أبواب...).
import { Geo } from '../engine/geo.js';
import { Mesh } from '../engine/gl.js';
import { mul, mT, mRY, mRX, mRZ, mS, rng, clamp, lerp, smooth } from '../engine/math.js';

const hash2 = (x, y) => { let h = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
export function noise(x, z) { const xi = Math.floor(x), zi = Math.floor(z), xf = x - xi, zf = z - zi, u = xf * xf * (3 - 2 * xf), v = zf * zf * (3 - 2 * zf); return lerp(lerp(hash2(xi, zi), hash2(xi + 1, zi), u), lerp(hash2(xi, zi + 1), hash2(xi + 1, zi + 1), u), v); }
export const fbm = (x, z, o = 4) => { let a = .5, s = 0, f = 1; for (let i = 0; i < o; i++) { s += a * noise(x * f, z * f); f *= 2; a *= .5; } return s; };
export const mix3 = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

export class WorldBuilder {
  constructor(r, phys, size = 32) {
    this.r = r; this.ph = phys; this.size = size; this.chunks = new Map(); this.fxGeo = new Geo(); this.waterMeshes = []; this.lights = []; this.parts = []; this.items = []; this.dyn = []; this.rand = rng(7); this.updaters = []; this.fxChunks = new Map();
  }
  G(x, z) { const k = Math.floor(x / this.size) + ',' + Math.floor(z / this.size); let g = this.chunks.get(k); if (!g) { g = new Geo(); g.rand = 99 + this.chunks.size * 31; this.chunks.set(k, g); } return g; }
  FX(x, z) { const k = Math.floor(x / 48) + ',' + Math.floor(z / 48); let g = this.fxChunks.get(k); if (!g) { g = new Geo(); this.fxChunks.set(k, g); } return g; }
  /** تضاريس بقطع */
  terrain(x0, z0, w, d, hf, colf, step = 2) { const s = this.size; for (let cx = x0; cx < x0 + w; cx += s) for (let cz = z0; cz < z0 + d; cz += s) { const g = this.G(cx + 1, cz + 1); g.terrain(cx, cz, s, s, Math.round(s / step), Math.round(s / step), hf, colf); } this.ph.terrain = hf; }
  light(x, y, z, r, c, i = 1, flick = 0) { const l = { x, y, z, r, c, i, flick }; this.lights.push(l); return l; }
  /** جسيمات: kind 0 يراعات، 1 جمر/غبار صاعد، 2 ساقط */
  particles(list) { this.parts.push(...list); }
  scatterParticles(n, x0, z0, w, d, yf, col, size, kind, range = 6, seed = 1) { const R = rng(seed), a = []; for (let i = 0; i < n; i++) { const x = x0 + R() * w, z = z0 + R() * d, c = Array.isArray(col[0]) ? col[Math.floor(R() * col.length)] : col; a.push(x, yf(x, z) + R() * 2, z, size * (.6 + R() * .8), c[0], c[1], c[2], R(), kind); } this.partData = this.partData || []; this.partData.push({ arr: a, range: [0, range, 0] }); }
  dynMesh(fn, kind = 'lit') { const g = new Geo(); fn(g); const m = new Mesh(this.r, g, kind); m.model = mT(0, 0, 0); return m; }
  finish() {
    const lit = [], fx = []; for (const g of this.chunks.values()) if (!g.empty) lit.push(new Mesh(this.r, g));
    for (const g of this.fxChunks.values()) if (!g.empty) fx.push(new Mesh(this.r, g, 'fx'));
    const parts = (this.partData || []).map(p => { const o = this.r.makeParticles(p.arr); o.range = p.range; return o; });
    return { lit, fx, water: this.waterMeshes, parts, lights: this.lights };
  }
  water(x0, z0, w, d, y, flow = [0, 0], nx = 24, nz = 24) { const g = new Geo().grid(x0, z0, w, d, nx, nz, y); const m = new Mesh(this.r, g, 'water'); m.flow = flow; this.waterMeshes.push(m); return m; }
}

// ===== مجسّمات =====
export const C = { stone: [.36, .41, .4], stoneD: [.22, .27, .28], moss: [.12, .34, .2], mossB: [.2, .45, .24], trunk: [.24, .17, .13], bark2: [.17, .12, .1], gold: [.95, .75, .3], teal: [.2, 1, .88], amber: [1, .65, .2], violet: [.62, .4, 1], wood: [.4, .27, .16] };

export function tree(B, x, y, z, s = 1, o = {}) {
  const g = B.G(x, z), R = B.rand, h = (6 + R() * 5) * s, tr = (.45 + R() * .25) * s, col = o.leaf || [.07 + R() * .06, .28 + R() * .12, .2 + R() * .08], tk = o.trunk || C.trunk;
  g.cyl(x, y + h / 2, z, tr * .65, tr, h, tk, { seg: 6, ry: R() * 3 });
  for (let i = 0; i < 4; i++) { const a = i * 1.57 + R(); g.cyl(x + Math.cos(a) * tr * .9, y + .5, z + Math.sin(a) * tr * .9, .1 * s, .32 * s, 1.5 * s, tk, { seg: 4, rz: Math.cos(a) * .6, rx: -Math.sin(a) * .6 }); }
  const n = 3 + (R() * 2 | 0); for (let i = 0; i < n; i++) { const a = R() * 6.28, rr = i ? (1.6 + R() * 1.8) * s : 0; g.sph(x + Math.cos(a) * rr, y + h - 1.2 + i * .7 * s + R() * 1.2, z + Math.sin(a) * rr, (2.4 + R() * 1.4) * s, (1.7 + R()) * s, (2.4 + R() * 1.4) * s, col, { sway: 1.4, jit: .14, grad: .5 }); }
  if (o.vines !== false && R() < .6) for (let i = 0; i < 3; i++) { const a = R() * 6.28, vl = 2 + R() * 3; g.box(x + Math.cos(a) * 2 * s, y + h - 1.5 - vl / 2, z + Math.sin(a) * 2 * s, .08, vl, .08, C.mossB, { sway: 0, e: .04 }); }
  B.ph.box(x, y + h / 2, z, tr * 1.4, h, tr * 1.4, { tag: 'tree' });
}
export function pine(B, x, y, z, s = 1) { const g = B.G(x, z), R = B.rand, h = (7 + R() * 5) * s; g.cyl(x, y + h / 2, z, .22 * s, .4 * s, h, C.bark2, { seg: 5 }); for (let i = 0; i < 5; i++) { const t = i / 5; g.cone(x, y + h * (.35 + t * .6), z, (2.4 - t * 1.7) * s, 2.6 * s, [.05 + R() * .04, .22 + R() * .1, .2], { seg: 6, sway: 1, jit: .1 }); } B.ph.box(x, y + h / 2, z, .8 * s, h, .8 * s); }
export function rock(B, x, y, z, s = 1, col = C.stone, solid = true) { const g = B.G(x, z), R = B.rand; g.sph(x, y + s * .35, z, s * (.9 + R() * .4), s * .7, s * (.8 + R() * .4), col, { low: 1, ry: R() * 3, jit: .12, grad: .3 }); if (solid) B.ph.box(x, y + s * .35, z, s * 1.3, s * .65, s * 1.3, { tag: 'rock' }); }
export function bush(B, x, y, z, s = 1, col = [.08, .32, .18]) { const g = B.G(x, z); g.sph(x, y + .35 * s, z, .8 * s, .5 * s, .8 * s, col, { low: 1, sway: .8, jit: .15 }); }
export function fern(B, x, y, z, s = 1) { const g = B.G(x, z), R = B.rand; for (let i = 0; i < 4; i++) g.cone(x, y + .3 * s, z, .1 * s, .9 * s, [.1, .4 + R() * .15, .22], { seg: 3, rx: (R() - .5) * .9, rz: (R() - .5) * .9, sway: 1.2 }); }
export function mushroom(B, x, y, z, s = 1, col = [.3, .9, .85]) { const g = B.G(x, z); g.cyl(x, y + .15 * s, z, .05 * s, .07 * s, .3 * s, [.8, .85, .8], { seg: 4 }); g.sph(x, y + .32 * s, z, .2 * s, .1 * s, .2 * s, col, { low: 1, e: .6, jit: 0 }); B.light(x, y + .5, z, 3, col, .5); }
export function grassTufts(B, x, z, n, rad, yf, col = [.1, .36, .2]) { const R = B.rand; for (let i = 0; i < n; i++) { const a = R() * 6.28, d = Math.sqrt(R()) * rad, px = x + Math.cos(a) * d, pz = z + Math.sin(a) * d; const g = B.G(px, pz); for (let k = 0; k < 3; k++) g.cone(px + (R() - .5) * .3, yf(px, pz) + .25, pz + (R() - .5) * .3, .06, .55 + R() * .4, mix3(col, [.2, .5, .25], R()), { seg: 3, rx: (R() - .5) * .4, rz: (R() - .5) * .4, sway: 1.3 }); } }
/** عمود نقوش متوهج */
export function runePillar(B, x, y, z, h = 3.2, col = C.teal, lit = true) {
  const g = B.G(x, z); g.box(x, y + .25, z, 1.1, .5, 1.1, C.stoneD); g.box(x, y + h / 2 + .3, z, .8, h - .3, .8, C.stone); g.box(x, y + h + .1, z, 1, .22, 1, C.stoneD);
  const f = B.FX(x, z), e = lit ? .6 : .08; for (let i = 0; i < 4; i++) { const yy = y + 1 + i * (h - 1.4) / 3; f.box(x, yy, z + .41, .36, .08, .02, col, { e, jit: 0 }); f.box(x + .1, yy + .2, z + .41, .08, .3, .02, col, { e, jit: 0 }); }
  B.ph.box(x, y + h / 2, z, 1.1, h, 1.1); if (lit) B.light(x, y + h + .5, z, 7, col, .9, .1);
}
/** قوس حجري */
export function arch(B, x, y, z, w = 5, h = 5, ry = 0, col = C.stone, t = .9) {
  const g = B.G(x, z), c = Math.cos(ry), s = Math.sin(ry), P = (a, b) => [x + a * c + b * s, z - a * s + b * c];
  for (const sx of [-1, 1]) { const [px, pz] = P(sx * (w / 2 + t / 2), 0); g.box(px, y + h / 2, pz, t, h, t * 1.1, col, { ry }); B.ph.box(px, y + h / 2, pz, Math.abs(c) * t + Math.abs(s) * t * 1.1, h, Math.abs(s) * t + Math.abs(c) * t * 1.1); }
  for (let i = 0; i <= 8; i++) { const a = Math.PI * i / 8, ax = Math.cos(a) * (w / 2 + t / 2), ay = Math.sin(a) * (h * .0 + w * .5); const [px, pz] = P(ax, 0); g.box(px, y + h + ay * .9, pz, t * 1.05, t * .9, t * 1.1, col, { ry, rz: 0 }); }
  g.box(...P(0, 0).slice(0, 1), y + h + w * .5 + t * .6, P(0, 0)[1], t * 1.4, t * .8, t * 1.2, C.stoneD, { ry });
}
/** جدار أثري مع طحلب وميدالية دائرية منقوشة */
export function medallionWall(B, x, y, z, w = 7, h = 4.5, ry = 0, col = C.teal) {
  const g = B.G(x, z), f = B.FX(x, z), c = Math.cos(ry), s = Math.sin(ry); g.box(x, y + h / 2, z, w, h, 1.1, C.stone, { ry, grad: .2 }); g.box(x, y + h + .1, z, w + .3, .3, 1.3, C.stoneD, { ry });
  const fz = .62; const px = x + s * fz, pz = z + c * fz;
  g.cyl(px, y + h * .55, pz, 1.2, 1.2, .12, C.stoneD, { seg: 16, rx: Math.PI / 2, ry }); g.cyl(px + s * .06, y + h * .55, pz + c * .06, .95, .95, .08, [.18, .3, .3], { seg: 16, rx: Math.PI / 2, ry });
  for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; const ox = Math.cos(a) * .72, oy = Math.sin(a) * .72; f.box(px + s * .12 + c * ox, y + h * .55 + oy, pz + c * .12 - s * ox, .16, .16, .03, col, { e: .5, ry, jit: 0 }); }
  f.cyl(px + s * .12, y + h * .55, pz + c * .12, .3, .3, .03, col, { seg: 10, rx: Math.PI / 2, ry, e: .8, jit: 0 });
  for (let i = 0; i < 6; i++) g.sph(x + (B.rand() - .5) * w, y + h - B.rand() * 1.4, z + (B.rand() - .5) * .8, .5, .25, .45, C.moss, { low: 1, sway: .5 });
  B.ph.box(x, y + h / 2, z, Math.abs(c) * w + Math.abs(s) * 1.1, h, Math.abs(s) * w + Math.abs(c) * 1.1); B.light(px + s * 1, y + h * .55, pz + c * 1, 8, col, .8, .08);
}
export function stairs(B, x, y, z, w, n, rise, run, ry = 0, col = C.stone) { const c = Math.cos(ry), s = Math.sin(ry); for (let i = 0; i < n; i++) { const d = i * run, px = x + s * d, pz = z + c * d, hh = rise * (i + 1); const gs = B.G(px, pz); gs.box(px, y + hh / 2, pz, Math.abs(c) * w + Math.abs(s) * run, hh, Math.abs(s) * w + Math.abs(c) * run, mix3(col, C.moss, i % 3 === 0 ? .3 : 0), { jit: .06 }); B.ph.box(px, y + hh / 2, pz, Math.abs(c) * w + Math.abs(s) * run, hh, Math.abs(s) * w + Math.abs(c) * run, { stair: 1 }); } }
export function lantern(B, x, y, z, col = C.amber, h = 2.2) { const g = B.G(x, z); g.cyl(x, y + h / 2, z, .05, .06, h, C.bark2, { seg: 4 }); g.box(x, y + h + .1, z, .26, .32, .26, col, { e: 1.2, jit: 0 }); g.box(x, y + h + .32, z, .34, .06, .34, C.bark2); B.light(x, y + h + .1, z, 11, col, 1.2, .12); const f = B.FX(x, z); f.sph(x, y + h + .1, z, .9, .9, .9, col, { e: .09, soft: 1, jit: 0, low: 1 }); }
export function crystal(g, x, y, z, h, r, col, e = .9, ry = 0) { g.cone(x, y + h * .35, z, r, h * .7, col, { seg: 5, e, jit: .04, ry }); g.cone(x, y + h * .35 - h * .0, z, r, -h * .35, col, { seg: 5, e, jit: .04, ry }); }
export function crystalCluster(B, x, y, z, s = 1, col = C.violet) { const g = B.G(x, z), R = B.rand; for (let i = 0; i < 5; i++) { const a = R() * 6.28, d = R() * .9 * s; g.cone(x + Math.cos(a) * d, y + (.6 + R() * .8) * s * .5, z + Math.sin(a) * d, (.2 + R() * .2) * s, (1.2 + R() * 1.6) * s, col, { seg: 5, e: .55, rz: (R() - .5) * .5, rx: (R() - .5) * .5, jit: .1 }); } const f = B.FX(x, z); f.sph(x, y + .9 * s, z, 1.4 * s, 1.2 * s, 1.4 * s, col, { e: .08, soft: 1, low: 1, jit: 0 }); B.light(x, y + 1.2 * s, z, 9 * s, col, 1, .05); }
export function waterfall(B, x, y0, y1, z, w, ry = 0, col = [.5, 1, .95]) { const f = B.FX(x, z); f.box(x, (y0 + y1) / 2, z, w, y1 - y0, .25, col, { e: .22, ry, jit: .25 }); for (let i = 0; i < 9; i++) f.box(x + (B.rand() - .5) * w * .9, (y0 + y1) / 2, z + .14, .12, y1 - y0, .02, [1, 1, 1], { e: .3, ry, jit: 0 }); f.sph(x, y0 + .3, z + .8, w * .7, .9, 1.6, [.8, 1, 1], { e: .12, soft: 1, low: 1, jit: 0 }); }
export function vineWall(B, x, y0, y1, z, w, axis = 'z', col = C.mossB) { const g = B.G(x, z); for (let i = 0; i < Math.round(w * 2); i++) { const o = -w / 2 + i * .5 + B.rand() * .2; const px = axis === 'z' ? x + o : x, pz = axis === 'z' ? z : z + o; g.box(px, (y0 + y1) / 2, pz, axis === 'z' ? .12 : .1, y1 - y0, axis === 'z' ? .1 : .12, col, { sway: .3, e: .05 }); for (let k = 0; k < 4; k++) g.sph(px, y0 + (y1 - y0) * (k + .5) / 4, pz, .22, .16, .22, [.12, .5, .25], { low: 1, jit: .2 }); } }
export function door(B, x, y, z, w, h, ry, col = C.wood, sym = C.amber) { // باب بجناحين؛ يرجع كائنًا يمكن فتحه
  const m = B.dynMesh(g => { g.box(0, h / 2, 0, w, h, .35, col, { jit: .03 }); g.box(0, h / 2, .2, w * .8, h * .85, .06, [.3, .2, .12], { jit: 0 }); g.cyl(0, h * .55, .26, .5, .5, .05, sym, { seg: 10, rx: Math.PI / 2, e: .7, jit: 0 }); g.box(0, h * .55, .26, .1, .6, .06, [.1, .06, .03], { jit: 0 }); });
  const c = Math.cos(ry), s = Math.sin(ry);
  const col2 = B.ph.box(x, y + h / 2, z, Math.abs(c) * w + Math.abs(s) * .5, h, Math.abs(s) * w + Math.abs(c) * .5, { tag: 'door' });
  const d = { mesh: m, box: col2, x, y, z, ry, h, open: 0, target: 0, base: m.model };
  B.updaters.push((dt) => { d.open += (d.target - d.open) * Math.min(1, dt * 2.5); if (Math.abs(d.target - d.open) < .002) d.open = d.target; col2.active = d.open < .9; m.model = mul(mT(x, y - d.open * (h + .2), z), mRY(ry)); });
  return d;
}
export function bridge(B, x0, z0, x1, z1, y, width = 2.6, arc = 1.2, col = C.stone) { const n = 14, dx = x1 - x0, dz = z1 - z0, len = Math.hypot(dx, dz), ry = Math.atan2(dx, dz); for (let i = 0; i < n; i++) { const t = (i + .5) / n, h = y + Math.sin(t * Math.PI) * arc, px = x0 + dx * t, pz = z0 + dz * t, g = B.G(px, pz); g.box(px, h - .25, pz, width, .5, len / n + .06, mix3(col, C.moss, (i % 4 === 0) * .3), { ry, rx: Math.cos(t * Math.PI) * .09 * 0 }); B.ph.box(px, h - .25, pz, Math.abs(Math.cos(ry)) * width + Math.abs(Math.sin(ry)) * len / n, .5, Math.abs(Math.sin(ry)) * width + Math.abs(Math.cos(ry)) * len / n, { nocam: 1 });
  for (const s of [-1, 1]) { const ox = Math.cos(ry) * s * width / 2, oz = -Math.sin(ry) * s * width / 2; g.box(px + ox, h + .3, pz + oz, .22, .55, len / n + .05, C.stoneD, { ry }); } } }
