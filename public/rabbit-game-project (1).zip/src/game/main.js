// «الأرنب وحارس الآيات» — الحلقة الرئيسية: العالم، الأرنب، الكاميرا، التحكم، البوابة، المكافآت، وضع المعلمة.
import { Renderer, Mesh } from '../engine/gl.js';
import { Physics, Character } from '../engine/physics.js';
import { FollowCam } from '../engine/camera.js';
import { Input } from '../engine/input.js';
import { Sfx } from '../engine/audio.js';
import { Geo } from '../engine/geo.js';
import { mul, mT, mRY, mRX, mS, clamp, lerpAngle } from '../engine/math.js';
import { loadQuran, Q } from '../data/quran.js';
import { crystal } from './kit.js';
import { build, px } from './world.js';
import { curriculum } from './curriculum.js';
import { createRabbit } from './rabbit.js';
import { QAudio } from './qaudio.js';
import { Voice, SAY } from './voice.js';
import { Progress } from './progress.js';
import { GateSession } from './gate.js';
import { Teacher } from './teacher.js';
const $ = id => document.getElementById(id), wait = ms => new Promise(r => setTimeout(r, ms));
export const G = window.__game = { t: 0, qual: 1, paused: true, noRender: false, snap: 3 };
const setLoad = (p, t) => { $('lbar').style.width = p + '%'; $('ltxt').textContent = t; };
function fatal(msg, det) { $('loading').classList.add('off'); const e = $('err'); e.classList.add('on'); e.innerHTML = '<div style="padding:20px;font-size:1.3rem;text-align:center">' + msg + '<pre style="font-size:.7rem;text-align:left;direction:ltr;white-space:pre-wrap">' + (det || '') + '</pre></div>'; }
let toastT; function toast(t) { const e = $('toast'); e.textContent = t; e.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => e.classList.remove('on'), 1800); }
function confetti(n = 20) { const c = $('conf'), em = ['⭐', '✨', '💎', '🌸', '🎈', '💖']; for (let i = 0; i < n; i++) { const s = document.createElement('span'); s.className = 'cf'; s.textContent = em[(Math.random() * em.length) | 0]; s.style.left = Math.random() * 100 + '%'; s.style.animationDelay = Math.random() * .8 + 's'; s.style.fontSize = 1.2 + Math.random() * 1.8 + 'rem'; c.append(s); setTimeout(() => s.remove(), 3500); } }
const hud = () => { $('hs').textContent = G.P.d.stars; $('hg').textContent = G.P.d.gems; };

async function boot() {
  try {
    setLoad(5, 'تهيئة الرسوم…');
    try { G.r = new Renderer($('c')); } catch (e) { return fatal('جهازك أو متصفحك لا يدعم WebGL2 المطلوب للعبة ثلاثية الأبعاد. جرّب Chrome حديثًا.', e.message); }
    G.r.onLost = () => fatal('فُقد سياق الرسوم. أعد تحميل الصفحة.');
    await wait(30); setLoad(25, 'التحقق من نص المصحف (ورش)…'); await loadQuran();
    const man = JSON.parse($('manifest').textContent); G.man = man; G.QA = new QAudio(man); Voice.init(man); G.Voice = Voice; G.Q = Q; G.cur = curriculum(man);
    G.P = new Progress(); Voice.on = G.P.d.settings.voice !== false; G.P.onChange.push(hud);
    G.sfx = new Sfx(); G.sfx.on = G.P.d.settings.sound !== false; G.rb = createRabbit(G.r);
    setLoad(45, 'بناء العالم…'); await wait(20);
    G.inp = new Input($('c')); G.inp.onJoy = (j, on) => { const b = $('joy'); b.classList.toggle('on', on); if (on) { b.style.left = j.ox - 65 + 'px'; b.style.top = j.oy - 65 + 'px'; b.style.bottom = 'auto'; } else { b.style.left = '30px'; b.style.top = 'auto'; b.style.bottom = 'calc(44px + env(safe-area-inset-bottom))'; } $('knob').style.transform = on ? `translate(${j.x * 40}px,${j.y * 40}px)` : ''; };
    G.inp.onMenu = () => G.T.toggle();
    G.sess = new GateSession({ root: $('gate'), QA: G.QA, Voice, P: G.P, Q, sfx: n => G.sfx.play(n), cheer: s => G.rb.cheer(s), confetti, stars: n => { G.P.addStars(n); }, onOpen: () => { G.inp.enabled = false; G.inp.keys = {}; }, onClose: why => { G.inp.enabled = true; G.T && G.T.open && G.T.render(); }, onComplete: onUnitDone, onStage: () => G.T && G.T.open && G.T.render() });
    G.T = new Teacher({ root: $('teacher'), QA: G.QA, Voice, P: G.P, Q, sess: G.sess, cur: G.cur, gotoGate, gotoStart, gotoZone: loadZone, skipGate: () => { const g = activeGate(); if (g) { G.P.completeUnit(g.unit.id, 1); setGateK(g, true); updateExit(); } }, resetZone: () => { for (const g of G.W.gates) delete G.P.d.units[g.unit.id]; delete (G.P.d.reviewed || {})[G.zi]; G.P.save(); loadZone(G.zi, true); }, recur: () => { G.cur = curriculum(G.man); G.T.c.cur = G.cur; loadZone(Math.min(G.zi, G.cur.zones.length - 1), true); }, zoneIdx: () => G.zi, resetWorld: () => loadZone(G.P.d.zone || 0), onToggle: v => { } });
    const z0 = Math.min(G.P.d.zone || 0, G.cur.zones.length - 1); loadZone(z0, true);
    wire(); addEventListener('resize', () => G.r.resize(G.qual)); setLoad(100, 'جاهز'); await wait(200); $('loading').classList.add('off'); $('bStart').disabled = false; G.running = true; requestAnimationFrame(loop);
  } catch (e) { fatal('تعذّر تحميل اللعبة.', e.stack || e.message); }
}
// ---------- مجسّمات العناصر + المناطق ----------
const lastOpen = () => { const o = G.W.gates.filter(g => g.want); return o[o.length - 1]; };
function loadZone(idx, first) {
  const r = G.r; idx = clamp(idx, 0, G.cur.zones.length - 1); G.sess && G.sess.on && G.sess.close('zone'); G.QA.stop();
  if (G.mk) r.disposeFrom(G.mk); if (!G.meshes) {
    const mk = f => { const g = new Geo(); f(g); return new Mesh(r, g); };
    G.meshes = { star: mk(g => { for (let i = 0; i < 5; i++) { const a = i * 1.2566; g.cone(Math.sin(a) * .2, Math.cos(a) * .2, 0, .13, .42, [1, .85, .3], { seg: 4, rz: -a, e: .7, jit: 0 }); } g.sph(0, 0, 0, .2, .2, .12, [1, .9, .45], { e: .7, jit: 0, low: 1 }); }),
      gem: [[1, .5, .75], [.4, .85, 1], [.75, .6, 1], [1, .85, .3]].map(c => mk(g => crystal(g, 0, -.1, 0, .6, .22, c, .8))) };
  }
  G.mk = r.mark(); G.zi = idx; G.P.d.zone = idx; G.P.save(); G.zone = G.cur.zones[idx]; G.ph = new Physics(); G.W = build(r, G.ph, G.zone);
  G.ch = new Character(G.ph); Object.assign(G.ch, { r: .3, h: 1, walk: 4.4, run: 5.4, jump: 8.4 }); G.ch.teleport(...G.W.spawn); G.ch.checkpoint = G.W.spawn.slice(); G.ch.yaw = 0;
  G.cam = new FollowCam(G.ph); G.cam.dist = 5.6; G.cam.pitch = .42; G.cam.minD = 3; G.cam.yaw = 0; G.snap = 3; G.armed = null; G.exitDone = false;
  const W = G.W; for (const it of W.items) { it.taken = !!G.P.d.items[it.id]; it.mi = (it.id.charCodeAt(it.id.length - 1)) % 4; }
  for (const c of W.chests) { c.done = !!G.P.d.chests[c.id]; c.open = c.done ? 1 : 0; }
  for (const g of W.gates) setGateK(g, G.P.unitDone(g.unit.id), false, true); updateExit(false); G.rev = G.P.d.reviewed && G.P.d.reviewed[idx]; if (G.rev) { W.exit.want = W.exit.open = 1; W.exit.block.active = false; } hud(); if (!first) { toast('🌈'); confetti(20); }
}
function allDone() { return G.W.gates.every(g => G.P.unitDone(g.unit.id)); }
function updateExit(anim = true) { const W = G.W; W.rainbow.visible = allDone(); if (W.rainbow.visible && anim) { G.sfx.play('door'); confetti(40); } }
function setGateK(g, open, anim = true, instant = false) { if (!g) return; g.want = open ? 1 : 0; if (instant || !anim) g.open = g.want; g.doorBox.active = !open; if (open && anim && !instant) { G.sfx.play('door'); confetti(30); toast('🚪✨'); Voice.say(SAY.open); } }
function activeGate() { return G.W.gates.find(g => !G.P.unitDone(g.unit.id)) || null; }
function onUnitDone(unit, stars, review) {
  if (review) { G.P.d.reviewed = G.P.d.reviewed || {}; G.P.d.reviewed[G.zi] = 1; G.P.save(); G.rev = 1; const e = G.W.exit; e.want = 1; e.block.active = false; G.sfx.play('door'); toast('🌈'); return; }
  if (!unit) return; G.P.completeUnit(unit.id, stars); const g = G.W.gates.find(x => x.unit.id === unit.id); setGateK(g, true); updateExit();
}
function gotoGate(k) { const g = typeof k === 'number' ? G.W.gates[k] : (activeGate() || G.W.gates[0]); G.sess.stopAll && G.sess.stopAll(); G.ch.teleport(g.x, G.W.H(g.x, g.z - 4) + .2, g.z - 4.5); G.ch.yaw = 0; G.cam.yaw = 0; G.snap = 3; G.armed = g; }
function gotoStart() { G.ch.teleport(...G.W.spawn); G.cam.yaw = 0; G.ch.yaw = 0; G.snap = 3; G.armed = null; }
function reviewPool() { const done = G.cur.units.filter(u => G.P.unitDone(u.id)); return done; }
function wire() {
  $('bJump').addEventListener('pointerdown', e => { G.inp.jumpP = true; e.preventDefault(); });
  $('bTeach').onclick = () => G.T.toggle(); addEventListener('keydown', e => { if (e.code === 'KeyT' && !(e.target.closest && e.target.closest('input,textarea,select'))) G.T.toggle(); });
  addEventListener('touchstart', () => document.body.classList.add('touch'), { once: true, passive: true }); if (matchMedia('(pointer:coarse)').matches) document.body.classList.add('touch');
  $('bStart').onclick = () => { G.sfx.init(); Voice.say(SAY.welcome); $('title').classList.remove('on'); $('hud').classList.add('on'); G.paused = false; };
  document.addEventListener('pointerdown', () => G.sfx.init(), { once: true });
}
// ---------- الحلقة ----------
let last = performance.now(), stepT = 0, fAcc = 0, fN = 0, bannerT = 0, bannerKey = '';
function banner(ch) {
  const el = $('gname'); let best = null, bd = 1e9; for (const g of G.W.gates) { const d = Math.hypot(g.x - ch.x, g.z - ch.z); if (d < bd && g.z > ch.z - 8) { bd = d; best = g; } }
  if (!best || bd > 22 || G.sess.on) { el.classList.remove('on'); bannerKey = ''; return; } const u = best.unit, done = G.P.unitDone(u.id), act = activeGate() === best, key = u.id + done + act; if (key === bannerKey) return; bannerKey = key;
  el.textContent = ''; el.append((act ? '👉 ' : done ? '✅ ' : '🔒 ') + u.icon + ' سورة ' + Q.surahs[u.surah - 1].name + (u.of > 1 ? '  ' + (u.k + 1) + '/' + u.of : '')); el.classList.add('on'); el.classList.toggle('act', act);
}
function loop(now) {
  requestAnimationFrame(loop); const dt = Math.min(.05, (now - last) / 1000); last = now; if (!G.W || G.r.lost) return;
  const r = G.r, ch = G.ch, W = G.W, t = G.t; r.resize(G.qual);
  fAcc += dt; fN++; if (fAcc > 3) { const fps = fN / fAcc; G.fps = fps; if (fps < 28 && G.qual > .55) G.qual = Math.max(.55, G.qual - .15); else if (fps > 55 && G.qual < 1) G.qual = Math.min(1, G.qual + .05); fAcc = 0; fN = 0; }
  if (!G.paused) {
    const o = G.inp.poll(G.cam.yaw); if (!G.inp.touch) G.cam.rotate(o.dx, o.dy); G.cam.dist = clamp(G.cam.dist + o.wheel, 4, 9);
    const mv = Math.hypot(o.mx, o.mz), on = G.sess.on;
    ch.update(dt, on ? 0 : o.mx, on ? 0 : o.mz, false, on ? false : o.jump, false); const gr = G.ph.groundAt(ch.x, ch.z, ch.y + .5, .6); ch.groundY = gr.y;
    if (mv > .3 && !on) { const d = ((ch.yaw - G.cam.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI; if (Math.abs(d) < 2.2) G.cam.yaw = lerpAngle(G.cam.yaw, ch.yaw, 1 - Math.exp(-1.6 * dt)); }
    for (const e of ch.events.splice(0)) G.sfx.play(e === 'respawn' ? 'ui' : e);
    stepT += dt * ch.speed; if (stepT > 2.2 && ch.onGround) { stepT = 0; G.sfx.play('step'); }
    for (const it of W.items) { if (it.taken) continue; if (Math.hypot(it.x - ch.x, it.z - ch.z, (it.y - ch.y - .5) * .6) < it.r) { it.taken = true; if (G.P.take(it.id, it.kind)) { G.sfx.play('pick'); G.rb.cheer(.8); confetti(3); } } }
    for (const c of W.chests) { if (c.done) continue; if (Math.hypot(c.x - ch.x, c.z - ch.z) < 1.8) { c.done = true; if (G.P.chest(c.id)) { G.sfx.play('crystal'); G.rb.cheer(1.8); confetti(24); toast('💎💎'); } } }
    // بوابات الوحدات
    let near = null; for (const g of W.gates) if (Math.hypot(ch.x - g.x, ch.z - (g.z - 3.4)) < 3.2) near = g;
    if (G.supp && Math.hypot(ch.x - G.supp.x, ch.z - (G.supp.z - (G.supp === W.exit ? 3 : 3.4))) > 9) G.supp = null;
    if (near && !on && ch.onGround && G.supp !== near && near.want < .5) { G.supp = near; const act = activeGate(); if (near !== act) { toast('🔒'); G.sfx.play('try'); Voice.say(SAY.gate); } else if (G.QA.has(near.unit.surah)) G.sess.open(near.unit.surah, near.unit.from, near.unit.to, { unit: near.unit }); }
    // بوابة الخروج: مراجعة ثم المنطقة التالية
    const e = W.exit, de = Math.hypot(ch.x - e.x, ch.z - (e.z - 3));
    if (allDone() && !G.rev && !on && de < 3.5 && G.supp !== e) { G.supp = e; const pool = reviewPool().slice(-6); if (pool.length) G.sess.open(pool[0].surah, pool[0].from, pool[0].to, { review: pool }); }
    if (G.rev && ch.z > e.z - .5 && Math.abs(ch.x - e.x) < 3 && !G.exitDone) { G.exitDone = true; if (G.zi < G.cur.zones.length - 1) { loadZone(G.zi + 1); return; } else { G.P.d.finished = 1; G.P.save(); toast('🏆🎉'); confetti(120); G.rb.cheer(5); G.sfx.play('crystal'); Voice.say(SAY.done); } }
    for (const c of W.clouds) c.model = mT(c.cx + ((t * 1.2) % 150), c.cy, c.cz);
    bannerT -= dt; if (bannerT < 0) { bannerT = .3; banner(ch); }
  }
  for (const g of W.gates) { g.open += (g.want - g.open) * Math.min(1, dt * 2.2); if (Math.abs(g.want - g.open) < .003) g.open = g.want; }
  G.rb.update(ch, dt); G.cam.update(dt, { x: ch.x, y: ch.y - .55, z: ch.z }, G.snap > 0); if (G.snap > 0) G.snap--; G.t += dt;
  if (G.noRender) return;
  const e = r.env, T = W.theme; Object.assign(e, { sunDir: [-.45, -.8, -.4], sunCol: [.55, .5, .38], ambSky: [.5, .56, .68], ambGnd: [.4, .43, .34], fogCol: T.fog, fog: .0065, top: T.top, mid: T.mid, bot: [.95, .96, .92], sun: [.5, .45, .3], stars: 0 });
  r.beginFrame(dt); r.setCamera(G.cam.pos, G.cam.tgt); r.drawSky(); r.lights = W.lights.concat([{ x: ch.x, y: ch.y + 2, z: ch.z, r: 8, c: [1, .95, .85], i: .35 }]);
  r.drawLit(W.lit, G.cam.tgt); const tt = r.time;
  G.rb.draw(ch, tt);
  for (const c of W.chests) { c.open += ((c.done ? 1 : 0) - c.open) * Math.min(1, dt * 6); const base = mul(mT(c.x, c.y, c.z), mRY(c.ry)); r.drawModel(c.body, base); r.drawModel(c.lid, mul(base, mT(0, .56, -.33), mRX(-c.open * 1.2))); }
  for (const it of W.items) { if (it.taken || Math.hypot(it.x - ch.x, it.z - ch.z) > 70) continue; const m = it.kind === 'star' ? G.meshes.star : G.meshes.gem[it.mi]; r.drawModel(m, mul(mT(it.x, it.y + Math.sin(tt * 2 + it.x) * .15, it.z), mRY(tt * 1.6 + it.x), mS(1.3, 1.3, 1.3))); }
  const act = activeGate(), fx = [];
  for (const g of W.gates) { if (Math.hypot(g.x - ch.x, g.z - ch.z) > 75) continue; const sh = Math.min(1, g.open) * 1.75; for (const lf of [g.leafL, g.leafR]) r.drawModel(lf, mul(mT(g.x + lf.side * 2.4, g.y, g.z), mRY(lf.side * sh))); g.portal.model = mT(g.x, g.y, g.z + .6); fx.push(g.portal); if (g === act) { g.arrow.model = mul(mT(g.x, g.y + 9.6 + Math.sin(tt * 3) * .4, g.z), mRY(tt)); fx.push(g.arrow); } }
  r.drawWater(W.water, { a: [.35, .7, .9], b: [.7, .95, 1], alpha: .78 });
  r.drawFx(W.fx); if (W.rainbow.visible) { if (G.rev || !W.exit.want) fx.push(W.rainbow); } if (allDone()) { W.exit.portal.model = mT(W.exit.x, W.exit.y, W.exit.z + .2); if (!G.rev) W.exit.portal.model = mul(mT(W.exit.x, W.exit.y, W.exit.z + .2), mS(.7 + Math.sin(tt * 3) * .06, .7, 1)); fx.push(W.exit.portal); }
  r.drawFx(fx, { pulse: 1 }); r.drawFx(W.clouds); G.rb.drawFx(ch); r.drawParticles(W.parts, G.qual < .8 ? .8 : 1);
}
boot();
