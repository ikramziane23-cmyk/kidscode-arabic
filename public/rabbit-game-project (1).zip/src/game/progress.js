// تقدّم الطفل محليًا (localStorage) خلف واجهة "مخزن" قابلة للاستبدال لاحقًا بمزامنة حسابات/خادم.
const KEY = 'ikram-rabbit.v1';
export const localStore = { load() { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { return null; } }, save(d) { try { localStorage.setItem(KEY, JSON.stringify(d)); } catch (e) { } } };
export class Progress {
  constructor(store = localStore) { this.store = store; this.d = Object.assign({ v: 1, child: { name: '' }, stars: 0, gems: 0, items: {}, chests: {}, surahs: {}, units: {}, zone: 0, settings: { voice: true, sound: true } }, store.load() || {}); this.onChange = []; }
  save() { this.store.save(this.d); this.onChange.forEach(f => f(this.d)); try { parent !== window && parent.postMessage({ type: 'ikram-rabbit:progress', data: this.d }, '*'); } catch (e) { } }
  setStore(s) { this.store = s; const d = s.load(); if (d) this.d = d; this.save(); }
  take(id, kind) { if (this.d.items[id]) return false; this.d.items[id] = 1; this.d[kind === 'gem' ? 'gems' : 'stars'] += 1; this.save(); return true; }
  addStars(n) { this.d.stars += n; this.save(); }
  chest(id) { if (this.d.chests[id]) return false; this.d.chests[id] = 1; this.d.gems += 2; this.save(); return true; }
  s(n) { return this.d.surahs[n] || (this.d.surahs[n] = { done: false, stars: 0, tries: 0, listens: 0, repeats: 0, correct: 0, wrong: 0, last: 0 }); }
  note(n, k, v = 1) { const s = this.s(n); s[k] += v; s.last = Date.now(); this.save(); }
  complete(n, stars) { const s = this.s(n); s.done = true; s.stars = Math.max(s.stars, stars); s.last = Date.now(); this.save(); }
  unit(id) { return this.d.units[id] || null; }
  completeUnit(id, stars) { const u = this.d.units[id] || (this.d.units[id] = { done: false, stars: 0 }); u.done = true; u.stars = Math.max(u.stars, stars); this.save(); }
  unitDone(id) { return !!(this.d.units[id] && this.d.units[id].done); }
  done(n) { return !!(this.d.surahs[n] && this.d.surahs[n].done); }
  reset() { this.d = { v: 1, child: { name: '' }, stars: 0, gems: 0, items: {}, chests: {}, surahs: {}, units: {}, zone: 0, settings: this.d.settings }; this.save(); }
  export() { return JSON.stringify(this.d); } import(t) { const d = JSON.parse(t); if (d && d.v === 1) { this.d = d; this.save(); return true; } return false; }
}
