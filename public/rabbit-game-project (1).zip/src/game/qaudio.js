// تشغيل التلاوة الحقيقية فقط (ملفات المستخدم) — مقاطع الآيات من ملف السورة بحسب manifest.
// لا يُولَّد أي صوت قرآني. إن لم يوجد ملف لسورة فـ has(n) = false ولا تُعرض في اللعبة.
const OVR = 'ikram-rabbit.seg-override';
export class QAudio {
  constructor(manifest) { this.man = manifest || { surahs: {} }; this.a = new Audio(); this.a.preload = 'auto'; this.token = 0; this.paused = false; this.playing = null; this.log = []; this.ov = {}; try { this.ov = JSON.parse(localStorage.getItem(OVR) || '{}'); } catch (e) { } this.pend = null; this.seq = 0; }
  has(n) { const s = this.man.surahs[n]; return !!(s && s.file && s.segs && s.segs.length); }
  meta(n) { return this.man.surahs[n]; }
  segs(n) { return (this.ov[n] || (this.man.surahs[n] || {}).segs || []); }
  setOverride(n, segs) { if (segs) this.ov[n] = segs; else delete this.ov[n]; try { localStorage.setItem(OVR, JSON.stringify(this.ov)); } catch (e) { } }
  count(n) { return this.segs(n).length; }
  _src(n) { const u = new URL(this.man.surahs[n].file, document.baseURI).href; if (this.a.src !== u) { this.a.src = u; } return new Promise(res => { if (this.a.readyState >= 1) return res(true); const ok = () => { cl(); res(true); }, bad = () => { cl(); res(false); }, cl = () => { this.a.removeEventListener('loadedmetadata', ok); this.a.removeEventListener('error', bad); clearTimeout(t); }; const t = setTimeout(bad, 9000); this.a.addEventListener('loadedmetadata', ok); this.a.addEventListener('error', bad); }); }
  /** يشغّل آية واحدة (فهرس من 0). يعيد 'ended' | 'stopped' | 'error' */
  async play(n, i, o = {}) {
    if (!this.has(n)) return 'error'; this._halt(); const my = ++this.token; const seg = this.segs(n)[i]; if (!seg) return 'error';
    if (!await this._src(n) || my !== this.token) return my === this.token ? 'error' : 'stopped';
    const a = this.a, start = o.from ?? seg[0], end = o.to ?? seg[1]; a.currentTime = start; this.paused = false; this.playing = { n, i };
    try { await a.play(); } catch (e) { this.playing = null; return 'error'; }
    return new Promise(res => {
      const done = r => { clearInterval(iv); this.pend = null; if (this.playing && my === this.token) this.playing = null; res(r); };
      this.pend = () => done('stopped');
      const iv = setInterval(() => { if (my !== this.token) return done('stopped'); if (a.ended || a.currentTime >= end - .02) { a.pause(); this.log.push([n, i, +start.toFixed(2), +end.toFixed(2)]); done('ended'); } }, 25);
    });
  }
  /** يشغّل آيات متتالية [from..to] ويستدعي onAyah(i) عند بداية كل آية */
  async playRange(n, from, to, onAyah) { const my = ++this.seq; for (let i = from; i <= to; i++) { if (my !== this.seq) return 'stopped'; onAyah && onAyah(i); const r = await this.play(n, i); if (r !== 'ended' || my !== this.seq) return my !== this.seq ? 'stopped' : r; if (i < to) { await new Promise(r2 => setTimeout(r2, 450)); } } return 'ended'; }
  stop() { this.seq++; this._halt(); }
  _halt() { this.token++; try { this.a.pause(); } catch (e) { } this.paused = false; const p = this.pend; this.pend = null; this.playing = null; p && p(); }
  pause() { if (this.playing && !this.paused) { this.a.pause(); this.paused = true; } }
  resume() { if (this.paused) { this.paused = false; this.a.play().catch(() => { }); } }
}
