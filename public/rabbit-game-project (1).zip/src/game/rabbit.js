// الأرنب: مجسّم ثلاثي الأبعاد لطيف بأجزاء متحركة (قفزات، أذنان، رمش، فرح).
import { Geo } from '../engine/geo.js';
import { Mesh } from '../engine/gl.js';
import { mul, mT, mRY, mRX, mRZ, mS, lerp } from '../engine/math.js';
const CREAM = [1, .95, .9], WHITE = [1, 1, 1], PINK = [1, .62, .7], DARK = [.16, .1, .12], BOW = [.95, .3, .4];
export function createRabbit(r) {
  const mk = f => { const g = new Geo(); f(g); return new Mesh(r, g); };
  const P = {
    body: mk(g => { g.sph(0, .38, 0, .34, .32, .38, CREAM, { jit: 0, grad: .12, e: .22 }); g.sph(0, .31, .12, .25, .24, .27, WHITE, { jit: 0, e: .2 }); g.sph(0, .4, -.4, .14, .14, .14, WHITE, { jit: 0, e: .3 }); }),
    head: mk(g => { g.sph(0, 0, 0, .3, .27, .28, CREAM, { jit: 0, grad: .1, e: .22 }); g.sph(-.17, -.09, .15, .09, .075, .06, PINK, { jit: 0, low: 1, e: .1 }); g.sph(.17, -.09, .15, .09, .075, .06, PINK, { jit: 0, low: 1, e: .1 }); g.sph(0, -.03, .27, .05, .04, .04, [.95, .45, .55], { jit: 0, low: 1 }); g.sph(-.04, -.12, .25, .03, .02, .02, DARK, { jit: 0, low: 1 }); g.sph(.04, -.12, .25, .03, .02, .02, DARK, { jit: 0, low: 1 }); g.sph(0, -.1, .255, .015, .03, .015, DARK, { jit: 0, low: 1 }); }),
    eyes: mk(g => { for (const s of [-1, 1]) { g.sph(s * .12, .05, .22, .055, .07, .04, DARK, { jit: 0, low: 1 }); g.sph(s * .105, .075, .255, .02, .025, .015, [1, 1, 1], { jit: 0, low: 1, e: .5 }); } }),
    earL: mk(g => { g.sph(0, .3, 0, .095, .32, .05, CREAM, { jit: 0, e: .22 }); g.sph(0, .3, .02, .055, .25, .03, PINK, { jit: 0, e: .1 }); }),
    paw: mk(g => { g.sph(0, 0, 0, .07, .06, .09, WHITE, { jit: 0 }); }),
    foot: mk(g => { g.sph(0, 0, .04, .1, .07, .18, WHITE, { jit: 0 }); }),
  };
  const shadow = (() => { const g = new Geo(); const n = 14; for (let i = 0; i < n; i++) { const a = i / n * 6.283, b = (i + 1) / n * 6.283, base = g.n; g.v.push(0, 0, 0, 0, 1, 0, 0, 0, 0, .5, 0, 0, 0, Math.cos(a) * .5, 0, Math.sin(a) * .5, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, Math.cos(b) * .5, 0, Math.sin(b) * .5, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0); g.idx.push(base, base + 2, base + 1); g.n += 3; } g.min = [-.5, 0, -.5]; g.max = [.5, 0, .5]; return new Mesh(r, g, 'fx'); })();
  let phase = 0, air = 0, joy = 0, blink = 0, blinkT = 2, t0 = 0;
  const api = {
    cheer(sec = 2.2) { joy = sec; },
    get joying() { return joy > 0; },
    update(ch, dt) { phase += ch.speed * dt * 2.6; air += ((ch.onGround ? 0 : 1) - air) * Math.min(1, dt * 14); if (joy > 0) joy -= dt; blinkT -= dt; if (blinkT < 0) { blink = .14; blinkT = 2 + Math.random() * 3; } if (blink > 0) blink -= dt; },
    draw(ch, t) {
      const S = Math.sin, sp = Math.min(1, ch.speed / 4.5), hop = Math.abs(S(phase)) * sp, J = joy > 0 ? 1 : 0;
      const jy = J ? Math.abs(S(t * 9)) * .55 : 0, spin = J ? t * 7 : 0;
      const sq = 1 + (air ? .1 : 0) - hop * .06 + (J ? S(t * 18) * .03 : 0);
      const y = ch.y + hop * .22 + jy + S(t * 2) * .006;
      const root = mul(mT(ch.x, y, ch.z), mRY(ch.yaw + spin), mRX(-air * .12 + sp * .08 * S(phase + 1.6)), mS(1 / Math.sqrt(sq), sq, 1 / Math.sqrt(sq)));
      const D = (m, M) => r.drawModel(P[m], M), hy = .78, tilt = S(t * 1.3) * .03;
      D('body', root);
      const head = mul(root, mT(0, hy, .2), mRX(.05 + sp * .05 - air * .15), mRZ(tilt)); D('head', head);
      const b = blink > 0 ? .1 : 1; D('eyes', mul(head, mT(0, .05, .22), mS(1, b, 1), mT(0, -.05, -.22)));
      const ef = air * .9 + sp * .3 + (J ? S(t * 14) * .25 : 0) + S(t * 3) * .03;
      D('earL', mul(head, mT(-.11, .2, -.03), mRX(-.12 - ef), mRZ(.22 + (J ? .3 : 0))));
      D('earL', mul(head, mT(.11, .2, -.03), mRX(-.12 - ef * .8 + S(t * 2.2) * .04), mRZ(-.22 - (J ? .3 : 0))));
      const sw = S(phase) * .5 * sp, up = J ? -.9 : 0;
      D('paw', mul(root, mT(-.13, .14 + (J ? .3 : 0), .26), mRX(-sw - air * .5 + up))); D('paw', mul(root, mT(.13, .14 + (J ? .3 : 0), .26), mRX(sw - air * .5 + up)));
      D('foot', mul(root, mT(-.2, .07, -.12), mRX(sw * .8 + air * .6))); D('foot', mul(root, mT(.2, .07, -.12), mRX(-sw * .8 + air * .6)));
    },
    drawFx(ch) { const h = Math.max(0, ch.y - (ch.groundY ?? ch.y)), s = 1 / (1 + h * .3); shadow.model = mul(mT(ch.x, (ch.groundY ?? ch.y) + .03, ch.z), mS(.95 * s, 1, .95 * s)); r.drawFx([shadow], { shadow: true }); shadow.model = null; },
  };
  return api;
}
