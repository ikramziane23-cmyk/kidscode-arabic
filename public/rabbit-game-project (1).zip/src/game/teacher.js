// لوحة المعلمة (درج جانبي يناسب مشاركة الشاشة في Zoom): سورة/آيات، تشغيل وإعادة، بدء/إيقاف التحدي، التحكم بالأرنب والبوابة، التقدّم، وضبط حدود الآيات.
import { h } from './gate.js';
import { approved, setApproved } from './curriculum.js';
export class Teacher {
  constructor(c) { this.c = c; this.el = c.root; this.n = null; this.from = 0; this.to = 0; this.oral = false; this.open = false; this.render(); }
  toggle(v) { this.open = v ?? !this.open; this.el.classList.toggle('on', this.open); if (this.open) this.render(); this.c.onToggle && this.c.onToggle(this.open); }
  surahs() { return Object.keys(this.c.QA.man.surahs).map(Number).filter(n => this.c.QA.has(n)).sort((a, b) => b - a); }
  render() {
    const c = this.c, QA = c.QA, P = c.P, list = this.surahs(); if (this.n == null || !list.includes(this.n)) this.n = list.includes(114) ? 114 : list[0];
    const cnt = QA.count(this.n); if (this.to >= cnt || this.to < this.from) { this.from = 0; this.to = cnt - 1; }
    const T = (t, f, cls = '', id) => h('button', { class: 'tb ' + cls, onclick: f, ...(id ? { id } : {}) }, t);
    const sel = h('select', { id: 'tSurah', onchange: e => { this.n = +e.target.value; this.from = 0; this.to = QA.count(this.n) - 1; this.render(); } }, ...list.map(n => h('option', { value: n, ...(n === this.n ? { selected: '' } : {}) }, n + ' · ' + c.Q.surahs[n - 1].name + (approved().includes(n) ? ' ✔' : QA.meta(n).risky ? ' ⛔' : ' ⚠'))));
    const ay = (id, v, f) => h('select', { id, onchange: e => f(+e.target.value) }, ...[...Array(cnt).keys()].map(i => h('option', { value: i, ...(i === v ? { selected: '' } : {}) }, 'آية ' + (i + 1))));
    const sess = c.sess, stg = ['intro', 'listen', 'repeat', 'quiz', 'reward'], names = { intro: 'الاسم', listen: 'استماع', repeat: 'تكرار', quiz: 'تحدٍّ', reward: 'مكافأة' };
    const US = c.cur.units, prog = h('table', {}, h('tr', {}, h('th', {}, 'السورة'), h('th', {}, 'الوحدات'), h('th', {}, 'استماع/تكرار'), h('th', {}, 'صح/خطأ')), ...c.cur.surahs.map(n => { const us = US.filter(u => u.surah === n), dn = us.filter(u => P.unitDone(u.id)).length, s = P.d.surahs[n]; return h('tr', {}, h('td', {}, c.Q.surahs[n - 1].name), h('td', {}, h('span', { class: 'badge' + (dn === us.length ? ' ok' : '') }, dn + '/' + us.length)), h('td', {}, s ? s.listens + '/' + s.repeats : '0/0'), h('td', {}, s ? s.correct + '/' + s.wrong : '0/0')); }));
    const segRow = (sg, i) => h('div', { class: 'row', style: 'justify-content:space-between;border-bottom:1px solid #eee;padding:2px 0' },
      h('b', {}, i + 1), h('span', { id: 'sg' + i }, sg[0].toFixed(2) + ' → ' + sg[1].toFixed(2)),
      h('span', {}, T('بداية −', () => this.nudge(i, 0, -.1)), T('+', () => this.nudge(i, 0, .1)), T('نهاية −', () => this.nudge(i, 1, -.1)), T('+', () => this.nudge(i, 1, .1)), T('🔊', () => QA.play(this.n, i))));
    const segUI = h('div', {}, ...QA.segs(this.n).map(segRow));
    this.el.innerHTML = ''; this.el.append(
      h('div', { class: 'row', style: 'justify-content:space-between' }, h('b', { style: 'font-size:1.2rem' }, '👩‍🏫 لوحة المعلمة'), T('✖ إغلاق', () => this.toggle(false), '', 'tClose')),
      h('h3', {}, 'السورة والآيات'), sel, h('div', { class: 'grid', style: 'margin-top:6px' }, ay('tFrom', this.from, v => { this.from = v; if (this.to < v) this.to = v; this.render(); }), ay('tTo', this.to, v => { this.to = Math.max(v, this.from); this.render(); })),
      h('small', {}, approved().includes(this.n) ? '✔ اعتُمدت حدود هذه السورة بعد المراجعة.' : QA.meta(this.n).risky ? '⛔ ثقة التقسيم منخفضة: السورة مستبعدة من اللعب حتى تراجعي الحدود وتعتمديها.' : '⚠ حدود الآيات مقترحة تلقائيًا ولم تُراجَع بالسمع — راجعيها من «ضبط الحدود» ثم اعتمديها.'), T(approved().includes(this.n) ? 'إلغاء الاعتماد' : '✔ اعتماد الحدود بعد المراجعة', () => { setApproved(this.n, !approved().includes(this.n)); c.recur(); this.render(); }, '', 'tApprove'),
      h('h3', {}, 'التلاوة'), T('▶ تشغيل المدى', () => QA.playRange(this.n, this.from, this.to), '', 'tPlay'), T('⏸ / ▶', () => QA.paused ? QA.resume() : QA.pause(), '', 'tPause'), T('⏹', () => QA.stop(), '', 'tStop'), T('🔁 آية', () => QA.play(this.n, this.from), '', 'tReplay'),
      h('h3', {}, 'البوابة والتحدي'), T('🚪 ابدأ عند البوابة', () => { c.gotoGate(); sess.open(this.n, this.from, this.to, { oral: this.oral, unit: this.unitOf() }); this.render(); }, '', 'tOpen'), T('🎯 ابدأ التحدي', () => { c.gotoGate(); sess.open(this.n, this.from, this.to, { oral: this.oral, stage: 'quiz', unit: this.unitOf() }); this.render(); }, '', 'tQuiz'), T('⏹ إيقاف', () => { sess.close('teacher'); this.render(); }, 'warn', 'tEnd'),
      h('div', {}, h('small', {}, 'مرحلة الجلسة: '), ...stg.map(s => T(names[s], () => { if (sess.on) sess.go(s); }, sess.stage === s ? 'on' : '', 'tg_' + s))),
      T(this.oral ? '✔ إجابة شفهية (الخيار ١/٢)' : '🗣 إجابة شفهية', () => { this.oral = !this.oral; this.render(); }, this.oral ? 'on' : '', 'tOral'),
      h('h3', {}, 'الأرنب'), T('إلى البوابة الحالية', () => c.gotoGate(), '', 'tToGate'), T('إلى البداية', () => c.gotoStart()), T('تخطّي البوابة الحالية', () => { c.skipGate(); this.render(); }, 'warn', 'tOpenGate'),
      h('h3', {}, 'المناطق (' + c.cur.zones.length + ')'), h('select', { id: 'tZone', onchange: e => c.gotoZone(+e.target.value) }, ...c.cur.zones.map((z, i) => h('option', { value: i, ...(i === c.zoneIdx() ? { selected: '' } : {}) }, 'المنطقة ' + (i + 1) + ' — ' + z.gates.map(u => c.Q.surahs[u.surah - 1].name).filter((x, k, a) => a.indexOf(x) === k).join('، ')))), T('إعادة تقدّم هذه المنطقة', () => { c.resetZone(); this.render(); }, 'warn'),
      c.cur.missing.length ? h('small', {}, 'سور بلا تسجيل (لن تظهر): ' + c.cur.missing.map(n => c.Q.surahs[n - 1].name).join('، ')) : null,
      h('h3', {}, 'تقدّم الطفل'), h('div', {}, '⭐ ' + P.d.stars + '  💎 ' + P.d.gems), prog, T('🗑 مسح التقدّم', () => { if (confirm('مسح تقدّم الطفل؟')) { P.reset(); c.resetWorld(); this.render(); } }, 'warn'), T('📤 تصدير', () => { this.io.value = P.export(); }), T('📤 الحدود المعتمدة', () => { this.io.value = JSON.stringify({ approved: approved(), segs: QA.ov }); }), T('📥 استيراد', () => { try { alert(P.import(this.io.value) ? 'تم' : 'ملف غير صالح'); c.resetWorld(); this.render(); } catch (e) { alert('ملف غير صالح'); } }), this.io = h('input', { placeholder: 'نسخة التقدّم (JSON)' }),
      h('h3', {}, 'الصوت'), T(c.Voice.on ? '🔊 صوت التعليمات: يعمل' : '🔇 صوت التعليمات: متوقف', () => { c.Voice.on = !c.Voice.on; this.render(); }), h('small', {}, c.Voice.arabicVoice ? 'يوجد صوت عربي في هذا المتصفح.' : 'لم يُعثر على صوت عربي في هذا الجهاز؛ يمكن إضافة تسجيلات للتعليمات في manifest.voice.'),
      h('h3', {}, 'ضبط حدود الآيات'), segUI, T('إعادة الحدود التلقائية', () => { QA.setOverride(this.n, null); this.render(); }));
  }
  unitOf() { return this.c.cur.units.find(u => u.surah === this.n && u.from === this.from && u.to === this.to) || null; }
  nudge(i, k, d) { const segs = this.c.QA.segs(this.n).map(s => s.slice()); segs[i][k] = Math.max(0, +(segs[i][k] + d).toFixed(2)); if (segs[i][1] - segs[i][0] < .3) return; this.c.QA.setOverride(this.n, segs); const e = this.el.querySelector('#sg' + i); if (e) e.textContent = segs[i][0].toFixed(2) + ' → ' + segs[i][1].toFixed(2); }
}
