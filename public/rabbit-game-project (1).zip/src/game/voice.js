// صوت التعليمات والتشجيع (غير قرآني، منفصل تمامًا عن التلاوة). يفضّل ملفًا مسجّلًا إن وُجد في manifest.voice،
// وإلا يستخدم نطق المتصفح العربي (speechSynthesis) إن توفّر. بلا صوت مخيف ولا عبارات محبطة.
export const SAY = {
  welcome: 'مرحبًا! هيا نلعب مع الأرنب', gate: 'وصلنا إلى البوابة', listen: 'استمع جيدًا', repeat: 'والآن كرّر معي', yourturn: 'دورك',
  choose: 'أيّ المقطعين هو الصحيح؟', next: 'أيّ المقطعين يأتي بعدها؟', same: 'أيّ المقطعين هو نفس ما سمعت؟',
  good: ['أحسنت!', 'رائع!', 'ممتاز، أنت بطل!', 'جميل جدًا!'], retry: ['حاول مرة أخرى، أنت تستطيع', 'لا بأس، استمع مرة أخرى', 'قريب جدًا، جرّب ثانية'],
  hint: 'سأساعدك، استمع إلى هذا', done: 'مبروك! أكملت السورة', open: 'انفتحت البوابة', again: 'هل نسمعها مرة أخرى؟',
};
export const Voice = {
  man: {}, on: true, last: '', count: 0, _u: null,
  init(man) { this.man = (man && man.voice) || {}; this.hasTTS = typeof speechSynthesis !== 'undefined'; if (this.hasTTS) { const f = () => { this.ar = speechSynthesis.getVoices().find(v => /^ar/i.test(v.lang)) || null; }; f(); speechSynthesis.onvoiceschanged = f; } },
  get arabicVoice() { return !!this.ar; },
  stop() { try { this._a && this._a.pause(); } catch (e) { } if (this.hasTTS) try { speechSynthesis.cancel(); } catch (e) { } },
  say(text, key) {
    this.last = text; this.count++; if (!this.on) return Promise.resolve();
    this.stop();
    if (key && this.man[key]) return new Promise(res => { const a = this._a = new Audio(new URL(this.man[key], document.baseURI).href); a.onended = a.onerror = () => res(); a.play().catch(() => res()); });
    if (!this.hasTTS) return Promise.resolve();
    return new Promise(res => { try { const u = new SpeechSynthesisUtterance(text); u.lang = 'ar-SA'; if (this.ar) u.voice = this.ar; u.rate = .82; u.pitch = 1.15; const t = setTimeout(res, 1800 + text.length * 170); u.onend = u.onerror = () => { clearTimeout(t); res(); }; speechSynthesis.speak(u); } catch (e) { res(); } });
  },
  pick(arr) { return arr[(Math.random() * arr.length) | 0]; },
};
