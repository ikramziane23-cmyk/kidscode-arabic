// عالم منطقة واحدة: حديقة نهارية بألوان هادئة — مسار طويل، جدول وجسر، أكواخ، أشجار وزهور، صناديق وجواهر،
// وبوابات الوحدات (بوابة لكل وحدة) ثم بوابة الخروج إلى المنطقة التالية. تتبدّل الألوان والتوزيع بين المناطق.
import { WorldBuilder, noise, fbm, mix3, C, rock, bush, mushroom, crystal } from './kit.js';
import { Geo } from '../engine/geo.js';
import { Mesh } from '../engine/gl.js';
import { smooth, lerp, rng, mul, mT, mS } from '../engine/math.js';
export const px = z => 6 * Math.sin(z * .06);
export const Z0 = -52, STREAM_Z = -40, EXIT_Z = 54;
const PAL = [[1, .55, .7], [1, .85, .35], [1, 1, .95], [.75, .6, 1], [1, .65, .35], [.55, .8, 1]];
const THEMES = [
  { g1: [.42, .76, .38], g2: [.56, .86, .45], leaf: [[.4, .78, .42], [.5, .84, .45], [.35, .72, .5], [.6, .85, .4]], fog: [.8, .91, 1], top: [.38, .66, .97], mid: [.66, .85, 1] },
  { g1: [.5, .78, .45], g2: [.7, .86, .5], leaf: [[.95, .6, .7], [.9, .7, .8], [.5, .8, .5], [.98, .75, .6]], fog: [1, .92, .95], top: [.55, .7, .98], mid: [.9, .88, 1] },
  { g1: [.38, .72, .5], g2: [.45, .82, .62], leaf: [[.3, .7, .6], [.4, .8, .7], [.35, .72, .45], [.5, .85, .6]], fog: [.78, .95, .95], top: [.3, .7, .9], mid: [.62, .9, .98] },
  { g1: [.62, .8, .38], g2: [.78, .86, .45], leaf: [[1, .8, .35], [.95, .65, .3], [.6, .78, .4], [.9, .85, .4]], fog: [1, .95, .8], top: [.5, .72, .95], mid: [.95, .92, .85] },
  { g1: [.46, .7, .55], g2: [.6, .8, .7], leaf: [[.6, .55, .9], [.7, .65, .95], [.45, .75, .55], [.55, .8, .75]], fog: [.88, .88, 1], top: [.45, .55, .95], mid: [.8, .82, 1] },
];
export const theme = i => THEMES[i % THEMES.length];
export function build(r, ph, zone) {
  const T = theme(zone.idx), B = new WorldBuilder(r, ph), R = rng(21 + zone.idx * 13), ITEMS = [], seed = zone.idx * 31;
  const onPath = (x, z, w = 2.6) => Math.abs(x - px(z)) < w, m = zone.gates.length, gap = Math.min(15, 66 / Math.max(m, 1));
  const gz = k => -24 + k * gap;
  const H = (x, z) => {
    let h = (fbm(x * .03 + 5 + seed, z * .03) - .45) * 5.5 + (fbm(x * .12, z * .12 + seed) - .5) * .5;
    const pf = (1 - smooth(3, 9, Math.abs(x - px(z)))) * smooth(-62, -54, z) * (1 - smooth(58, 64, z)); h = lerp(h, .3, pf);
    for (let k = 0; k < m; k++) { const pl = 1 - smooth(7, 12, Math.hypot(x - px(gz(k)), z - gz(k))); h = lerp(h, .3, pl); }
    const pe = 1 - smooth(8, 13, Math.hypot(x - px(EXIT_Z), z - EXIT_Z)); h = lerp(h, .3, pe);
    return lerp(h, -.9, 1 - smooth(2.2, 4.4, Math.abs(z - STREAM_Z)));
  };
  const col = (x, y, z, ny) => {
    const n = noise(x * .25, z * .25), n2 = noise(x * .9, z * .9); let c = mix3(T.g1, T.g2, n); c = mix3(c, [.5, .8, .5], n2 * .25);
    if (y < -.25) c = [.62, .74, .66]; else if (y < .05) c = mix3(c, [.8, .78, .6], smooth(.05, -.25, y));
    if (onPath(x, z, 1.7) && y > -.2 && z > -58 && z < EXIT_Z + 6) c = mix3(c, [.86, .72, .46], .85 * (1 - smooth(1.2, 1.8, Math.abs(x - px(z)))) + .15);
    for (let k = 0; k < m; k++) { const d = Math.hypot(x - px(gz(k)), z - gz(k)); if (d < 9.5) c = mix3(c, [.9, .87, .8], .6 * (1 - smooth(6, 9.5, d)) + .05); }
    if (1 - ny > .3) c = mix3(c, [.6, .6, .55], smooth(.3, .6, 1 - ny)); return c;
  };
  B.terrain(-64, -64, 128, 128, H, col, 1.6); ph.terrain = H; ph.waterY = -99; ph.killY = -15;
  for (const [x, z, w, d] of [[-62, 0, 2, 130], [62, 0, 2, 130], [0, -62, 130, 2], [0, 62, 130, 2]]) ph.box(x, 20, z, w, 60, d, { nocam: 1 });
  B.water(-64, STREAM_Z - 5.5, 128, 11, -.38, [1, 0], 40, 8);
  { const bx = px(STREAM_Z), g = B.G(bx, STREAM_Z), n = 12, len = 12, wid = 3.4;
    for (let i = 0; i < n; i++) { const t = (i + .5) / n, z = STREAM_Z - len / 2 + len * t, h = .38 + Math.sin(t * Math.PI) * .7; g.box(bx, h - .22, z, wid, .26, len / n + .04, mix3([.82, .6, .38], [.7, .5, .3], (i % 2) * .5), { jit: .03 }); ph.box(bx, h - .27, z, wid, .4, len / n + .1, { nocam: 1 }); for (const s of [-1, 1]) g.box(bx + s * (wid / 2 - .1), h + .35, z, .14, .7, len / n + .02, [.95, .85, .7], { jit: .02 }); }
    for (const s of [-1, 1]) for (const zz of [-len / 2, len / 2]) g.box(bx + s * (wid / 2 - .1), 1.2, STREAM_Z + zz, .3, 1.4, .3, [.95, .82, .62]); }
  const gateNear = (x, z, d) => { for (let k = 0; k < m; k++) if (Math.hypot(x - px(gz(k)), z - gz(k)) < d) return true; return Math.hypot(x - px(EXIT_Z), z - EXIT_Z) < d || Math.hypot(x - px(Z0), z - Z0) < 6; };
  const roundTree = (x, z, s) => { const y = H(x, z), g = B.G(x, z), lc = T.leaf[(R() * T.leaf.length) | 0]; g.cyl(x, y + 1.1 * s, z, .22 * s, .32 * s, 2.2 * s, [.7, .5, .35], { seg: 6 });
    for (let i = 0; i < 3; i++) { const a = R() * 6.28, rr = i ? .7 * s : 0; g.sph(x + Math.cos(a) * rr, y + (2.6 + i * .55) * s, z + Math.sin(a) * rr, 1.5 * s, 1.2 * s, 1.5 * s, lc, { sway: .6, jit: .1, grad: .3 }); }
    if (R() < .4) g.sph(x + .8 * s, y + 3 * s, z + .5 * s, .18 * s, .18 * s, .18 * s, [1, .45, .45], { low: 1, e: .15, jit: 0 }); ph.box(x, y + 1.2 * s, z, .6 * s, 2.4 * s, .6 * s, { tag: 'tree' }); };
  let nt = 0; for (let k = 0; k < 600 && nt < 46; k++) { const x = -56 + R() * 112, z = -56 + R() * 112; if (onPath(x, z, 5) || Math.abs(z - STREAM_Z) < 7 || gateNear(x, z, 12)) continue; roundTree(x, z, .9 + R() * .6); nt++; }
  const hut = (x, z, ry, wall, roof) => { const y = H(x, z), g = B.G(x, z), c = Math.cos(ry), s = Math.sin(ry); g.box(x, y + 1.2, z, 4, 2.4, 3.4, wall, { ry, jit: .02 }); g.cone(x, y + 3.1, z, 3.5, 1.9, roof, { seg: 4, ry: ry + Math.PI / 4, jit: .02 });
    const f = (a, b) => [x + a * c + b * s, z - a * s + b * c]; const [dx, dz] = f(0, 1.72); g.box(dx, y + .8, dz, .9, 1.6, .1, [.6, .4, .25], { ry }); for (const sx of [-1.2, 1.2]) { const [wx, wz] = f(sx, 1.72); g.box(wx, y + 1.4, wz, .7, .6, .08, [.7, .9, 1], { ry, e: .25, jit: 0 }); }
    const [cx2, cz2] = f(1.2, -.6); g.box(cx2, y + 3.1, cz2, .5, 1.2, .5, [.82, .55, .45], { ry }); ph.box(x, y + 1.2, z, Math.abs(c) * 4 + Math.abs(s) * 3.4, 2.4, Math.abs(s) * 4 + Math.abs(c) * 3.4); };
  const WALL = [[1, .88, .8], [.85, .93, 1], [1, .95, .75], [.9, 1, .88]], ROOF = [[.9, .45, .45], [.45, .6, .9], [.95, .65, .35], [.6, .75, .5]];
  let nh = 0; for (let k = 0; k < 200 && nh < 3; k++) { const side = k % 2 ? 1 : -1, z = -30 + R() * 80, x = px(z) + side * (13 + R() * 14); if (gateNear(x, z, 14) || Math.abs(z - STREAM_Z) < 9 || Math.abs(x) > 52) continue; hut(x, z, side * (.4 + R()), WALL[(nh + zone.idx) % 4], ROOF[(nh + zone.idx) % 4]); nh++; }
  let nf = 0; for (let k = 0; k < 9000 && nf < 2600; k++) { const x = -58 + R() * 116, z = -58 + R() * 116; if (onPath(x, z, 2.4) || Math.abs(z - STREAM_Z) < 5) continue; const y = H(x, z); if (y < -.1) continue; const c = PAL[(R() * PAL.length) | 0], G = B.G(x, z), s = .8 + R() * .8;
    G.cyl(x, y + .22 * s, z, .015, .02, .44 * s, [.3, .65, .3], { seg: 3, jit: 0, sway: .8 }); G.sph(x, y + .47 * s, z, .15 * s, .09 * s, .15 * s, c, { low: 1, jit: .05, sway: .8, e: .05 }); G.sph(x, y + .5 * s, z, .04 * s, .03 * s, .04 * s, [1, .9, .3], { low: 1, jit: 0, sway: .8 }); nf++; }
  for (let k = 0; k < 90; k++) { const x = -58 + R() * 116, z = -58 + R() * 116; if (onPath(x, z, 2.2) || Math.abs(z - STREAM_Z) < 5 || H(x, z) < -.1 || gateNear(x, z, 5)) continue; bush(B, x, H(x, z), z, .6 + R() * .7, T.leaf[(R() * 4) | 0]); if (R() < .3) mushroom(B, x + 1, H(x + 1, z), z, .9, [1, .5, .55]); }
  for (let k = 0; k < 14; k++) { const x = -55 + R() * 110, z = -55 + R() * 110; if (onPath(x, z, 3) || Math.abs(z - STREAM_Z) < 6 || gateNear(x, z, 8)) continue; rock(B, x, H(x, z) - .1, z, .5 + R() * .6, [.78, .78, .74]); }
  for (let z = Z0 + 6; z < EXIT_Z; z += 12) for (const s of [-1, 1]) { const x = px(z) + s * 2.4, y = H(x, z), g = B.G(x, z); g.cyl(x, y + .7, z, .05, .06, 1.4, [.9, .8, .65], { seg: 4 }); g.sph(x, y + 1.5, z, .22, .22, .22, PAL[(((z + 60) / 12 | 0) + (s > 0 ? 1 : 0)) % PAL.length], { low: 1, e: .25, jit: 0 }); }
  // ===== بوابات الوحدات =====
  const STONE = [.93, .88, .8], GATES = [], hsv = h => { const f = (n, k = (n + h * 6) % 6) => .55 + .45 * Math.max(0, Math.min(k, 4 - k, 1)); return [f(5), f(3), f(1)]; };
  const mkGate = (cx, cz, k, unit, tint) => { const gy = H(cx, cz), g = B.G(cx, cz), F = B.FX(cx, cz);
    for (const s of [-1, 1]) { g.box(cx + s * 3, gy + 2.6, cz, 1.3, 5.2, 1.3, STONE, { grad: .1 }); g.box(cx + s * 3, gy + .3, cz, 1.8, .6, 1.8, [.85, .8, .7]); g.sph(cx + s * 3, gy + 5.5, cz, .55, .55, .55, tint, { e: .35, jit: 0 }); ph.box(cx + s * 3, gy + 2.6, cz, 1.3, 5.2, 1.3); }
    for (let i = 0; i <= 10; i++) { const a = Math.PI * i / 10; g.box(cx + Math.cos(a) * 3, gy + 5.2 + Math.sin(a) * 2.2, cz, 1.05, .95, 1.2, i % 2 ? STONE : [.97, .93, .85], { rz: a - Math.PI / 2 }); }
    g.sph(cx, gy + 7.8, cz, .5, .5, .5, tint, { e: .5, jit: 0 }); for (let i = 0; i < 5; i++) F.cone(cx, gy + 8.5, cz - .1, .18, .9, tint, { seg: 4, e: .8, rz: i * 1.2566, jit: 0 });
    for (const s of [-1, 1]) for (let x = 4; x < 60; x += 2.2) { const X = cx + s * x; if (Math.abs(X) > 58) break; const y = H(X, cz); g.sph(X, y + .9, cz, 1.3, 1, 1, T.leaf[(x / 2.2 | 0) % 4], { low: 1, jit: .08, sway: .3 }); if ((x / 2.2 | 0) % 4 === 0) g.sph(X + .3, y + 1.5, cz - .7, .14, .14, .14, PAL[(x / 2.2 | 0) % 6], { low: 1, e: .2, jit: 0 }); ph.box(X, y + 1, cz, 2.3, 2, 1.6, { nocam: 1 }); }
    B.light(cx, gy + 2, cz - 3, 11, [1, .9, .6], 1.0, .05);
    const mkLeaf = side => { const gg = new Geo(), o = -side * 1.2; gg.box(o, 2.3, 0, 2.3, 4.6, .22, [.78, .56, .36], { jit: .02 }); gg.box(o, 2.3, -.12, 2, 4.2, .06, [.9, .7, .5], { jit: 0 }); gg.sph(-side * 2.0, 2.2, -.2, .14, .14, .14, tint, { e: .3, jit: 0, low: 1 }); gg.sph(o, 3.4, -.15, .4, .4, .08, tint, { e: .3, jit: 0 }); const mm = new Mesh(r, gg); mm.side = side; return mm; };
    const portal = (() => { const gg = new Geo(); gg.box(0, 2.4, 0, 5.4, 4.8, .1, [.8, .95, 1], { e: .5, jit: 0 }); for (let i = 0; i < 6; i++) gg.sph(Math.sin(i * 2) * 1.8, 1 + i * .7, 0, .3, .3, .06, [1, .95, .6], { e: 1, soft: 1, jit: 0, low: 1 }); return new Mesh(r, gg, 'fx'); })();
    const arrow = (() => { const gg = new Geo(); gg.cone(0, 0, 0, .55, 1.1, tint, { seg: 4, e: .9, rx: Math.PI, jit: 0 }); return new Mesh(r, gg, 'fx'); })();
    return { k, unit, x: cx, y: gy, z: cz, leafL: mkLeaf(1), leafR: mkLeaf(-1), portal, arrow, doorBox: ph.box(cx, gy + 2.3, cz, 4.8, 4.6, .4), open: 0, want: 0 }; };
  zone.gates.forEach((u, k) => GATES.push(mkGate(px(gz(k)), gz(k), k, u, hsv((u.surah * .137 + u.k * .05) % 1))));
  // ===== بوابة الخروج (حلقة سحرية) =====
  const ey = H(px(EXIT_Z), EXIT_Z), EX = { x: px(EXIT_Z), y: ey, z: EXIT_Z, open: 0, want: 0 };
  { const g = B.G(EX.x, EX.z); for (let i = 0; i < 16; i++) { const a = Math.PI * 2 * i / 16; g.box(EX.x + Math.cos(a) * 3, ey + 3.4 + Math.sin(a) * 3, EX.z, .8, .8, .8, [.98, .8, .45], { rz: a, e: .15 }); } for (const s of [-1, 1]) ph.box(EX.x + s * 3, ey + 3.4, EX.z, .9, 7, .9); }
  EX.portal = (() => { const gg = new Geo(); for (let i = 0; i < 24; i++) { const a = Math.PI * 2 * i / 24, rr = 2.5 * (i % 3 === 0 ? 1 : .6); gg.sph(Math.cos(a) * rr, 3.4 + Math.sin(a) * rr, 0, .55, .55, .1, [.9, .85, 1], { e: 1, soft: 1, jit: 0, low: 1 }); } return new Mesh(r, gg, 'fx'); })();
  EX.block = ph.box(EX.x, ey + 3.4, EX.z, 5, 7, .5);
  // ===== صناديق ونجوم وجواهر =====
  const mkChest = (x, z, ry, id) => { const y = H(x, z), b = new Geo(), GOLD = [1, .82, .35]; b.box(0, .28, 0, .95, .56, .65, [.78, .52, .34], { jit: .02 }); b.box(0, .28, .34, .98, .12, .02, GOLD, { jit: 0, e: .2 }); b.box(0, .28, -.34, .98, .12, .02, GOLD, { jit: 0, e: .2 });
    const l = new Geo(); l.box(0, .13, .32, .97, .26, .66, [.86, .6, .38], { jit: .02 }); l.sph(0, .13, .64, .09, .09, .04, GOLD, { low: 1, e: .4, jit: 0 }); l.box(0, .13, .32, .06, .28, .68, GOLD, { jit: 0, e: .2 }); ph.box(x, y + .3, z, 1.1, .6, 1.1); return { id, x, y, z, ry, open: 0, body: new Mesh(r, b), lid: new Mesh(r, l) }; };
  const chests = []; for (let k = 0, c = 0; k < 200 && c < 3; k++) { const side = k % 2 ? 1 : -1, z = -30 + R() * 80, x = px(z) + side * (5 + R() * 9); if (gateNear(x, z, 8) || Math.abs(z - STREAM_Z) < 8 || onPath(x, z, 3) || H(x, z) < 0) continue; if (!ph.near(x, z, 2.5).size) { chests.push(mkChest(x, z, R() * 6, `z${zone.idx}c${c}`)); c++; } }
  const addItem = (kind, id, x, z, dy = 1.1) => ITEMS.push({ kind, id, x, y: H(x, z) + dy, z, r: 1.2, taken: false });
  let si = 0; for (let z = Z0 + 4; z < EXIT_Z; z += 4.6) { if (GATES.some(g => Math.abs(g.z - z) < 3.2) || Math.abs(z - STREAM_Z) < 7) continue; addItem('star', `z${zone.idx}s${si}`, px(z) + Math.sin(si * 1.7) * 1.3, z, 1.1 + (si % 2) * .4); si++; }
  for (let k = 0, c = 0; k < 300 && c < 8; k++) { const x = -50 + R() * 100, z = -45 + R() * 95; if (onPath(x, z, 3) || gateNear(x, z, 6) || H(x, z) < 0 || Math.abs(z - STREAM_Z) < 8 || ph.near(x, z, 2).size) continue; addItem('gem', `z${zone.idx}g${c}`, x, z, .9); c++; }
  const rainbow = (() => { const g = new Geo(), cols = [[1, .4, .4], [1, .7, .35], [1, .95, .45], [.5, .9, .5], [.45, .75, 1], [.7, .55, 1]]; cols.forEach((c, k) => { const rr = 16 - k * .75; for (let i = 0; i < 30; i++) { const a = Math.PI * i / 29; g.box(Math.cos(a) * rr, Math.sin(a) * rr, 0, .9, .8, .3, c, { e: .45, jit: 0, rz: a }); } }); const mm = new Mesh(r, g, 'fx'); mm.model = mT(EX.x, ey - 1, EX.z - 14); mm.visible = false; return mm; })();
  const clouds = []; for (let i = 0; i < 7; i++) { const g = new Geo(), cx = (R() - .5) * 150, cz = (R() - .5) * 150; for (let k = 0; k < 5; k++) g.sph((k - 2) * 3, (k % 2) * .8, R() * 2, 4 + R() * 2, 2 + R(), 3, [1, 1, 1], { e: .55, soft: 1, jit: 0 }); const mm = new Mesh(r, g, 'fx'); mm.cx = cx; mm.cz = cz; mm.cy = 38 + R() * 12; clouds.push(mm); }
  B.scatterParticles(160, -58, -58, 116, 116, (x, z) => H(x, z), [[1, .6, .8], [1, .9, .4], [.6, .8, 1]], .7, 0, 5, 3 + zone.idx);
  GATES.forEach(g => B.scatterParticles(30, g.x - 6, g.z - 7, 12, 12, (x, z) => H(x, z), [[1, .85, .4], [1, .7, .9]], 1, 1, 7, 4 + g.k));
  B.light(EX.x, ey + 3, EX.z - 1, 10, [.9, .85, 1], .9, 0);
  const fin = B.finish();
  return { ...fin, items: ITEMS, chests, clouds, H, gates: GATES, exit: EX, rainbow, spawn: [px(Z0), H(px(Z0), Z0) + .1, Z0], B, bounds: 58, theme: T, gz, zone };
}
