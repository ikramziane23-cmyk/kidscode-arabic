const { chromium } = require('playwright'); const S = '/home/claude/rabbit-game/shots';
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
  const p = await b.newPage({ viewport: { width: 1000, height: 600 } }); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type() === 'error' && errs.push(m.text()));
  await p.goto('file:///home/claude/rabbit-game/dist/rabbit-game.html'); await p.waitForFunction(() => !document.getElementById('bStart').disabled, { timeout: 60000 }); await p.screenshot({ path: S + '/t_title.png' });
  await p.click('#bStart'); await p.waitForTimeout(1500); await p.screenshot({ path: S + '/t_spawn.png' });
  const pos = () => p.evaluate(() => { const c = __game.ch; return { x: +c.x.toFixed(2), y: +c.y.toFixed(2), z: +c.z.toFixed(2), og: c.onGround, sp: +c.speed.toFixed(2) }; });
  const a = await pos(); await p.keyboard.down('KeyW'); await p.waitForTimeout(2500); const w = await pos(); await p.screenshot({ path: S + '/t_walk.png' });
  await p.keyboard.press('Space'); await p.waitForTimeout(250); const j = await pos(); await p.keyboard.up('KeyW');
  console.log(JSON.stringify({ a, w, j })); console.log('errors', JSON.stringify(errs.slice(0, 6)), 'fps', await p.evaluate(() => __game.fps));
  await b.close();
})();
