// اختبار المنهج والمناطق والصوت لكل السور + الانتقال بين المناطق والمراجعة (بوابات حقيقية + مشي).
const { chromium } = require('playwright'); const S = '/home/claude/rabbit-game/shots';
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
  const p = await b.newPage({ viewport: { width: 900, height: 560 } }); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type() === 'error' && errs.push(m.text()));
  await p.goto('file:///home/claude/rabbit-game/dist/rabbit-game.html'); await p.waitForFunction(() => !document.getElementById('bStart').disabled, { timeout: 90000 }); await p.click('#bStart');
  await p.evaluate(() => { __game.noRender = true; __game.Voice.on = false; });
  const out = {};
  out.cur = await p.evaluate(() => ({ units: __game.cur.units.length, zones: __game.cur.zones.map(z => z.gates.length), skipped: __game.cur.skipped, missing: __game.cur.missing, surahs: __game.cur.surahs.length }));
  // 1) كل سورة: الصوت يُحمَّل وتغطي الحدود الملف ولا تتجاوز مدته؛ كل وحدة ≤4 آيات ومجموعها يغطي السورة بلا تكرار
  out.audio = await p.evaluate(async () => { const G = __game, bad = []; for (const n of G.cur.surahs) { const m = G.QA.meta(n), a = new Audio(new URL(m.file, document.baseURI).href); await new Promise(r => { a.onloadedmetadata = r; a.onerror = () => { bad.push([n, 'load']); r(); }; setTimeout(r, 8000); }); const last = m.segs[m.segs.length - 1][1]; if (!(a.duration >= last - 0.05)) bad.push([n, 'dur', a.duration, last]); if (m.segs.length !== G.Q.surahs[n - 1].ayat.length) bad.push([n, 'count']); const us = G.cur.units.filter(u => u.surah === n); let nxt = 0; for (const u of us) { if (u.from !== nxt || u.to - u.from + 1 > 4) bad.push([n, 'unit', u.id]); nxt = u.to + 1; } if (nxt !== m.segs.length) bad.push([n, 'cover']); } return bad; });
  // 2) المناطق: بنِ كل منطقة وتحقق من بواباتها وعناصرها وأنه لا أخطاء
  out.zones = [];
  for (let i = 0; i < out.cur.zones.length; i++) { out.zones.push(await p.evaluate(i => { const G = __game; G.P.reset(); (window.loadZ || (() => { }))(); G.T.c.gotoZone(i); const W = G.W; return [i, W.gates.length, W.items.length, W.chests.length, W.gates.map(g => g.unit.surah).join(',')].join('|'); }, i)); }
  console.log(JSON.stringify(out, null, 0)); console.log('errors', JSON.stringify(errs.slice(0, 5))); await b.close();
})();
