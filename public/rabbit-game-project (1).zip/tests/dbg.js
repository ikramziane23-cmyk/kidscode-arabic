const { chromium } = require('playwright');
(async () => { const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] }); const p = await b.newPage(); p.on('console', m => console.log('LOG', m.text().slice(0, 300)));
await p.goto('file:///home/claude/rabbit-game/dist/rabbit-game.html'); await p.waitForFunction(() => !document.getElementById('bStart').disabled, { timeout: 60000 });
console.log(JSON.stringify(await p.evaluate(() => __game.W.lit.map(m => [m.count, m.itype === 5125 ? 'u32' : 'u16', m.b.c.map(v => +v.toFixed(0)), +m.b.r.toFixed(0)]))));
await b.close(); })();
