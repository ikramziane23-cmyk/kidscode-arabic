// اختبار مسار البوابة كاملًا مع الصوت الحقيقي: اسم السورة ← استماع ← تكرار ← تحدٍّ ← مكافأة.
const { chromium } = require('playwright'); const S = '/home/claude/rabbit-game/shots';
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
  const p = await b.newPage({ viewport: { width: 900, height: 560 } }); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type() === 'error' && errs.push(m.text()));
  await p.goto('file:///home/claude/rabbit-game/dist/rabbit-game.html'); await p.waitForFunction(() => !document.getElementById('bStart').disabled, { timeout: 60000 }); await p.click('#bStart');
  await p.evaluate(() => { __game.noRender = true; __game.Voice.on = false; }); // الاختبار: بدون نطق المتصفح؛ التلاوة الحقيقية تُشغَّل
  const log = []; const stage = () => p.evaluate(() => __game.sess.stage);
  // الوصول إلى البوابة بالمشي الحقيقي: انقل الأرنب قرب البوابة ثم تحرّك للأمام بلوحة المفاتيح
  await p.evaluate(() => { const G = __game; const g = G.W.gates[0]; G.ch.teleport(g.x, 1, g.z - 9); G.snap = 3; }); await p.keyboard.down('KeyW');
  await p.waitForFunction(() => __game.sess.on, { timeout: 15000 }); await p.keyboard.up('KeyW'); log.push('opened:' + await stage());
  await p.waitForSelector('#bGo'); await p.screenshot({ path: S + '/g_intro.png' }); log.push('voiceSaid:' + await p.evaluate(() => __game.Voice.last));
  await p.click('#bGo', { force: true }); log.push('stage:' + await stage());
  // استماع: شغّل وانتظر انتهاء التلاوة الحقيقية (الكوثر ~14 ثانية)
  await p.click('#bPlay'); await p.waitForTimeout(2500); log.push('playing:' + JSON.stringify(await p.evaluate(() => ({ t: +__game.QA.a.currentTime.toFixed(2), paused: __game.QA.a.paused, txt: document.getElementById('ayahText').textContent.slice(0, 20) }))));
  await p.screenshot({ path: S + '/g_listen.png' }); log.push('nextDisabledBefore:' + await p.evaluate(() => document.getElementById('bNext').hasAttribute('disabled')));
  await p.waitForFunction(() => !document.getElementById('bNext').hasAttribute('disabled'), { timeout: 40000 }); log.push('clips:' + JSON.stringify(await p.evaluate(() => __game.QA.log)));
  await p.click('#bNext', { force: true }); log.push('stage:' + await stage());
  for (let k = 0; k < 3; k++) { await p.waitForFunction(() => !document.getElementById('bMic').hasAttribute('disabled'), { timeout: 20000 }); if (k === 0) await p.screenshot({ path: S + '/g_repeat.png' }); await p.click('#bMic', { force: true }); await p.waitForTimeout(300); }
  log.push('stage:' + await stage()); await p.waitForSelector('.opt'); await p.waitForTimeout(1500); await p.screenshot({ path: S + '/g_quiz.png' });
  // سؤال 1: اختر الخطأ أولًا ثم الصحيح
  const answer = async (wantOk) => { const card = p.locator(`.opt[data-ok="${wantOk ? 1 : 0}"]`); await card.locator('.ocard').click({ force: true }); await p.waitForTimeout(400); await card.locator('.chk').click({ force: true }); };
  await p.waitForTimeout(500); await answer(false); await p.waitForTimeout(700); log.push('msgAfterWrong:' + await p.evaluate(() => document.getElementById('msg').textContent)); await p.screenshot({ path: S + '/g_wrong.png' }); log.push('voiceAfterWrong:' + await p.evaluate(() => __game.Voice.last));
  await p.waitForTimeout(800); await answer(true); await p.waitForTimeout(1200); log.push('q:' + await p.evaluate(() => __game.sess.qi));
  for (let q = 1; q < 3; q++) { await p.waitForSelector('.opt'); await p.waitForTimeout(1200); await answer(true); await p.waitForTimeout(1400); }
  await p.waitForFunction(() => __game.sess.stage === 'reward', { timeout: 15000 }); log.push('stage:' + await stage()); await p.screenshot({ path: S + '/g_reward.png' });
  await p.click('#bFinish', { force: true }); await p.waitForTimeout(600);
  log.push('after:' + JSON.stringify(await p.evaluate(() => ({ gateWant: __game.W.gates[0].want, unit: __game.P.unitDone('114:0'), done: __game.P.done(114), stars: __game.P.d.stars, s114: __game.P.d.surahs[114], sessOn: __game.sess.on, inpEnabled: __game.inp.enabled }))));
  console.log(log.join('\n')); console.log('errors', JSON.stringify(errs.slice(0, 5))); await b.close();
})();
