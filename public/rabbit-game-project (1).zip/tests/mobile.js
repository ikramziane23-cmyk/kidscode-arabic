// محاكاة هاتف Android أفقي: عصا التحكم باللمس، زر القفز، حجم الأزرار، ملاءمة لوحة البوابة للشاشة.
const { chromium, devices } = require('playwright'); const S = '/home/claude/rabbit-game/shots';
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
  const ctx = await b.newContext({ viewport: { width: 851, height: 393 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: devices['Pixel 5'].userAgent });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message)); const cdp = await ctx.newCDPSession(p);
  await p.goto('file:///home/claude/rabbit-game/dist/rabbit-game.html'); await p.waitForFunction(() => !document.getElementById('bStart').disabled, { timeout: 60000 });
  await p.tap('#bStart'); await p.waitForTimeout(800); const out = {};
  const T = (type, pts) => cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts });
  const pos = () => p.evaluate(() => { const c = __game.ch; return { x: +c.x.toFixed(2), z: +c.z.toFixed(2), y: +c.y.toFixed(2), og: c.onGround }; });
  out.start = await pos();
  await T('touchStart', [{ x: 140, y: 300, id: 1 }]); await T('touchMove', [{ x: 140, y: 250, id: 1 }]); await p.waitForTimeout(1800); out.joyOn = await p.evaluate(() => document.getElementById('joy').classList.contains('on')); await p.screenshot({ path: S + '/m_joy.png' });
  out.moved = await pos(); await T('touchEnd', []); await p.waitForTimeout(700); out.stopped = await pos(); await p.waitForTimeout(300); out.stopped2 = await pos();
  const jb = await p.$eval('#bJump', e => { const r = e.getBoundingClientRect(); return [r.x + r.width / 2, r.y + r.height / 2, r.width]; }); out.jumpBtn = jb;
  await T('touchStart', [{ x: jb[0], y: jb[1], id: 2 }]); await T('touchEnd', []); await p.waitForTimeout(280); out.air = await pos(); await p.waitForTimeout(1200); out.landed = await pos();
  // تحريك الجويستيك + القفز معًا
  await T('touchStart', [{ x: 140, y: 300, id: 1 }]); await T('touchMove', [{ x: 160, y: 255, id: 1 }]); await p.waitForTimeout(500); await T('touchStart', [{ x: 140, y: 300, id: 1 }, { x: jb[0], y: jb[1], id: 2 }]); await p.waitForTimeout(200); out.both = await pos(); await T('touchEnd', []);
  // الذهاب إلى البوابة وفتح الجلسة واختبار الأحجام
  await p.evaluate(() => { const G = __game; const g = G.W.gates[0]; G.ch.teleport(g.x, 1, g.z - 5); G.snap = 3; }); await p.waitForFunction(() => __game.sess.on, { timeout: 10000 });
  await p.waitForSelector('#bGo'); await p.screenshot({ path: S + '/m_gate.png' });
  const sizes = async () => p.$$eval('#gate button', bs => bs.filter(b => b.offsetParent).map(b => [b.id || b.className.slice(0, 12), Math.round(b.getBoundingClientRect().width), Math.round(b.getBoundingClientRect().height)]));
  out.introBtns = await sizes(); out.panelFits = await p.$eval('.gpanel', e => { const r = e.getBoundingClientRect(); return [Math.round(r.top), Math.round(r.bottom), innerHeight, e.scrollHeight <= e.clientHeight + 2]; });
  await p.tap('#bGo'); await p.waitForTimeout(300); await p.tap('#bPlay'); await p.waitForTimeout(1500); await p.screenshot({ path: S + '/m_listen.png' }); out.listenFits = await p.$eval('.gpanel', e => [e.scrollHeight <= e.clientHeight + 2, e.scrollHeight, e.clientHeight]);
  await p.evaluate(() => __game.sess.go('quiz')); await p.waitForSelector('.opt'); await p.waitForTimeout(1500); await p.screenshot({ path: S + '/m_quiz.png' }); out.quizFits = await p.$eval('.gpanel', e => [e.scrollHeight <= e.clientHeight + 2, e.scrollHeight, e.clientHeight]); out.quizBtns = await sizes();
  // تحدٍّ بالمس: اختيار الصحيح
  const ok = p.locator('.opt[data-ok="1"]'); await ok.locator('.ocard').tap(); await p.waitForTimeout(500); await ok.locator('.chk').tap({ force: true }); await p.waitForTimeout(900); out.qiAfter = await p.evaluate(() => __game.sess.qi);
  console.log(JSON.stringify(out, null, 1)); console.log('errors', JSON.stringify(errs.slice(0, 5)), 'fps', await p.evaluate(() => __game.fps)); await b.close();
})();
