const { chromium } = require('playwright'); const S = '/home/claude/rabbit-game/shots';
(async () => { const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const p = await b.newPage({ viewport: { width: 700, height: 500 } }); await p.goto('file:///home/claude/rabbit-game/dist/rabbit-game.html'); await p.waitForFunction(() => !document.getElementById('bStart').disabled, { timeout: 60000 }); await p.click('#bStart');
for (const [n, cy] of [['back', 0], ['front', Math.PI]]) { await p.evaluate(cy => { const G = __game; G.armed = false; G.cam.dist = 2.6; G.cam.pitch = .15; G.cam.yaw = cy; G.snap = 3; G.ch.yaw = 0; }, cy); await p.waitForTimeout(900); await p.screenshot({ path: S + '/r_' + n + '.png', clip: { x: 150, y: 50, width: 400, height: 400 } }); }
await b.close(); })();
