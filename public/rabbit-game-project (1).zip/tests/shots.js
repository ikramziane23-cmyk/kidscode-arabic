const { chromium } = require('playwright'); const S = '/home/claude/rabbit-game/shots';
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
  const p = await b.newPage({ viewport: { width: 1000, height: 600 } }); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto('file:///home/claude/rabbit-game/dist/rabbit-game.html'); await p.waitForFunction(() => !document.getElementById('bStart').disabled, { timeout: 60000 }); await p.click('#bStart');
  await p.evaluate(() => { __game.armed = false; __game.cam.dist = 3.8; __game.cam.pitch = .25; }); await p.waitForTimeout(1200); await p.screenshot({ path: S + '/s_close.png' });
  await p.evaluate(() => { __game.cam.dist = 5.6; __game.cam.pitch = .42; const G = __game; G.ch.teleport(G.W.gate.x, 1, G.W.gate.z - 12); G.snap = 3; }); await p.waitForTimeout(1200); await p.screenshot({ path: S + '/s_gate.png' });
  console.log(errs); await b.close();
})();
