const { chromium } = require('playwright'); const S = '/home/claude/rabbit-game/shots';
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
  const p = await b.newPage({ viewport: { width: 1000, height: 600 } }); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto('file:///home/claude/rabbit-game/dist/rabbit-game.html'); await p.waitForFunction(() => !document.getElementById('bStart').disabled, { timeout: 90000 }); await p.click('#bStart');
  await p.evaluate(() => { const G = __game, g = G.W.gates[0]; G.ch.teleport(g.x, 1, g.z - 12); G.snap = 3; }); await p.waitForTimeout(1500); await p.screenshot({ path: S + '/z0.png' });
  const t0 = Date.now(); await p.evaluate(() => { __game.T.c.gotoZone(3); }); const ms = Date.now() - t0; await p.evaluate(() => { const G = __game, g = G.W.gates[0]; G.ch.teleport(g.x, 1, g.z - 10); G.snap = 3; }); await p.waitForTimeout(1500); await p.screenshot({ path: S + '/z3.png' });
  console.log('zoneBuildMs', ms, 'fps', await p.evaluate(() => __game.fps), errs); await b.close();
})();
