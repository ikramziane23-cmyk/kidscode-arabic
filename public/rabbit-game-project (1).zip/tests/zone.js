const { chromium } = require('playwright'); const S = '/home/claude/rabbit-game/shots';
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
  const p = await b.newPage({ viewport: { width: 900, height: 560 } }); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type() === 'error' && errs.push(m.text()));
  await p.goto('file:///home/claude/rabbit-game/dist/rabbit-game.html'); await p.waitForFunction(() => !document.getElementById('bStart').disabled, { timeout: 90000 }); await p.click('#bStart');
  await p.evaluate(() => { __game.noRender = true; __game.Voice.on = false; }); const out = {};
  // بوابة مقفلة: الثانية قبل إكمال الأولى
  await p.evaluate(() => { const G = __game, g = G.W.gates[1]; G.ch.teleport(g.x, 1, g.z - 9); G.snap = 3; }); await p.keyboard.down('KeyW'); await p.waitForTimeout(2500); await p.keyboard.up('KeyW');
  out.locked = await p.evaluate(() => ({ sessOn: __game.sess.on, toast: document.getElementById('toast').textContent, banner: document.getElementById('gname').textContent }));
  // أكمل بوابات المنطقة (تخطّي المعلمة) ثم اذهب إلى الخروج
  await p.evaluate(() => { const G = __game; for (let i = 0; i < 5; i++) G.T.c.skipGate(); G.W.gates.forEach(g => g.open = 1); });
  out.afterSkip = await p.evaluate(() => ({ units: __game.W.gates.map(g => __game.P.unitDone(g.unit.id)), rainbow: __game.W.rainbow.visible, exitBlock: __game.W.exit.block.active }));
  await p.evaluate(() => { const G = __game, e = G.W.exit; G.ch.teleport(e.x, 1, e.z - 9); G.snap = 3; }); await p.keyboard.down('KeyW'); await p.waitForFunction(() => __game.sess.on, { timeout: 15000 }); await p.keyboard.up('KeyW');
  out.review = await p.evaluate(() => ({ stage: __game.sess.stage, review: !!__game.sess.review, qs: __game.sess.Qs.length })); await p.waitForSelector('.opt'); await p.waitForTimeout(1200);
  const answer = async () => { const card = p.locator('.opt[data-ok="1"]'); await card.locator('.ocard').click({ force: true }); await p.waitForTimeout(400); await card.locator('.chk').click({ force: true }); };
  for (let q = 0; q < out.review.qs; q++) { await p.waitForSelector('.opt'); await p.waitForTimeout(1300); await answer(); await p.waitForTimeout(1500); }
  await p.waitForFunction(() => __game.sess.stage === 'reward', { timeout: 15000 }); await p.click('#bFinish', { force: true }); await p.waitForTimeout(500);
  out.exit = await p.evaluate(() => ({ want: __game.W.exit.want, rev: __game.rev, block: __game.W.exit.block.active })); 
  await p.evaluate(() => { const G = __game, e = G.W.exit; G.ch.teleport(e.x, 1, e.z - 5); G.snap = 3; }); await p.keyboard.down('KeyW'); await p.waitForFunction(() => __game.zi === 1, { timeout: 15000 }); await p.keyboard.up('KeyW');
  out.zone2 = await p.evaluate(() => ({ zi: __game.zi, gates: __game.W.gates.map(g => g.unit.surah), P: __game.P.d.zone, active: __game.W.gates.find(g => !__game.P.unitDone(g.unit.id)).unit.id, canMove: __game.inp.enabled }));
  console.log(JSON.stringify(out, null, 1)); console.log('errors', JSON.stringify(errs.slice(0, 5))); await b.close();
})();
