# يبني assets/audio/manifest.json من نتائج التقسيم ويفحص سلامتها. السور ذات الثقة المنخفضة تُعلَّم risky ولا تدخل المنهج قبل مراجعتها.
import json, shutil, os
seg=json.load(open('tools/seg_all.json')); q=json.load(open('assets/quran.json')); os.makedirs('assets/audio',exist_ok=True)
man={"reciter":"ياسين الجزائري","riwaya":"ورش عن نافع","note":"التقسيم تلقائي وغير مُراجَع بالسمع؛ risky = ثقة منخفضة (تُستبعد من اللعب حتى تُراجَع). لإضافة سورة: ضع mp3 وأضف مدخلًا.","voice":{},"surahs":{}}
bad=[]
for n,r in sorted(seg.items(),key=lambda x:int(x[0])):
    n=int(n); segs=[[a,min(b,round(r['dur'],2))] for a,b in r['segs']]; cnt=len(q[n-1][1])
    assert len(segs)==cnt,(n,len(segs),cnt)
    ok=all(segs[i][1]<=segs[i+1][0]+1e-6 and segs[i][0]<segs[i][1] for i in range(cnt-1)) and all(s[1]-s[0]>=0.8 for s in segs) and segs[-1][1]<=r['dur']+.05
    risky=(not ok) or min(r['conf'] or [9])<0.5 or max(r['ratio'])>1.8 or min(r['ratio'])<0.5
    man['surahs'][str(n)]={"file":f"audio/{n:03d}.mp3","segs":segs,"conf":r['conf'],"ratio":r['ratio'],"intro":r['intro'],"verified":False,"risky":bool(risky)}
    shutil.copy(f'src_audio/{n:03d}.mp3',f'assets/audio/{n:03d}.mp3')
    if risky: bad.append(n)
for f in os.listdir('assets/audio'):
    if f.endswith('.mp3') and str(int(f[:3])) not in man['surahs']: os.remove('assets/audio/'+f)
json.dump(man,open('assets/audio/manifest.json','w'),ensure_ascii=False,indent=1)
print('surahs',len(man['surahs']),'risky',bad)
