# تقسيم تسجيل سورة كاملة إلى آيات: غلاف طاقة + برمجة ديناميكية تطابق أطوال الآيات (بعدد الحروف). تلقائي وغير مُراجَع بالسمع.
import sys, json, subprocess, re, numpy as np
from scipy.ndimage import uniform_filter1d
def load(path):
    raw = subprocess.run(['ffmpeg','-v','error','-i',path,'-ac','1','-ar','8000','-f','s16le','-'],capture_output=True).stdout
    return np.frombuffer(raw,dtype=np.int16).astype(np.float32)/32768
def letters(t): return len(re.findall('[ء-ي]', t))
def segment(path, ayat, intro_max=16.0):
    x=load(path); hop=200; dt=hop/8000; nf=len(x)//hop
    e=uniform_filter1d(np.log(np.sqrt((x[:nf*hop].reshape(nf,hop)**2).mean(1))+1e-5),3)
    n=len(ayat); L=np.array([letters(a) for a in ayat],float)
    thr=np.percentile(e,20)+0.3*(np.percentile(e,95)-np.percentile(e,20)); sp=np.where(e>thr)[0]; first,end=int(sp[0]),int(sp[-1])
    w=int(0.35/dt); cs=[]; dep={}
    for i in range(w,nf-w):
        if e[i]==e[i-w:i+w+1].min():
            d=min(e[i-w:i].max(),e[i+1:i+w+1].max())-e[i]
            if d>0.2: cs.append(i); dep[i]=d
    starts=[first]+[c for c in cs if c*dt<intro_max]; best=None
    for s in starts:
        pts=np.array([s]+[c for c in cs if c>s+int(0.5/dt)]+[end]); N=len(pts); k=(end-s)*dt/L.sum()
        bonus=np.array([0.35*dep.get(int(p),0) for p in pts]); bonus[-1]=0
        D=(pts[:,None]-pts[None,:])*dt  # D[m,p]
        f=np.full(N,1e18); f[0]=0; bks=[]
        for j in range(n):
            ex=k*L[j]; with_ok=D>0.3; cost=np.where(with_ok,np.log(np.where(with_ok,D,1)/ex)**2,1e18)
            tot=f[None,:]+cost; bk=tot.argmin(1); nf_=tot.min(1)-bonus; nf_[0]=1e18; f=np.minimum(nf_,1e18); bks.append(bk)
        if f[N-1]<1e17 and (best is None or f[N-1]<best[0]):
            idx=[N-1]
            for j in range(n-1,-1,-1): idx.append(bks[j][idx[-1]])
            best=(float(f[N-1]),[int(pts[i]) for i in idx[::-1]],k)
    if not best: return None
    b=best[1]; k=best[2]; segs=[[round(b[i]*dt,2),round(b[i+1]*dt,2)] for i in range(n)]
    ratio=[round((b[i+1]-b[i])*dt/(k*L[i]),2) for i in range(n)]; conf=[round(float(dep.get(b[i+1],0)),2) for i in range(n-1)]
    return {'segs':segs,'conf':conf,'ratio':ratio,'cost':round(best[0],2),'dur':round(len(x)/8000,2),'intro':round(b[0]*dt,2)}
if __name__=='__main__':
    q=json.load(open(sys.argv[1])); res={}
    for spec in sys.argv[3:]:
        n,path=spec.split('=',1); r=segment(path,q[int(n)-1][1]); res[n]=r
    json.dump(res,open(sys.argv[2],'w'),ensure_ascii=False)
