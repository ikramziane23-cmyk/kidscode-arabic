#!/usr/bin/env python3
"""يولّد src/data/tajweed-examples.json من public/data/warsh-ayat.json (نص ورش).
لا تُكتب أي آية يدويًا: كل مثال إحداثيات (سورة، آية، فهرس كلمة) + الكلمة المقتبسة آليًا
ليتحقق الاختبار من أنها ما زالت مطابقة للنص. شغّله من جذر المشروع:  python3 scripts/gen-tajweed-examples.py
"""
import json, re, sys, random

SRC = 'public/data/warsh-ayat.json'
OUT = 'src/data/tajweed-examples.json'
Q = json.load(open(SRC, encoding='utf-8'))
AY = [(s['n'], i + 1, t.split(' ')) for s in Q for i, t in enumerate(s['ayat'])]
PAUSE = re.compile('[ۖ-ۜ۩]')
LET = 'ء-يٱ-ۓ'
TW = 'ًٌٍٖٞٗ'
HALQI, IDG_G, IDG_N = 'هعحغخ', 'ينمو', 'لر'
IKH = 'تثجدذزسشصضطظفقك'
HAMZA = 'أإء'

def first_letter(w):
    m = re.search('[' + LET + ']', w); return m.group(0) if m else ''
def end_info(w):
    m = re.search('([' + LET + '])([ً-ٰٟ۝-ۭ]*)$', w); return (m.group(1), m.group(2)) if m else None
def strip_pause(w): return PAUSE.sub('', w)

def classify4(A, B):
    if PAUSE.search(A): return None
    e = end_info(A)
    if not e: return None
    l, mk = e; iq = 'ۢ' in mk
    if any(c in mk for c in TW): kind = 'tanween'
    elif iq: kind = 'noon' if l == 'ن' else 'tanween'
    elif l == 'ن' and mk in ('', 'ْ'): kind = 'noon'
    else: return None
    L = first_letter(B)
    if not L: return None
    if L == 'ب': cat = 'iqlab'
    elif L in HALQI: cat = 'idhar'
    elif L in IDG_G: cat = 'idghamG'
    elif L in IDG_N: cat = 'idghamN'
    elif L in IKH: cat = 'ikhfa'
    else: return None
    if iq != (cat == 'iqlab'): return None
    return cat

def classify5(A, B):
    if PAUSE.search(A): return None
    e = end_info(A)
    if not e or e[0] != 'م': return None
    mk = e[1]; L = first_letter(B); B0 = re.sub('^[^' + LET + ']+', '', B)[:1]
    if len(mk) == 3 and all(c in mk for c in 'ُۥٓ'):
        return 'silah' if B0 in HAMZA else None
    if mk not in ('', 'ْ'): return None
    if L == 'م': return 'idgham'
    if mk == 'ْ' and L and L not in 'بما' and B0 not in HAMZA: return 'idhar'
    return None

MC = '[ً-ٰٟۖ-ۜ۟۠ۥۦ]*'
RE_MUT = re.compile('[اويى]' + MC + 'ٓ' + MC + '[أإؤئء]')
RE_LAZ = re.compile('[اويى]ٓ([' + LET + '])([ً-ٰٟ]*)')
RE_MUN_A = re.compile('[اوىيے]' + MC + 'ٓ' + MC + '$')

def short(ws): return len(ws) <= 14

out = {}
def add(lesson, s, a, i, n=1, extra=None):
    if any(e['s']==s and e['a']==a and e['i']==i for e in out.get(lesson, [])): return
    ws = dict(s=s, a=a, i=i, n=n)
    ayw = next(w for (ss, aa, w) in AY if ss == s and aa == a)
    ws['w'] = ' '.join(ayw[i:i + n])
    if extra: ws.update(extra)
    out.setdefault(lesson, []).append(ws)

def pick(lesson, cands, k=6, seed=1):
    """يختار k أمثلة متنوعة السور من المرشحين (بترتيب حتمي)."""
    rnd = random.Random(seed); rnd.shuffle(cands)
    seen, res = set(), []
    for c in cands:
        if c[0] in seen: continue
        seen.add(c[0]); res.append(c)
        if len(res) == k: break
    for c in res: add(lesson, *c)

# ---- النون والتنوين
buckets = {k: [] for k in ('idhar', 'iqlab', 'idghamG', 'idghamN', 'ikhfa')}
mb = {k: [] for k in ('idgham', 'idhar', 'silah')}
for s, a, ws in AY:
    if not short(ws): continue
    for i in range(len(ws) - 1):
        c = classify4(ws[i], ws[i + 1])
        if c: buckets[c].append((s, a, i, 2))
        c = classify5(ws[i], ws[i + 1])
        if c: mb[c].append((s, a, i, 2))
for lid, cat in (('noon-idhar', 'idhar'), ('noon-idgham-ghunna', 'idghamG'), ('noon-idgham-bila', 'idghamN'), ('noon-ikhfa', 'ikhfa'), ('noon-iqlab', 'iqlab')):
    pick(lid, buckets[cat], 6)
pick('meem-idhar', mb['idhar'], 6); pick('meem-idgham', mb['idgham'], 6)
pick('madd-silat-meem', mb['silah'], 6)

# ---- القلقلة
Q5 = 'قطبجد'
sug, kub = [], []
for s, a, ws in AY:
    if len(ws) > 12: continue
    for i, w in enumerate(ws):
        w2 = strip_pause(w)
        if re.search('[' + Q5 + ']ْ[' + LET + ']', w2) and i < len(ws) - 1: sug.append((s, a, i, 1))
    last = strip_pause(ws[-1])
    m = re.search('([' + LET + '])([ً-ٰٟ۝-ۭ]*)$', last)
    if m and m.group(1) in Q5 and 'ّ' in m.group(2) is False: pass
    if m and m.group(1) in Q5: kub.append((s, a, len(ws) - 1, 1))
pick('qalqala-sughra', sug, 6); pick('qalqala-kubra', kub, 6)

# ---- المدود (بالمُحدّدات المختبرة سابقًا + كواشف)
def word(s, a, i):
    return next(w for (ss, aa, w) in AY if ss == s and aa == a)[i]
FIX = {
    'madd-tabii': [(2, 29, 1), (2, 10, 1), (2, 116, 7), (7, 68, 17)],
    'madd-badal': [(2, 24, 2), (3, 33, 3), (2, 36, 1), (2, 12, 5)],
    'madd-arid': [(1, 1, 3), (1, 2, 1), (1, 3, 2), (2, 12, 18)],
    'madd-muttasil': [(4, 43, 26), (2, 18, 3), (2, 48, 6), (2, 19, 14)],
    'madd-lazim': [(69, 1, 0), (79, 34, 2), (2, 163, 32)],
    'madd-munfasil': [(2, 3, 2), (2, 40, 1), (2, 8, 6), (2, 19, 9), (2, 89, 6), (66, 6, 3)],
    'madd-leen': [(2, 19, 23)],
}
mut, laz, mun = [], [], []
for s, a, ws in AY:
    if len(ws) > 14: continue
    for i, w0 in enumerate(ws):
        w = re.sub('^[۞ ]+', '', w0)
        if PAUSE.search(w) or re.match('^يَٰ|^هَٰٓ', w): continue
        m = RE_LAZ.search(w)
        if m and 'ّ' in m.group(2) and i < len(ws) - 1: laz.append((s, a, i, 1)); continue
        if (RE_MUT.search(w) or 'لَٰٓئ' in w) and not m and i < len(ws) - 1: mut.append((s, a, i, 1))
    for i in range(len(ws) - 1):
        A, B = ws[i], ws[i + 1]
        if not PAUSE.search(A) and not re.match('^يَٰ', A) and RE_MUN_A.search(A) and B[0] in HAMZA: mun.append((s, a, i, 2))
# مد اللين المهموز: واو/ياء ساكنة بعد فتح ثم همزة في الكلمة نفسها
leen = []
for s, a, ws in AY:
    if len(ws) > 14: continue
    for i, w in enumerate(ws):
        if re.search('َ[وي' + 'ے' + ']ْ[ءأئؤ]', strip_pause(w)): leen.append((s, a, i, 1))
for lid, fx in FIX.items():
    for (s, a, i) in fx: add(lid, s, a, i, 2 if lid == 'madd-munfasil' else 1)
pick('madd-muttasil', mut, 3, 2); pick('madd-lazim', laz, 3, 2); pick('madd-munfasil', mun, 3, 2); pick('madd-leen', leen, 4, 2)
# صلة هاء الضمير
sg, kb = [], []
for s, a, ws in AY:
    if len(ws) > 14: continue
    for i in range(len(ws) - 1):
        A, B = ws[i], ws[i + 1]
        if PAUSE.search(A): continue
        if re.search('[' + LET + '][َُِ]ه[ُِ][ۥۦ]ٓ$', A) and B[0] in HAMZA: kb.append((s, a, i, 2))
        elif re.search('[' + LET + '][َُِ]ه[ُِ][ۥۦ]$', A) and B[0] not in HAMZA + 'اٱ': sg.append((s, a, i, 2))
pick('madd-silat-sughra', sg, 6); pick('madd-silat-kubra', kb, 6)

# ---- اللام
jal_f, jal_t, tagh = [], [], []
for s, a, ws in AY:
    if len(ws) > 14: continue
    for i in range(1, len(ws)):
        A, B = ws[i - 1], ws[i]
        if PAUSE.search(A): continue
        sk = re.sub('[^' + LET + ']', '', B)
        if sk != 'الله' or 'ّ' not in B: continue
        e = end_info(A)
        if e is None: continue
        mk = e[1].replace('ْ', '')
        if mk == 'ِ': jal_t.append((s, a, i - 1, 2))
        elif mk in ('َ', 'ُ'): jal_f.append((s, a, i - 1, 2))
    for i, w in enumerate(ws):
        if re.search('[صطظ][َْ]ّ?ل[َ]', strip_pause(w)): tagh.append((s, a, i, 1))
pick('lam-jalala-tafkhim', jal_f, 5); pick('lam-jalala-tarqiq', jal_t, 5); pick('lam-taghlith', tagh, 6)
# ---- الراء
ra_f, ra_t = [], []
for s, a, ws in AY:
    if len(ws) > 14: continue
    for i, w in enumerate(ws):
        w2 = strip_pause(w)
        if re.search('[خصضغطقظ]', w2): continue
        if re.search('[َُ][' + LET.replace('ي', 'ي') + ']ر[َُ]', w2) and not re.search('ِ', w2): ra_f.append((s, a, i, 1))
        if re.search('ِ[^ء-يٱ-ۓ]*[' + LET + ']?ر[َُ]|[يے]ْر[َُ]', w2) and re.search('(ِ|[يے]ْ)ر[َُ]', w2): ra_t.append((s, a, i, 1))
pick('ra-tafkhim', ra_f, 6); pick('ra-tarqiq', ra_t, 6)

# ---- التفخيم والترقيق
ISTI = 'خصضغطقظ'
tf = {'t-alif': [], 't-fatha': [], 't-damma': [], 't-sukun': [], 't-kasra': [], 'letters': {}}
for s, a, ws in AY:
    if len(ws) > 10: continue
    for i, w in enumerate(ws):
        w2 = strip_pause(w)
        if PAUSE.search(w): pass
        m = re.match('^[^' + LET + ']*([' + ISTI + '])(ّ?)([َُِْ])?(ٰ|ا)?', w2)
        if not m: continue
        v, al = m.group(3), m.group(4)
        key = 't-alif' if v == 'َ' and al else 't-fatha' if v == 'َ' else 't-damma' if v == 'ُ' else 't-kasra' if v == 'ِ' else None
        if key: tf[key].append((s, a, i, 1, {'letter': m.group(1)}))
        tf['letters'].setdefault(m.group(1), []).append((s, a, i, 1, {'letter': m.group(1)}))
    for i, w in enumerate(ws):
        if i == 0: continue
        m = re.search('([' + ISTI + '])ْ[' + LET + ']', strip_pause(w))
        if m and w[0] not in ISTI: tf['t-sukun'].append((s, a, i, 1, {'letter': m.group(1)}))
def pick_x(lesson, cands, k, seed=3):
    rnd = random.Random(seed); rnd.shuffle(cands); seen, n = set(), 0
    for c in cands:
        if c[0] in seen: continue
        seen.add(c[0]); add(lesson, c[0], c[1], c[2], c[3], c[4]); n += 1
        if n == k: break
for k in ('t-alif', 't-fatha', 't-damma', 't-sukun', 't-kasra'): pick_x('tafkhim-rank-' + k[2:], tf[k], 4)
# حروف الاستعلاء: مثال لكل حرف
for L in ISTI:
    c = tf['letters'].get(L, [])
    random.Random(5).shuffle(c)
    if c: add('tafkhim-letters', c[0][0], c[0][1], c[0][2], 1, c[0][4])
# حروف مرققة: كلمات تبدأ بحرف استفال مفتوح
tq = []
for s, a, ws in AY:
    if len(ws) > 6: continue
    for i, w in enumerate(ws):
        m = re.match('^([بتثجحدذزسشفكلمنهو])َ', strip_pause(w))
        if m: tq.append((s, a, i, 1, {'letter': m.group(1)}))
random.Random(7).shuffle(tq); seen = set(); n = 0
for c in tq:
    if c[4]['letter'] in seen: continue
    seen.add(c[4]['letter']); add('tarqiq-letters', *c[:4], c[4]); n += 1
    if n == 6: break

# ---- مخارج وصفات: كلمة مثال لكل حرف (حرف مفتوح في أول الكلمة)
def letter_word(L, seed=11):
    c = []
    for s, a, ws in AY:
        if len(ws) > 5: continue
        for i, w in enumerate(ws):
            if re.match('^' + L + '[َُِ]', strip_pause(w)) and not PAUSE.search(w): c.append((s, a, i))
    random.Random(seed).shuffle(c); return c[0] if c else None
LETTERS = {'ء': 'ء', 'ه': 'ه', 'ع': 'ع', 'ح': 'ح', 'غ': 'غ', 'خ': 'خ', 'ق': 'ق', 'ك': 'ك', 'ج': 'ج', 'ش': 'ش', 'ي': 'ي', 'ض': 'ض', 'ل': 'ل', 'ن': 'ن', 'ر': 'ر', 'ط': 'ط', 'د': 'د', 'ت': 'ت', 'ص': 'ص', 'ز': 'ز', 'س': 'س', 'ظ': 'ظ', 'ذ': 'ذ', 'ث': 'ث', 'ف': 'ف', 'ب': 'ب', 'م': 'م', 'و': 'و'}
lw = {}
for L in LETTERS:
    r = letter_word('أ' if L == 'ء' else L)
    if r: lw[L] = r
GRP = {
    'makharij-jawf': 'اوي', 'makharij-halq': 'ءهعحغخ', 'makharij-lisan': 'قكجشيضلنرطدتصزسظذثو'[:0] + 'قكجشيضلنرطدتصزسظذث',
    'makharij-shafatan': 'فبمو',
    'sifat-mutadadda': 'هعحقطبجدءتكصشسخضغزظثذفر', 'sifat-ghayr-mutadadda': 'صزسقطبجدلرشضو',
}
for lid, letters in GRP.items():
    seen = 0
    for L in letters:
        if L in lw and L not in 'او' and seen < 6:
            s, a, i = lw[L]; add(lid, s, a, i, 1, {'letter': L}); seen += 1
# الجوف: أمثلة من المد الطبيعي، الخيشوم: نون/ميم مشددة (غنة)
for e in out.get('madd-tabii', [])[:3]: add('makharij-jawf', e['s'], e['a'], e['i'], e['n'])
gh = []
for s, a, ws in AY:
    if len(ws) > 8: continue
    for i, w in enumerate(ws):
        m = re.search('([نم])ّ', strip_pause(w))
        if m: gh.append((s, a, i, 1, {'letter': m.group(1)}))
random.Random(9).shuffle(gh); seen = set(); n = 0
for c in gh:
    if (c[0], c[4]['letter']) in seen or n >= 4: continue
    seen.add((c[0], c[4]['letter'])); add('makharij-khayshum', *c[:4], c[4]); n += 1

# ---- علامة u: الموضع هو الوحيد من نوعه في الآية (يُستعمل لسؤال «أين موضع الحكم؟» دون التباس)
def hits(lesson, ws):
    res = []
    n4 = {'noon-idhar': 'idhar', 'noon-iqlab': 'iqlab', 'noon-idgham-ghunna': 'idghamG', 'noon-idgham-bila': 'idghamN', 'noon-ikhfa': 'ikhfa'}
    if lesson in n4:
        return [i for i in range(len(ws) - 1) if classify4(ws[i], ws[i + 1]) == n4[lesson]]
    m5 = {'meem-idhar': 'idhar', 'meem-idgham': 'idgham', 'madd-silat-meem': 'silah'}
    if lesson in m5:
        return [i for i in range(len(ws) - 1) if classify5(ws[i], ws[i + 1]) == m5[lesson]]
    if lesson == 'qalqala-sughra':
        return [i for i, w in enumerate(ws[:-1]) if re.search('[' + Q5 + ']ْ[' + LET + ']', strip_pause(w))]
    if lesson == 'madd-muttasil':
        return [i for i, w in enumerate(ws[:-1]) if (RE_MUT.search(re.sub('^[۞ ]+', '', w)) or 'لَٰٓئ' in w) and not RE_LAZ.search(w) and not re.match('^يَٰ|^هَٰٓ', w)]
    if lesson == 'madd-munfasil':
        return [i for i in range(len(ws) - 1) if RE_MUN_A.search(ws[i]) and ws[i + 1][0] in HAMZA and not PAUSE.search(ws[i])]
    return None
for lid, exs in out.items():
    for e in exs:
        ws = next(w for (ss, aa, w) in AY if ss == e['s'] and aa == e['a'])
        h = hits(lid, ws)
        if h is not None and e['i'] in h and len(h) == 1: e['u'] = True
json.dump(out, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print({k: len(v) for k, v in sorted(out.items())})
