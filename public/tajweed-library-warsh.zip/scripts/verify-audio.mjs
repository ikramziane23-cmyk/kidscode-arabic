#!/usr/bin/env node
// يفحص أن ملفات تلاوة ياسين الجزائري (ورش) التي تستعملها الدروس موجودة فعلاً على المصدر.
// تشغيل (من جهاز له اتصال بالإنترنت):  node scripts/verify-audio.mjs
// الفحص يؤكد الوجود فقط؛ مطابقة الآية للتسجيل (ترقيم ورش) تحتاج استماعًا بشريًا، يطبع السكربت قائمة للاستماع.
import { readFileSync } from "node:fs";

const manifest = JSON.parse(readFileSync("src/data/tajweed-audio.json", "utf8"));
const examples = JSON.parse(readFileSync("src/data/tajweed-examples.json", "utf8"));
const r = manifest.reciters[0];
const pad = (n) => String(n).padStart(3, "0");
const ayat = new Map();
for (const [lesson, list] of Object.entries(examples)) for (const e of list) ayat.set(`${e.s}:${e.a}`, [...(ayat.get(`${e.s}:${e.a}`) ?? []), lesson]);

let ok = 0;
const bad = [];
for (const key of [...ayat.keys()].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }))) {
  const [s, a] = key.split(":").map(Number);
  const url = `${r.baseUrl}/${r.filePattern.replace("{SSS}", pad(s)).replace("{AAA}", pad(a))}`;
  try {
    const res = await fetch(url, { method: "HEAD" });
    const type = res.headers.get("content-type") ?? "";
    if (res.ok && /audio|octet-stream/.test(type)) ok++;
    else bad.push(`${key} → HTTP ${res.status} ${type} ${url}`);
  } catch (e) {
    bad.push(`${key} → ${e.message} ${url}`);
  }
}
console.log(`موجود: ${ok} / ${ayat.size}`);
if (bad.length) console.log("غير موجود/غير صالح:\n" + bad.join("\n"));
console.log("\nقائمة الاستماع (تأكدي أن الصوت هو الآية نفسها برواية ورش):");
for (const [k, v] of ayat) console.log(`  ${k}  ← ${[...new Set(v)].join(", ")}`);
process.exit(bad.length ? 1 : 0);
