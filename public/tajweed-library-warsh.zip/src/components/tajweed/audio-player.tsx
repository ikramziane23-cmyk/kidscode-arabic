import { useEffect, useRef, useState } from "react";
import { Pause, Play, RotateCcw } from "lucide-react";
import { ayahAudioUrl, DEFAULT_RECITER } from "@/lib/tajweed/audio";

type Status = "idle" | "loading" | "playing" | "paused" | "error";

/** تلاوة الآية بصوت ياسين الجزائري (ورش). إن تعذّر تحميل الملف يظهر تنبيه بدل أي تسجيل بديل. */
export function AyahAudio({ surah, ayah }: { surah: number; ayah: number }) {
  const url = ayahAudioUrl(surah, ayah);
  const ref = useRef<HTMLAudioElement | null>(null);
  const [status, setStatus] = useState<Status>("idle");

  useEffect(() => {
    setStatus("idle");
    const el = ref.current;
    return () => {
      el?.pause();
    };
  }, [surah, ayah]);

  if (!url) return <p className="text-sm text-muted-foreground">التسجيل غير متاح لهذا المثال.</p>;

  const play = () => {
    const el = ref.current;
    if (!el) return;
    setStatus("loading");
    el.play().then(
      () => setStatus("playing"),
      () => setStatus("error"),
    );
  };
  const pause = () => {
    ref.current?.pause();
    setStatus("paused");
  };
  const restart = () => {
    const el = ref.current;
    if (!el) return;
    el.currentTime = 0;
    play();
  };

  return (
    <div className="flex flex-wrap items-center justify-center gap-2" data-testid="ayah-audio">
      <audio
        ref={ref}
        src={url}
        preload="none"
        onEnded={() => setStatus("idle")}
        onError={() => setStatus("error")}
      />
      {status === "playing" || status === "loading" ? (
        <button type="button" onClick={pause} className="inline-flex items-center gap-1 rounded-full bg-white/90 px-4 py-2 font-bold text-[#2f5d46] shadow">
          <Pause className="size-4" /> إيقاف
        </button>
      ) : (
        <button type="button" onClick={play} className="inline-flex items-center gap-1 rounded-full bg-white/90 px-4 py-2 font-bold text-[#2f5d46] shadow">
          <Play className="size-4" /> استمعي
        </button>
      )}
      <button type="button" onClick={restart} className="inline-flex items-center gap-1 rounded-full bg-white/70 px-4 py-2 font-bold text-[#2f5d46] shadow">
        <RotateCcw className="size-4" /> إعادة الاستماع
      </button>
      {status === "error" && (
        <p role="alert" className="basis-full text-center text-sm font-bold text-amber-200">
          تعذّر تشغيل تسجيل هذه الآية. التسجيل غير متاح الآن، ولن نعرض تسجيلًا بديلًا غير مطابق.
        </p>
      )}
      <p className="basis-full text-center text-xs text-white/70">
        {DEFAULT_RECITER.name} — رواية {DEFAULT_RECITER.riwaya} (آية كاملة: {surah}:{ayah}) — المصدر: EveryAyah
      </p>
    </div>
  );
}
