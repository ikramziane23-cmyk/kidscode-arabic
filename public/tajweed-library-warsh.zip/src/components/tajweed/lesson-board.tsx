import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Palette } from "lucide-react";
import type { Surah } from "@/lib/ayah-game";
import { groupsOf, resolveGroup } from "@/lib/tajweed/examples";
import type { Lesson } from "@/lib/tajweed/types";
import { AyahAudio } from "./audio-player";
import { QuranWords } from "./quran-words";

/** السبورة التعليمية التفاعلية: تعرض أمثلة الدرس واحدًا واحدًا مع تلوين موضع الحكم وتلاوة الآية. */
export function LessonBoard({ lesson, surahs }: { lesson: Lesson; surahs: Surah[] }) {
  const groups = useMemo(
    () => groupsOf(lesson).map((g) => ({ ...g, examples: resolveGroup(surahs, g.key) })).filter((g) => g.examples.length > 0),
    [lesson, surahs],
  );
  const [gi, setGi] = useState(0);
  const [ei, setEi] = useState(0);
  const [colored, setColored] = useState(true);

  if (groups.length === 0) {
    return (
      <div className="rounded-3xl border border-amber-300 bg-amber-50 p-6 text-center font-bold text-amber-900" role="status">
        لا تتوفر أمثلة قرآنية موثّقة لهذا الدرس بعد، ولا نعرض مثالًا لم نتحقق منه.
      </div>
    );
  }
  const group = groups[Math.min(gi, groups.length - 1)]!;
  const idx = Math.min(ei, group.examples.length - 1);
  const ex = group.examples[idx]!;
  const hl = Array.from({ length: ex.n }, (_, k) => ex.i + k);

  return (
    <section aria-label="السبورة التعليمية" className="rounded-[2rem] border-4 border-[#b58a45] bg-[#2f5d46] p-4 text-white shadow-xl md:p-6" data-testid="board">
      {groups.length > 1 && (
        <div className="mb-3 flex flex-wrap justify-center gap-2" role="tablist">
          {groups.map((g, k) => (
            <button
              key={g.key}
              role="tab"
              aria-selected={k === gi}
              type="button"
              onClick={() => {
                setGi(k);
                setEi(0);
              }}
              className={`rounded-full px-4 py-1.5 text-sm font-bold ${k === gi ? "bg-amber-300 text-[#4a2d00]" : "bg-white/15 text-white"}`}
            >
              {g.title}
            </button>
          ))}
        </div>
      )}
      {group.note && <p className="mb-2 text-center text-sm text-white/80">{group.note}</p>}
      <div className="rounded-2xl bg-[#244a38] px-3 py-5">
        <QuranWords words={ex.words} hl={hl} color={colored} className="text-3xl md:text-4xl" />
        <p className="mt-2 text-center text-sm text-white/80">
          سورة {ex.surahName} — الآية {ex.a}
        </p>
        {ex.letter && (
          <p className="mt-1 text-center text-sm font-bold text-amber-200">
            الحرف المقصود في الكلمة الملوّنة: «{ex.letter}»
          </p>
        )}
      </div>
      <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
        <button type="button" onClick={() => setEi((i) => Math.max(0, i - 1))} disabled={idx === 0} className="rounded-full bg-white/90 p-2 text-[#2f5d46] shadow disabled:opacity-40" aria-label="المثال السابق">
          <ChevronRight className="size-5" />
        </button>
        <span className="min-w-20 text-center text-sm font-bold" aria-live="polite">
          {idx + 1} / {group.examples.length}
        </span>
        <button type="button" onClick={() => setEi((i) => Math.min(group.examples.length - 1, i + 1))} disabled={idx === group.examples.length - 1} className="rounded-full bg-white/90 p-2 text-[#2f5d46] shadow disabled:opacity-40" aria-label="المثال التالي">
          <ChevronLeft className="size-5" />
        </button>
        <button type="button" onClick={() => setColored((c) => !c)} aria-pressed={colored} className="inline-flex items-center gap-1 rounded-full bg-white/90 px-4 py-2 text-sm font-bold text-[#2f5d46] shadow">
          <Palette className="size-4" /> {colored ? "إخفاء التلوين" : "إظهار التلوين"}
        </button>
      </div>
      <div className="mt-4 border-t border-white/20 pt-3">
        <AyahAudio surah={ex.s} ayah={ex.a} />
      </div>
    </section>
  );
}
