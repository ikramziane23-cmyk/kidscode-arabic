import { useMemo, useState } from "react";
import { Check, RotateCcw, X } from "lucide-react";
import type { Surah } from "@/lib/ayah-game";
import { buildQuiz, PASS_RATIO, scoreMessage } from "@/lib/tajweed/quiz";
import type { Lesson } from "@/lib/tajweed/types";
import { QuranWords } from "./quran-words";

export function LessonQuiz({
  lesson,
  surahs,
  onFinished,
}: {
  lesson: Lesson;
  surahs: Surah[];
  onFinished: (score: number, total: number) => void;
}) {
  const [round, setRound] = useState(0);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const questions = useMemo(() => buildQuiz(lesson, surahs), [lesson, surahs, round]);
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);

  if (questions.length === 0) {
    return <p className="rounded-2xl bg-amber-50 p-4 text-center font-bold text-amber-900">لا يتوفر اختبار لهذا الدرس بعد.</p>;
  }

  const restart = () => {
    setRound((r) => r + 1);
    setI(0);
    setPicked(null);
    setScore(0);
    setDone(false);
  };

  if (done) {
    const pass = score / questions.length >= PASS_RATIO;
    return (
      <div className="rounded-3xl border border-emerald-200 bg-emerald-50 p-6 text-center" data-testid="quiz-result">
        <p className="text-5xl" aria-hidden>
          {pass ? "🌟" : "💪"}
        </p>
        <h3 className="mt-2 text-2xl font-bold">
          نتيجتك: {score} من {questions.length}
        </h3>
        <p className="mt-2">{scoreMessage(score, questions.length)}</p>
        <button type="button" onClick={restart} className="mt-4 inline-flex items-center gap-2 rounded-full bg-emerald-600 px-6 py-3 font-bold text-white">
          <RotateCcw className="size-4" /> إعادة الاختبار
        </button>
      </div>
    );
  }

  const q = questions[i]!;
  const answered = picked !== null;
  const choose = (k: number) => {
    if (answered) return;
    setPicked(k);
    if (k === q.answer) setScore((s) => s + 1);
  };
  const next = () => {
    if (i + 1 >= questions.length) {
      setDone(true);
      onFinished(score, questions.length);
      return;
    }
    setI(i + 1);
    setPicked(null);
  };

  return (
    <div className="rounded-3xl border border-rose-200 bg-white p-5 shadow" data-testid="quiz">
      <div className="mb-3 flex items-center justify-between text-sm font-bold text-muted-foreground">
        <span>
          السؤال {i + 1} من {questions.length}
        </span>
        <span>الدرجة: {score}</span>
      </div>
      <h3 className="text-lg font-bold">{q.prompt}</h3>
      {q.verse && (
        <div className="my-3 rounded-2xl bg-[#fff8ee] p-3">
          <QuranWords words={q.verse.words} hl={q.verse.hl} className="text-2xl md:text-3xl" />
          <p className="mt-1 text-center text-xs text-muted-foreground">
            سورة {q.verse.surahName} — الآية {q.verse.ayah}
          </p>
        </div>
      )}
      <div className="mt-3 grid gap-2">
        {q.options.map((o, k) => {
          const isRight = answered && k === q.answer;
          const isWrong = answered && k === picked && k !== q.answer;
          return (
            <button
              key={k}
              type="button"
              onClick={() => choose(k)}
              disabled={answered}
              data-correct={isRight ? "1" : undefined}
              className={`flex items-center justify-between rounded-2xl border-2 px-4 py-3 text-start text-lg font-bold transition ${
                isRight ? "border-emerald-500 bg-emerald-50" : isWrong ? "border-red-400 bg-red-50" : "border-rose-100 bg-rose-50/40 hover:bg-rose-50"
              }`}
            >
              <span className={q.kind === "locate" ? "warsh text-2xl" : ""}>{o}</span>
              {isRight && <Check className="size-5 text-emerald-600" aria-label="صحيحة" />}
              {isWrong && <X className="size-5 text-red-600" aria-label="خاطئة" />}
            </button>
          );
        })}
      </div>
      {answered && (
        <div className={`mt-4 rounded-2xl p-4 ${picked === q.answer ? "bg-emerald-50" : "bg-red-50"}`} role="status" data-testid="feedback">
          <p className="font-bold">{picked === q.answer ? "أحسنتِ! إجابة صحيحة." : "إجابة غير صحيحة."}</p>
          <p className="mt-1">{q.explanation}</p>
          <button type="button" onClick={next} className="mt-3 rounded-full bg-rose-500 px-6 py-2 font-bold text-white">
            {i + 1 >= questions.length ? "إنهاء الاختبار" : "السؤال التالي"}
          </button>
        </div>
      )}
    </div>
  );
}
