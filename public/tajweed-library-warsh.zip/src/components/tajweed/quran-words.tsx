import { Fragment } from "react";

export const TAJWEED_FONT_CSS = `
@font-face { font-family: "UthmanicWarsh"; src: url("/fonts/UthmanicWarsh.woff2") format("woff2"); font-display: swap; }
.warsh { font-family: "UthmanicWarsh", "Amiri", "Scheherazade New", serif; line-height: 2.2; }
`;

/** يعرض كلمات الآية كما هي من نص ورش، مع تلوين مواضع الحكم (الأول ذهبي، الثاني أخضر). */
export function QuranWords({
  words,
  hl,
  color = true,
  className = "",
}: {
  words: string[];
  hl: number[];
  color?: boolean;
  className?: string;
}) {
  return (
    <p className={`warsh text-center ${className}`} dir="rtl">
      {words.map((w, i) => {
        const k = hl.indexOf(i);
        const cls = color && k >= 0 ? (k === 0 ? "rounded-lg bg-amber-300/80 px-1 text-[#4a2d00]" : "rounded-lg bg-emerald-300/80 px-1 text-[#06371f]") : "";
        return (
          <Fragment key={i}>
            <span className={cls} data-hl={k >= 0 ? "1" : undefined}>
              {w}
            </span>{" "}
          </Fragment>
        );
      })}
    </p>
  );
}
