import { useEffect, useMemo, useRef, useState } from "react";
import { Pause, Play, RotateCcw, Volume2 } from "lucide-react";
import { BrowserSpeechProvider, NarrationController, type NarrationSegment, type NarrationState } from "@/lib/tajweed/speech";

/**
 * أزرار شرح الدرس صوتيًا. يستقبل القطع المكتوبة ويبلّغ الصفحة بالقطعة الجارية لتمييزها نصيًا.
 * الصوت لشرح القواعد فقط وليس لتلاوة القرآن.
 */
export function VoiceExplainer({
  segments,
  onActive,
}: {
  segments: NarrationSegment[];
  onActive: (segmentId: string | null) => void;
}) {
  const provider = useMemo(() => new BrowserSpeechProvider(), []);
  const [available, setAvailable] = useState<boolean | null>(null);
  const [state, setState] = useState<NarrationState>("idle");
  const [error, setError] = useState<string | null>(null);
  const ctrl = useRef<NarrationController | null>(null);
  const segKey = segments.map((s) => s.id).join("|");

  useEffect(() => {
    const synth = typeof window !== "undefined" ? window.speechSynthesis : undefined;
    if (!synth) {
      setAvailable(false);
      return;
    }
    const update = () => setAvailable(provider.isAvailable());
    update();
    synth.addEventListener?.("voiceschanged", update);
    return () => synth.removeEventListener?.("voiceschanged", update);
  }, [provider]);

  useEffect(() => {
    ctrl.current = new NarrationController(provider, segments, (st, i, err) => {
      setState(st);
      setError(err ?? null);
      onActive(st === "idle" ? null : (segments[i]?.id ?? null));
    });
    return () => {
      ctrl.current?.dispose();
      onActive(null);
    };
    // segments تتغير فقط مع تغيّر الدرس
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [provider, segKey]);

  const voice = provider.voices()[0];
  return (
    <div className="rounded-2xl border border-rose-200 bg-white/80 p-4" data-testid="voice-explainer">
      <div className="flex flex-wrap items-center justify-center gap-2">
        <Volume2 className="size-5 text-rose-500" aria-hidden />
        <span className="font-bold">استمعي لشرح الدرس</span>
        {state === "playing" ? (
          <button type="button" onClick={() => ctrl.current?.pause()} className="inline-flex items-center gap-1 rounded-full bg-rose-500 px-4 py-2 font-bold text-white">
            <Pause className="size-4" /> إيقاف مؤقت
          </button>
        ) : (
          <button type="button" onClick={() => ctrl.current?.play()} disabled={available === false} className="inline-flex items-center gap-1 rounded-full bg-rose-500 px-4 py-2 font-bold text-white disabled:opacity-50">
            <Play className="size-4" /> {state === "paused" ? "متابعة" : "تشغيل الشرح"}
          </button>
        )}
        <button type="button" onClick={() => ctrl.current?.restart()} disabled={available === false} className="inline-flex items-center gap-1 rounded-full border border-rose-300 bg-white px-4 py-2 font-bold text-rose-600 disabled:opacity-50">
          <RotateCcw className="size-4" /> إعادة
        </button>
      </div>
      {available === false && (
        <p role="alert" className="mt-3 text-center text-sm font-bold text-amber-800">
          لا يتوفر صوت عربي على هذا الجهاز أو المتصفح، لذلك لا يعمل شرح الدرس صوتيًا هنا. الشرح المكتوب متاح كاملًا. يمكن تثبيت صوت عربي من إعدادات النظام ثم إعادة فتح الصفحة.
        </p>
      )}
      {available && voice && (
        <p className="mt-2 text-center text-xs text-muted-foreground">
          الصوت المستعمل: {voice.voice.name}
          {voice.likelyFemale ? " (يبدو صوتًا نسائيًا)" : " (لا يمكن للمتصفح تأكيد كونه صوتًا نسائيًا)"} — يعتمد الصوت على جهازك.
        </p>
      )}
      {error && (
        <p role="alert" className="mt-2 text-center text-sm font-bold text-red-700">
          {error}
        </p>
      )}
    </div>
  );
}
