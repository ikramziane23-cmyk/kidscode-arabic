import audioJson from "@/data/tajweed-audio.json";

export type Reciter = {
  id: string;
  name: string;
  riwaya: string;
  baseUrl: string;
  filePattern: string;
  source: string;
  sourceUrl: string;
  licenseNote: string;
  verified: boolean;
};

const DATA = audioJson as unknown as {
  reciters: Reciter[];
  unavailable: { id: string; name: string; reason: string }[];
};

export const RECITERS: Reciter[] = DATA.reciters;
export const DEFAULT_RECITER: Reciter = RECITERS[0] as Reciter;
export const UNAVAILABLE_RECITERS = DATA.unavailable;

const pad = (n: number) => String(n).padStart(3, "0");

export function fileName(pattern: string, s: number, a: number): string {
  return pattern.replace("{SSS}", pad(s)).replace("{AAA}", pad(a));
}

/**
 * رابط تلاوة الآية كاملة. يُبنى من مجلد المقرئ المعتمد ورقم السورة والآية فقط؛
 * لا تُخترع روابط لمقرئين آخرين، ولا تُستعمل أي رواية غير ورش.
 */
export function ayahAudioUrl(s: number, a: number, reciter: Reciter = DEFAULT_RECITER): string | null {
  if (!Number.isInteger(s) || !Number.isInteger(a) || s < 1 || s > 114 || a < 1) return null;
  return `${reciter.baseUrl}/${fileName(reciter.filePattern, s, a)}`;
}
