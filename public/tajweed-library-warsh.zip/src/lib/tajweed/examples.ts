import type { Surah } from "@/lib/ayah-game";
import examplesJson from "@/data/tajweed-examples.json";
import type { ExampleGroup, Lesson, RawExample, ResolvedExample } from "./types";

export type RawExampleU = RawExample & { u?: boolean };
const RAW = examplesJson as unknown as Record<string, RawExampleU[]>;

export function rawExamples(key: string): RawExampleU[] {
  return RAW[key] ?? [];
}

export function groupsOf(lesson: Lesson): ExampleGroup[] {
  return lesson.groups ?? [{ key: lesson.id, title: "أمثلة من القرآن الكريم" }];
}

export function allRawExamples(lesson: Lesson): RawExampleU[] {
  return groupsOf(lesson).flatMap((g) => rawExamples(g.key));
}

export function ayahWords(surahs: Surah[], s: number, a: number): string[] | null {
  const text = surahs[s - 1]?.ayat[a - 1];
  return text ? text.split(" ") : null;
}

/** يربط المثال بنص ورش المحمّل؛ يعيد null إذا لم تتطابق الكلمة المخزنة مع النص (حماية من انحراف البيانات). */
export function resolveExample(surahs: Surah[], ex: RawExampleU): (ResolvedExample & { u?: boolean }) | null {
  const surah = surahs[ex.s - 1];
  const words = ayahWords(surahs, ex.s, ex.a);
  if (!surah || !words) return null;
  const got = words.slice(ex.i, ex.i + ex.n).join(" ");
  if (got !== ex.w) return null;
  return { ...ex, surahName: surah.name, words };
}

export function resolveGroup(surahs: Surah[], key: string): (ResolvedExample & { u?: boolean })[] {
  return rawExamples(key).flatMap((e) => {
    const r = resolveExample(surahs, e);
    return r ? [r] : [];
  });
}
