import { LESSONS } from "./lessons";

const KEY = "tajweed-library-progress-v1";

export type LessonProgress = { visited: boolean; score?: number; total?: number; passed?: boolean };
export type ProgressMap = Record<string, LessonProgress>;

function storage(): Storage | null {
  try {
    return typeof window === "undefined" ? null : window.localStorage;
  } catch {
    return null;
  }
}

export function loadProgress(): ProgressMap {
  const st = storage();
  if (!st) return {};
  try {
    const raw = st.getItem(KEY);
    const data = raw ? (JSON.parse(raw) as unknown) : {};
    return data && typeof data === "object" && !Array.isArray(data) ? (data as ProgressMap) : {};
  } catch {
    return {};
  }
}

function save(map: ProgressMap) {
  try {
    storage()?.setItem(KEY, JSON.stringify(map));
  } catch {
    /* التخزين غير متاح: يستمر العمل بدون حفظ */
  }
}

export function markVisited(id: string): ProgressMap {
  const map = loadProgress();
  map[id] = { ...map[id], visited: true };
  save(map);
  return map;
}

export function recordQuiz(id: string, score: number, total: number, passRatio: number): ProgressMap {
  const map = loadProgress();
  const prev = map[id];
  const best = prev?.score !== undefined && prev.total ? prev.score / prev.total : -1;
  const now = total ? score / total : 0;
  map[id] = {
    visited: true,
    score: now >= best ? score : (prev?.score as number),
    total: now >= best ? total : (prev?.total as number),
    passed: Boolean(prev?.passed) || now >= passRatio,
  };
  save(map);
  return map;
}

export function completionPercent(map: ProgressMap): number {
  const active = LESSONS.filter((l) => !l.pending);
  if (!active.length) return 0;
  const done = active.filter((l) => map[l.id]?.passed).length;
  return Math.round((done / active.length) * 100);
}

export function resetProgress() {
  try {
    storage()?.removeItem(KEY);
  } catch {
    /* ignore */
  }
}
