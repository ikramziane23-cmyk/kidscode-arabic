import { shuffle, type Surah } from "@/lib/ayah-game";
import { LESSONS } from "./lessons";
import { groupsOf, resolveGroup } from "./examples";
import type { Lesson, ResolvedExample } from "./types";

export type QuizQuestion = {
  id: string;
  kind: "fact" | "recognize" | "locate";
  prompt: string;
  /** للأسئلة المبنية على مثال: الآية بكلماتها والمواضع الملوّنة */
  verse?: { words: string[]; hl: number[]; surahName: string; ayah: number };
  options: string[];
  answer: number;
  explanation: string;
};

const MAX_QUESTIONS = 8;

function toQuestionOptions(correct: string, wrong: string[], rng: () => number) {
  const options = shuffle([correct, ...wrong], rng);
  return { options, answer: options.indexOf(correct) };
}

/** الأحكام التي تُعرض كخيارات خاطئة لسؤال «ما الحكم؟»: من الدرس نفسه ثم من بقية الدروس المعتمدة. */
function labelPool(lesson: Lesson): string[] {
  const same = LESSONS.filter((l) => l.category === lesson.category && l.id !== lesson.id && !l.pending);
  const other = LESSONS.filter((l) => l.category !== lesson.category && !l.pending && !l.review);
  return [...new Set([...same, ...other].map((l) => l.label).filter((x) => x !== lesson.label))];
}

function canRecognize(lesson: Lesson): boolean {
  return !lesson.groups && ["noon", "meem", "madd", "qalqala"].includes(lesson.category);
}

function verseOf(e: ResolvedExample, hl: number[]) {
  return { words: e.words, hl, surahName: e.surahName, ayah: e.a };
}

export function buildQuiz(lesson: Lesson, surahs: Surah[], rng: () => number = Math.random): QuizQuestion[] {
  if (lesson.pending) return [];
  const out: QuizQuestion[] = [];

  lesson.facts.forEach((f, i) => {
    const { options, answer } = toQuestionOptions(f.correct, [...f.wrong], rng);
    out.push({ id: `${lesson.id}:fact:${i}`, kind: "fact", prompt: f.q, options, answer, explanation: f.why });
  });

  const examples = groupsOf(lesson).flatMap((g) => resolveGroup(surahs, g.key));

  if (canRecognize(lesson)) {
    const pool = labelPool(lesson);
    shuffle(examples, rng)
      .slice(0, 3)
      .forEach((e, i) => {
        const wrong = shuffle(pool, rng).slice(0, 3);
        const { options, answer } = toQuestionOptions(lesson.label, wrong, rng);
        const hl = Array.from({ length: e.n }, (_, k) => e.i + k);
        out.push({
          id: `${lesson.id}:rec:${e.s}:${e.a}:${e.i}:${i}`,
          kind: "recognize",
          prompt: "ما الحكم التجويدي في الكلمات الملوّنة (برواية ورش)؟",
          verse: verseOf(e, hl),
          options,
          answer,
          explanation: `الحكم هنا: ${lesson.label}. ${lesson.definition}`,
        });
      });
  }

  // «أين موضع الحكم؟»: فقط حيث الموضع هو الوحيد من نوعه في الآية، ولا يتداخل مع الكلمات البديلة
  const locatable = examples.filter((e) => e.u && e.words.length >= 4);
  shuffle(locatable, rng)
    .slice(0, 2)
    .forEach((e, i) => {
      const taken = new Set(Array.from({ length: e.n }, (_, k) => e.i + k));
      const distinct = new Map<string, number>();
      e.words.forEach((w, idx) => {
        // نستبعد كل كلمة تساوي كلمة الحكم أو كلمات موضعه، ونكتفي بنسخة واحدة من كل كلمة
        if (!taken.has(idx) && !e.words.slice(e.i, e.i + e.n).includes(w) && !distinct.has(w)) distinct.set(w, idx);
      });
      const others = shuffle([...distinct].map(([w, idx]) => ({ w, idx })), rng).slice(0, 3);
      if (others.length < 3) return;
      const target = e.words[e.i] as string;
      const { options, answer } = toQuestionOptions(target, others.map((o) => o.w), rng);
      out.push({
        id: `${lesson.id}:loc:${e.s}:${e.a}:${e.i}:${i}`,
        kind: "locate",
        prompt: `في الآية الآتية موضع واحد لحكم «${lesson.label}». أي الكلمات الآتية يبدأ عندها هذا الحكم؟`,
        verse: verseOf(e, []),
        options,
        answer,
        explanation: `يبدأ الحكم عند «${target}»: ${lesson.definition}`,
      });
    });

  return shuffle(out, rng).slice(0, MAX_QUESTIONS);
}

export function scoreMessage(score: number, total: number): string {
  if (total === 0) return "";
  const r = score / total;
  if (r === 1) return "ما شاء الله! أجبتِ عن كل الأسئلة إجابة صحيحة.";
  if (r >= 0.7) return "ممتاز! أنتِ على الطريق الصحيح، راجعي الأسئلة الخاطئة.";
  if (r >= 0.4) return "جيّد، أعيدي قراءة الدرس ثم جرّبي الاختبار مرة أخرى.";
  return "لا بأس، استمعي إلى شرح الدرس مرة أخرى ثم أعيدي المحاولة.";
}

export const PASS_RATIO = 0.7;
