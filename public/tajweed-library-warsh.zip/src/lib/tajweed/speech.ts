/**
 * شرح الدروس بالصوت (تحويل نص إلى كلام) — مخصص لشرح الأحكام فقط وليس لتلاوة القرآن.
 * الحل الأولي: SpeechSynthesis في المتصفح مع اكتشاف الأصوات العربية المتوفرة.
 * لربط خدمة احترافية لاحقًا: نفّذي واجهة SpeechProvider وسجّليها بـ registerSpeechProvider دون تغيير الواجهات.
 */

export type NarrationSegment = { id: string; text: string };

export interface SpeechHandlers {
  onSegment?: (index: number) => void;
  onEnd?: () => void;
  onError?: (message: string) => void;
}

export interface SpeechProvider {
  id: string;
  name: string;
  /** هل يستطيع المزوّد النطق بالعربية الآن؟ */
  isAvailable(): boolean;
  /** يبدأ النطق من القطعة from؛ يعيد دالة إيقاف. */
  speak(segments: NarrationSegment[], from: number, handlers: SpeechHandlers): () => void;
}

const FEMALE_HINTS = ["laila", "leila", "hoda", "zariyah", "salma", "amira", "fatima", "maryam", "female", "امرأة", "ليلى", "هدى", "سلمى"];

export type VoiceInfo = { voice: SpeechSynthesisVoice; likelyFemale: boolean };

export function arabicVoices(list: readonly SpeechSynthesisVoice[]): VoiceInfo[] {
  return list
    .filter((v) => v.lang.toLowerCase().startsWith("ar"))
    .map((voice) => ({ voice, likelyFemale: FEMALE_HINTS.some((h) => voice.name.toLowerCase().includes(h)) }))
    .sort((a, b) => Number(b.likelyFemale) - Number(a.likelyFemale));
}

/** يقسّم النص إلى قطع قصيرة (حدّ المتصفحات لطول النطق المتصل). */
export function chunkText(text: string, max = 170): string[] {
  const parts = text.split(/(?<=[.،؛:؟!])\s+/u).filter(Boolean);
  const out: string[] = [];
  let cur = "";
  for (const p of parts) {
    if ((cur + " " + p).trim().length > max && cur) {
      out.push(cur.trim());
      cur = p;
    } else cur = (cur + " " + p).trim();
  }
  if (cur) out.push(cur.trim());
  return out;
}

export function narrationFor(parts: { id: string; text: string }[]): NarrationSegment[] {
  return parts.flatMap((p) => chunkText(p.text).map((t, i) => ({ id: `${p.id}#${i}`, text: t })));
}

export class BrowserSpeechProvider implements SpeechProvider {
  id = "browser";
  name = "صوت المتصفح";
  rate = 0.9;
  voiceURI: string | null = null;

  constructor(private synth: SpeechSynthesis | null = typeof window !== "undefined" ? (window.speechSynthesis ?? null) : null) {}

  voices(): VoiceInfo[] {
    return this.synth ? arabicVoices(this.synth.getVoices()) : [];
  }

  isAvailable(): boolean {
    return this.voices().length > 0;
  }

  speak(segments: NarrationSegment[], from: number, handlers: SpeechHandlers): () => void {
    const synth = this.synth;
    if (!synth) {
      handlers.onError?.("المتصفح لا يدعم النطق الصوتي.");
      return () => {};
    }
    const vs = this.voices();
    const chosen = (this.voiceURI && vs.find((v) => v.voice.voiceURI === this.voiceURI)) || vs[0];
    if (!chosen) {
      handlers.onError?.("لا يتوفر صوت عربي على هذا الجهاز.");
      return () => {};
    }
    let cancelled = false;
    synth.cancel();
    const run = (i: number) => {
      if (cancelled) return;
      const seg = segments[i];
      if (!seg) {
        handlers.onEnd?.();
        return;
      }
      handlers.onSegment?.(i);
      const u = new SpeechSynthesisUtterance(seg.text);
      u.voice = chosen.voice;
      u.lang = chosen.voice.lang;
      u.rate = this.rate;
      u.onend = () => run(i + 1);
      u.onerror = (e) => {
        if (cancelled || (e as SpeechSynthesisErrorEvent).error === "canceled" || (e as SpeechSynthesisErrorEvent).error === "interrupted") return;
        handlers.onError?.("تعذّر تشغيل الصوت.");
      };
      synth.speak(u);
    };
    run(from);
    return () => {
      cancelled = true;
      synth.cancel();
    };
  }
}

const providers: SpeechProvider[] = [];
export function registerSpeechProvider(p: SpeechProvider) {
  providers.unshift(p);
}
export function getSpeechProviders(fallback: SpeechProvider): SpeechProvider[] {
  return [...providers, fallback];
}

export type NarrationState = "idle" | "playing" | "paused";

/** مشغّل الشرح: تشغيل وإيقاف مؤقت واستئناف وإعادة، مع تتبّع القطعة الحالية للمزامنة مع النص المكتوب. */
export class NarrationController {
  state: NarrationState = "idle";
  index = 0;
  private stop: (() => void) | null = null;

  constructor(
    private provider: SpeechProvider,
    private segments: NarrationSegment[],
    private notify: (state: NarrationState, index: number, error?: string) => void,
  ) {}

  private start(from: number) {
    this.stop?.();
    this.index = from;
    this.state = "playing";
    this.notify(this.state, this.index);
    this.stop = this.provider.speak(this.segments, from, {
      onSegment: (i) => {
        this.index = i;
        this.notify("playing", i);
      },
      onEnd: () => {
        this.state = "idle";
        this.index = 0;
        this.notify("idle", 0);
      },
      onError: (m) => {
        this.state = "idle";
        this.notify("idle", this.index, m);
      },
    });
  }

  play() {
    if (!this.provider.isAvailable()) {
      this.notify("idle", 0, "لا يتوفر صوت عربي على هذا الجهاز، لذلك لا يمكن تشغيل شرح الدرس صوتيًا.");
      return;
    }
    this.start(this.state === "paused" ? this.index : 0);
  }
  pause() {
    if (this.state !== "playing") return;
    this.stop?.();
    this.stop = null;
    this.state = "paused";
    this.notify("paused", this.index);
  }
  restart() {
    this.start(0);
  }
  dispose() {
    this.stop?.();
    this.stop = null;
    this.state = "idle";
  }
}
