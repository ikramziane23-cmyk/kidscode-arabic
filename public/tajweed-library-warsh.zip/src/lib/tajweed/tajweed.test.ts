import { describe, expect, it, beforeEach } from "vitest";
import { readFileSync } from "node:fs";
import type { Surah } from "@/lib/ayah-game";
import { CATEGORIES, LESSONS, lessonById } from "./lessons";
import { allRawExamples, groupsOf, rawExamples, resolveExample } from "./examples";
import { buildQuiz } from "./quiz";
import { arabicVoices, chunkText, NarrationController, type NarrationSegment, type SpeechProvider } from "./speech";
import { ayahAudioUrl, DEFAULT_RECITER, RECITERS, UNAVAILABLE_RECITERS } from "./audio";
import { completionPercent, loadProgress, markVisited, recordQuiz } from "./progress";

const surahs = JSON.parse(readFileSync("public/data/warsh-ayat.json", "utf8")) as Surah[];

function seeded(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 2 ** 32;
  };
}
const NO_EXAMPLES_OK = new Set(["sifat-overview"]);
const wordsOf = (s: number, a: number) => (surahs[s - 1]!.ayat[a - 1] as string).split(" ");
const L = (w: string) => w.match(/[ء-يٱ-ۓ]/)?.[0] ?? "";
const endMarks = (w: string) => w.match(/[ء-يٱ-ۓ]([ً-ٰٟ۝-ۭ]*)$/)?.[1] ?? "";

describe("بيانات الدروس", () => {
  it("المعرّفات فريدة والأقسام موجودة", () => {
    expect(new Set(LESSONS.map((l) => l.id)).size).toBe(LESSONS.length);
    const cats = new Set(CATEGORIES.map((c) => c.id));
    for (const l of LESSONS) expect(cats.has(l.category)).toBe(true);
  });

  it("كل درس فيه تعريف وشرح وتطبيق ومصدر", () => {
    for (const l of LESSONS) {
      expect(l.definition.length).toBeGreaterThan(10);
      expect(l.explanation.length).toBeGreaterThan(0);
      expect(l.how.length).toBeGreaterThan(0);
      expect(l.sources.length).toBeGreaterThan(0);
    }
  });

  it("أسئلة المعرفة: أربعة خيارات مختلفة والجواب ليس بين الخاطئة", () => {
    for (const l of LESSONS) {
      for (const f of l.facts) {
        const all = [f.correct, ...f.wrong];
        expect(new Set(all).size).toBe(4);
      }
      if (!l.pending) expect(l.facts.length).toBeGreaterThan(0);
    }
  });

  it("الدرس المعلّق (الميم قبل الباء) بلا أمثلة ولا أسئلة", () => {
    const l = lessonById("meem-ikhfa")!;
    expect(l.pending).toBe(true);
    expect(l.facts).toHaveLength(0);
    expect(buildQuiz(l, surahs)).toHaveLength(0);
  });

  it("لكل درس أمثلة، أو هو في قائمة الاستثناء الصريحة", () => {
    for (const l of LESSONS) {
      if (l.pending || NO_EXAMPLES_OK.has(l.id)) continue;
      for (const g of groupsOf(l)) expect(rawExamples(g.key).length).toBeGreaterThan(0);
    }
  });
});

describe("الأمثلة القرآنية مطابقة لنص ورش", () => {
  it("كل مثال يطابق كلمته المخزّنة في نص ورش", () => {
    let n = 0;
    for (const l of LESSONS) {
      for (const e of allRawExamples(l)) {
        n++;
        expect(resolveExample(surahs, e)).toBeTruthy();
      }
    }
    expect(n).toBeGreaterThan(150);
  });

  it("مثال محرَّف لا يُقبل", () => {
    const e = { ...rawExamples("noon-iqlab")[0]!, w: "كلمة مخترعة" };
    expect(resolveExample(surahs, e)).toBeNull();
  });
});

describe("تحقق مستقل من انطباق الحكم على الأمثلة", () => {
  const A = (e: { s: number; a: number; i: number }) => wordsOf(e.s, e.a)[e.i]!;
  const B = (e: { s: number; a: number; i: number }) => wordsOf(e.s, e.a)[e.i + 1]!;

  it("النون والتنوين: الحرف التالي من مجموعة الحكم", () => {
    const sets: Record<string, string> = {
      "noon-idhar": "هعحغخ",
      "noon-idgham-ghunna": "ينمو",
      "noon-idgham-bila": "لر",
      "noon-ikhfa": "تثجدذزسشصضطظفقك",
      "noon-iqlab": "ب",
    };
    for (const [id, set] of Object.entries(sets)) {
      for (const e of rawExamples(id)) {
        expect(set.includes(L(B(e)))).toBe(true);
        const mk = endMarks(A(e));
        const hasNoonOrTanween = /[ًٌٍٖٞٗۢ]/.test(mk) || (A(e).replace(/[^ء-يٱ-ۓ]/g, "").endsWith("ن") && /^(ْ)?$/.test(mk));
        expect(hasNoonOrTanween).toBe(true);
        expect(mk.includes("ۢ")).toBe(id === "noon-iqlab");
      }
    }
  });

  it("الميم الساكنة: إدغام قبل الميم، وإظهار لغير الباء والميم، وصلة الميم قبل الهمزة", () => {
    for (const e of rawExamples("meem-idgham")) {
      expect(A(e).replace(/[^ء-يٱ-ۓ]/g, "").endsWith("م")).toBe(true);
      expect(L(B(e))).toBe("م");
    }
    for (const e of rawExamples("meem-idhar")) {
      expect("بم".includes(L(B(e)))).toBe(false);
      expect("أإء".includes(B(e)[0]!)).toBe(false);
    }
    for (const e of rawExamples("madd-silat-meem")) {
      expect(A(e)).toMatch(/مُۥٓ$/);
      expect("أإء".includes(B(e)[0]!)).toBe(true);
    }
  });

  it("القلقلة: صغرى بحرف ساكن وسط الكلمة، وكبرى بحرف في آخر الآية", () => {
    for (const e of rawExamples("qalqala-sughra")) expect(A(e).replace(/[ۖ-ۜ]/g, "")).toMatch(/[قطبجد]ْ[ء-ي]/);
    for (const e of rawExamples("qalqala-kubra")) {
      expect(e.i).toBe(wordsOf(e.s, e.a).length - 1);
      expect("قطبجد".includes(A(e).replace(/[^ء-يٱ-ۓ]/g, "").slice(-1))).toBe(true);
    }
  });

  it("المدود: متصل (مد+همز في كلمة)، منفصل (مد آخر الكلمة+همز أول التالية)، لازم (مد+شدة)", () => {
    for (const e of rawExamples("madd-muttasil")) expect(A(e)).toMatch(/[اويى][ً-ٰٟ]*ٓ[ً-ٰٟ]*[أإؤئء]|لَٰٓئ/);
    for (const e of rawExamples("madd-munfasil")) {
      expect(A(e)).toMatch(/[اويىے][ً-ٰٟ]*ٓ[ً-ٰٟۖ-ۜ]*(ا[ً-ٰٟ]*)?$/);
      expect("أإء".includes(B(e)[0]!)).toBe(true);
    }
    for (const e of rawExamples("madd-lazim")) expect(A(e)).toMatch(/ٓ.?ّ/);
    for (const e of rawExamples("madd-leen")) expect(A(e).replace(/[ۖ-ۜ]/g, "")).toMatch(/َ[ويے]ْ[ءأئؤ]/);
  });

  it("صلة هاء الضمير: كبرى قبل همزة قطع، وصغرى قبل غير الهمز", () => {
    for (const e of rawExamples("madd-silat-kubra")) {
      expect(A(e)).toMatch(/هُۥٓ$|هِۦٓ$/);
      expect("أإء".includes(B(e)[0]!)).toBe(true);
    }
    for (const e of rawExamples("madd-silat-sughra")) {
      expect(A(e)).toMatch(/هُۥ$|هِۦ$/);
      expect("أإءاٱ".includes(B(e)[0]!)).toBe(false);
    }
  });

  it("لام لفظ الجلالة: ترقيق بعد كسرة، وتفخيم بعد فتح/ضم", () => {
    for (const e of rawExamples("lam-jalala-tarqiq")) expect(endMarks(A(e))).toContain("ِ");
    for (const e of rawExamples("lam-jalala-tafkhim")) expect(/[َُ]/.test(endMarks(A(e)))).toBe(true);
    for (const e of [...rawExamples("lam-jalala-tafkhim"), ...rawExamples("lam-jalala-tarqiq")]) {
      expect(B(e).replace(/[^ء-يٱ-ۓ]/g, "")).toBe("الله");
    }
  });

  it("تفخيم الراء وترقيقها: الترقيق بعد كسرة أو ياء ساكنة، والتفخيم بعد فتح/ضم، ولا حرف استعلاء في الكلمة", () => {
    for (const e of rawExamples("ra-tarqiq")) {
      expect(A(e)).toMatch(/(ِ[ّ]?|[يے]ْ)ر[َُ]/);
      expect(A(e)).not.toMatch(/[خصضغطقظ]/);
    }
    for (const e of rawExamples("ra-tafkhim")) {
      expect(A(e)).toMatch(/[َُ][ء-ي]ر[َُ]/);
      expect(A(e)).not.toMatch(/ِ/);
    }
  });

  it("حروف الاستعلاء في أمثلتها", () => {
    for (const e of rawExamples("tafkhim-letters")) expect("خصضغطقظ".includes(e.letter!)).toBe(true);
    for (const e of rawExamples("tarqiq-letters")) expect("خصضغطقظ".includes(e.letter!)).toBe(false);
  });
});

describe("الاختبارات", () => {
  it("كل اختبار: أربعة خيارات مختلفة، فهرس جواب صالح، وجواب صحيح بناءً على الدرس", () => {
    for (const l of LESSONS) {
      for (let seed = 1; seed <= 12; seed++) {
        const qs = buildQuiz(l, surahs, seeded(seed));
        if (l.pending) {
          expect(qs).toHaveLength(0);
          continue;
        }
        expect(qs.length).toBeGreaterThan(0);
        expect(qs.length).toBeLessThanOrEqual(8);
        for (const q of qs) {
          expect(q.options).toHaveLength(4);
          expect(new Set(q.options).size).toBe(4);
          expect(q.answer).toBeGreaterThan(-1);
          expect(q.answer).toBeLessThanOrEqual(3);
          expect(q.explanation.length).toBeGreaterThan(3);
          if (q.kind === "recognize") {
            expect(q.options[q.answer]).toBe(l.label);
            expect(q.options.filter((o) => o === l.label)).toHaveLength(1);
          }
          if (q.kind === "locate") {
            const v = q.verse!;
            expect(v.words).toContain(q.options[q.answer]);
          }
          expect(JSON.stringify(q)).not.toMatch(/\{\{|undefined|NaN/);
        }
      }
    }
  });

  it("سؤال «أين الحكم؟» يُبنى فقط على المواضع الفريدة في الآية", () => {
    const seen = new Set<string>();
    for (const l of LESSONS) {
      for (let seed = 1; seed <= 12; seed++) {
        for (const q of buildQuiz(l, surahs, seeded(seed))) {
          if (q.kind !== "locate") continue;
          seen.add(l.id);
          const m = q.id.match(/:loc:(\d+):(\d+):(\d+):/)!;
          const raw = rawExamples(l.id).find((e) => e.s === +m[1]! && e.a === +m[2]! && e.i === +m[3]!);
          expect(raw?.u).toBe(true);
        }
      }
    }
    expect(seen.size).toBeGreaterThan(5);
  });
});

describe("شرح الدرس الصوتي", () => {
  it("chunkText يقسّم النص الطويل دون فقد كلمات", () => {
    const t = "هذه جملة أولى طويلة نوعًا ما. وهذه جملة ثانية، وفيها فاصلة؛ وفيها فاصلة منقوطة. وجملة ثالثة قصيرة؟ نعم!";
    const parts = chunkText(t, 40);
    expect(parts.length).toBeGreaterThan(1);
    expect(parts.join(" ").replace(/\s+/g, " ")).toBe(t);
  });

  it("اكتشاف الأصوات العربية فقط", () => {
    const mk = (name: string, lang: string) => ({ name, lang, voiceURI: name }) as SpeechSynthesisVoice;
    const v = arabicVoices([mk("Google US English", "en-US"), mk("Microsoft Hoda", "ar-EG"), mk("Maged", "ar-SA")]);
    expect(v).toHaveLength(2);
    expect(v[0]!.voice.name).toBe("Microsoft Hoda");
    expect(v[0]!.likelyFemale).toBe(true);
    expect(v[1]!.likelyFemale).toBe(false);
  });

  function fakeProvider(available: boolean) {
    const log: string[] = [];
    let stopped = 0;
    const p: SpeechProvider = {
      id: "fake",
      name: "fake",
      isAvailable: () => available,
      speak(segments: NarrationSegment[], from, h) {
        log.push(`speak@${from}`);
        h.onSegment?.(from);
        return () => {
          stopped++;
        };
      },
    };
    return { p, log, stopped: () => stopped };
  }
  const segs: NarrationSegment[] = [
    { id: "a#0", text: "أ" },
    { id: "b#0", text: "ب" },
  ];

  it("تشغيل ثم إيقاف مؤقت ثم متابعة من القطعة نفسها ثم إعادة", () => {
    const { p, log } = fakeProvider(true);
    const events: string[] = [];
    const c = new NarrationController(p, segs, (st, i) => events.push(`${st}:${i}`));
    c.play();
    expect(c.state).toBe("playing");
    c.index = 1;
    c.pause();
    expect(c.state).toBe("paused");
    c.play();
    expect(log).toEqual(["speak@0", "speak@1"]);
    c.restart();
    expect(log[2]).toBe("speak@0");
    c.dispose();
    expect(c.state).toBe("idle");
  });

  it("بلا صوت عربي: لا يبدأ التشغيل ويظهر خطأ صريح", () => {
    const { p, log } = fakeProvider(false);
    let err: string | undefined;
    const c = new NarrationController(p, segs, (_s, _i, e) => (err = e));
    c.play();
    expect(log).toHaveLength(0);
    expect(err).toMatch(/لا يتوفر صوت عربي/);
  });
});

describe("التسجيلات الصوتية", () => {
  it("المصدر ياسين الجزائري (ورش) فقط، ولا مقرئ آخر في القائمة", () => {
    expect(RECITERS).toHaveLength(1);
    expect(DEFAULT_RECITER.id).toBe("yassin-aljazairi");
    expect(DEFAULT_RECITER.baseUrl).toContain("/warsh/warsh_yassin_al_jazaery");
    expect(RECITERS.some((r) => /husary|hussary|الحصري/i.test(r.name + r.baseUrl))).toBe(false);
    expect(UNAVAILABLE_RECITERS.length).toBeGreaterThan(0);
  });
  it("رابط الآية بصيغة SSSAAA.mp3 ويرفض القيم غير الصالحة", () => {
    expect(ayahAudioUrl(2, 255)).toBe(`${DEFAULT_RECITER.baseUrl}/002255.mp3`);
    expect(ayahAudioUrl(114, 6)).toBe(`${DEFAULT_RECITER.baseUrl}/114006.mp3`);
    expect(ayahAudioUrl(0, 1)).toBeNull();
    expect(ayahAudioUrl(115, 1)).toBeNull();
    expect(ayahAudioUrl(2, 0)).toBeNull();
  });
  it("كل أمثلة الدروس لها آية صالحة ضمن عدّ ورش", () => {
    for (const l of LESSONS) {
      for (const e of allRawExamples(l)) {
        expect(e.a).toBeLessThanOrEqual(surahs[e.s - 1]!.ayat.length);
        expect(ayahAudioUrl(e.s, e.a)).toBeTruthy();
      }
    }
  });
});

describe("حفظ التقدم", () => {
  beforeEach(() => window.localStorage.clear());
  it("يسجّل الزيارة وأفضل نتيجة ويحسب نسبة الإنجاز", () => {
    expect(completionPercent(loadProgress())).toBe(0);
    markVisited("noon-idhar");
    recordQuiz("noon-idhar", 5, 8, 0.7);
    expect(loadProgress()["noon-idhar"]?.passed).toBe(false);
    recordQuiz("noon-idhar", 7, 8, 0.7);
    recordQuiz("noon-idhar", 2, 8, 0.7);
    const p = loadProgress()["noon-idhar"]!;
    expect(p.passed).toBe(true);
    expect(p.score).toBe(7);
    const active = LESSONS.filter((l) => !l.pending).length;
    expect(completionPercent(loadProgress())).toBe(Math.round((1 / active) * 100));
  });
  it("تالف التخزين لا يكسر الصفحة", () => {
    window.localStorage.setItem("tajweed-library-progress-v1", "{not json");
    expect(loadProgress()).toEqual({});
  });
});
