export type CategoryId = "noon" | "meem" | "qalqala" | "tafkhim" | "ra-lam" | "madd" | "makharij";

export interface Category {
  id: CategoryId;
  title: string;
  blurb: string;
  emoji: string;
  /** لون البطاقة (فئات Tailwind ثابتة كي لا تُحذف عند البناء) */
  tone: string;
}

/** سؤال معرفي مكتوب بحيث تكون الإجابة الأولى هي الصحيحة (تُخلط وقت العرض) */
export interface QuizFact {
  q: string;
  correct: string;
  wrong: [string, string, string];
  why: string;
}

export interface ExampleGroup {
  /** مفتاح داخل tajweed-examples.json */
  key: string;
  title: string;
  note?: string;
}

export interface Lesson {
  id: string;
  category: CategoryId;
  /** اسم الحكم كما يظهر في العنوان */
  title: string;
  /** صيغة قصيرة تُستعمل كخيار في الاختبار (اسم الحكم) */
  label: string;
  definition: string;
  explanation: string[];
  /** حروف الحكم (مفصولة بمسافات) إن وُجدت */
  letters?: string;
  how: string[];
  /** مجموعات الأمثلة؛ افتراضيًا مجموعة واحدة بمفتاح id الدرس */
  groups?: ExampleGroup[];
  /** يظهر شريطًا تنبيهيًا: الدرس يحتاج مراجعة مقرئة مجازة برواية ورش */
  review?: string;
  /** يُمنع عرض أمثلة/اختبار حتى يُعتمد الحكم */
  pending?: boolean;
  facts: QuizFact[];
  /** هل الحكم خاص برواية ورش (للشارة) */
  warshSpecific?: boolean;
  sources: string[];
}

export interface RawExample {
  s: number;
  a: number;
  i: number;
  n: number;
  w: string;
  letter?: string;
}

export interface ResolvedExample extends RawExample {
  surahName: string;
  words: string[];
}
