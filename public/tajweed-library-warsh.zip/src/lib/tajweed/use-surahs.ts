import { useEffect, useState } from "react";
import { loadSurahs, type Surah } from "@/lib/ayah-game";

export function useSurahs() {
  const [state, setState] = useState<{ data: Surah[] | null; error: boolean }>({ data: null, error: false });
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let alive = true;
    setState({ data: null, error: false });
    loadSurahs().then(
      (data) => alive && setState({ data, error: false }),
      () => alive && setState({ data: null, error: true }),
    );
    return () => {
      alive = false;
    };
  }, [attempt]);
  return { ...state, retry: () => setAttempt((a) => a + 1) };
}
