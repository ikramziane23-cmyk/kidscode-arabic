import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { LessonBoard } from "@/components/tajweed/lesson-board";
import { LessonQuiz } from "@/components/tajweed/lesson-quiz";
import { TAJWEED_FONT_CSS } from "@/components/tajweed/quran-words";
import { VoiceExplainer } from "@/components/tajweed/voice-explainer";
import { LESSONS, SOURCES, lessonById } from "@/lib/tajweed/lessons";
import { markVisited, recordQuiz } from "@/lib/tajweed/progress";
import { PASS_RATIO } from "@/lib/tajweed/quiz";
import { narrationFor } from "@/lib/tajweed/speech";
import { useSurahs } from "@/lib/tajweed/use-surahs";

export const Route = createFileRoute("/tajweed/$lessonId")({
  loader: ({ params }) => {
    const lesson = lessonById(params.lessonId);
    if (!lesson) throw notFound();
    return { lessonId: lesson.id };
  },
  head: ({ params }) => {
    const l = lessonById(params.lessonId);
    return {
      meta: [
        { title: `${l?.title ?? "درس"} — مكتبة التجويد (ورش)` },
        { name: "description", content: l?.definition ?? "درس تجويد برواية ورش" },
      ],
    };
  },
  notFoundComponent: () => (
    <div dir="rtl" className="p-10 text-center">
      <p className="text-lg font-bold">هذا الدرس غير موجود.</p>
      <Link to="/tajweed/" className="mt-4 inline-block rounded-full bg-rose-500 px-6 py-2 font-bold text-white">
        العودة إلى المكتبة
      </Link>
    </div>
  ),
  component: LessonPage,
});

function LessonPage() {
  const { lessonId } = Route.useParams();
  const lesson = lessonById(lessonId)!;
  const { data, error, retry } = useSurahs();
  const [active, setActive] = useState<string | null>(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [savedNote, setSavedNote] = useState<string | null>(null);

  const idx = LESSONS.findIndex((l) => l.id === lesson.id);
  const prev = LESSONS[idx - 1];
  const next = LESSONS[idx + 1];

  useEffect(() => {
    markVisited(lesson.id);
    setShowQuiz(false);
    setSavedNote(null);
  }, [lesson.id]);

  const parts = useMemo(
    () => [
      { id: "def", text: `${lesson.title}. ${lesson.definition}` },
      ...lesson.explanation.map((t, i) => ({ id: `exp${i}`, text: t })),
      ...(lesson.letters ? [{ id: "letters", text: `حروف هذا الحكم: ${lesson.letters.replace(/\+/g, " ثم ").replace(/\|/g, ". ")}` }] : []),
      ...lesson.how.map((t, i) => ({ id: `how${i}`, text: t })),
    ],
    [lesson],
  );
  const segments = useMemo(() => narrationFor(parts), [parts]);
  const activePart = active ? active.split("#")[0] : null;
  const hi = (id: string) => (activePart === id ? "rounded-xl bg-amber-100 ring-2 ring-amber-300" : "");

  return (
    <div dir="rtl" className="min-h-screen bg-[#fff8ee] font-body text-foreground">
      <style dangerouslySetInnerHTML={{ __html: TAJWEED_FONT_CSS }} />
      <div className="mx-auto max-w-3xl px-4 py-6">
        <Link to="/tajweed/" className="inline-flex items-center gap-1 text-sm font-bold text-rose-600">
          <ArrowRight className="size-4" /> مكتبة التجويد
        </Link>

        <h1 className="mt-3 font-display text-3xl font-bold text-rose-700">{lesson.title}</h1>
        <div className="mt-1 flex flex-wrap gap-2 text-xs font-bold">
          <span className="rounded-full bg-emerald-100 px-3 py-1 text-emerald-800">رواية ورش عن نافع</span>
          {lesson.warshSpecific && <span className="rounded-full bg-emerald-600 px-3 py-1 text-white">حكم خاص بورش</span>}
        </div>

        {lesson.review && (
          <div role="note" className="mt-4 flex gap-2 rounded-2xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
            <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden />
            <p>
              <b>يحتاج مراجعة:</b> {lesson.review}
            </p>
          </div>
        )}

        <div className="mt-4">
          <VoiceExplainer segments={segments} onActive={setActive} />
        </div>

        <article className="mt-5 space-y-4 rounded-3xl border border-rose-100 bg-white p-5 shadow-sm">
          <section className={`p-2 ${hi("def")}`}>
            <h2 className="text-lg font-bold text-emerald-800">١. التعريف المبسّط</h2>
            <p className="mt-1 text-lg leading-8">{lesson.definition}</p>
          </section>
          <section>
            <h2 className="text-lg font-bold text-emerald-800">٢. الشرح</h2>
            {lesson.explanation.map((t, i) => (
              <p key={i} className={`mt-2 p-2 leading-8 ${hi(`exp${i}`)}`}>
                {t}
              </p>
            ))}
          </section>
          {lesson.letters && (
            <section className={`p-2 ${hi("letters")}`}>
              <h2 className="text-lg font-bold text-emerald-800">٣. حروف الحكم</h2>
              <p className="mt-1 rounded-2xl bg-amber-50 p-3 text-center text-2xl font-bold tracking-widest" data-testid="letters">
                {lesson.letters}
              </p>
            </section>
          )}
          <section>
            <h2 className="text-lg font-bold text-emerald-800">{lesson.letters ? "٤" : "٣"}. كيف نطبّقه؟</h2>
            <ol className="mt-1 list-decimal space-y-1 pe-6">
              {lesson.how.map((t, i) => (
                <li key={i} className={`p-1 ${hi(`how${i}`)}`}>
                  {t}
                </li>
              ))}
            </ol>
          </section>
        </article>

        {lesson.pending ? null : (
          <section className="mt-6">
            <h2 className="mb-2 text-lg font-bold text-emerald-800">السبورة والأمثلة القرآنية (ورش)</h2>
            {error ? (
              <div className="rounded-2xl bg-red-50 p-4 text-center">
                <p className="font-bold text-red-700">تعذّر تحميل نص المصحف.</p>
                <button type="button" onClick={retry} className="mt-2 rounded-full bg-rose-500 px-5 py-2 font-bold text-white">
                  إعادة المحاولة
                </button>
              </div>
            ) : !data ? (
              <p className="py-8 text-center font-bold text-muted-foreground">جارٍ تحميل المصحف…</p>
            ) : (
              <LessonBoard lesson={lesson} surahs={data} />
            )}
          </section>
        )}

        {!lesson.pending && data && (
          <section className="mt-6">
            <h2 className="mb-2 text-lg font-bold text-emerald-800">اختبار قصير</h2>
            {showQuiz ? (
              <LessonQuiz
                lesson={lesson}
                surahs={data}
                onFinished={(score, total) => {
                  recordQuiz(lesson.id, score, total, PASS_RATIO);
                  setSavedNote(score / total >= PASS_RATIO ? "تم حفظ إنجازك لهذا الدرس." : "حاولي مرة أخرى للوصول إلى ٧٠٪ فأكثر.");
                }}
              />
            ) : (
              <button type="button" onClick={() => setShowQuiz(true)} className="w-full rounded-3xl bg-emerald-600 py-4 text-lg font-bold text-white shadow">
                ابدئي الاختبار
              </button>
            )}
            {savedNote && <p className="mt-2 text-center text-sm font-bold text-emerald-800">{savedNote}</p>}
          </section>
        )}

        <footer className="mt-8 rounded-2xl border border-amber-200 bg-white/70 p-4 text-sm">
          <h2 className="font-bold">المصادر</h2>
          <ul className="mt-1 list-disc space-y-0.5 pe-5 text-muted-foreground">
            {lesson.sources.map((s) => (
              <li key={s}>{SOURCES[s]?.title ?? s}</li>
            ))}
          </ul>
        </footer>

        <nav className="mt-6 flex justify-between gap-2">
          {prev ? (
            <Link to="/tajweed/$lessonId" params={{ lessonId: prev.id }} className="inline-flex items-center gap-1 rounded-full bg-white px-4 py-2 text-sm font-bold shadow">
              <ChevronRight className="size-4" /> {prev.title}
            </Link>
          ) : (
            <span />
          )}
          {next ? (
            <Link to="/tajweed/$lessonId" params={{ lessonId: next.id }} className="inline-flex items-center gap-1 rounded-full bg-white px-4 py-2 text-sm font-bold shadow">
              {next.title} <ChevronLeft className="size-4" />
            </Link>
          ) : (
            <span />
          )}
        </nav>
      </div>
    </div>
  );
}
