import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, BookOpenCheck, Check, Sparkles } from "lucide-react";
import { CATEGORIES, LESSONS, lessonsOf } from "@/lib/tajweed/lessons";
import { completionPercent, loadProgress, resetProgress, type ProgressMap } from "@/lib/tajweed/progress";

export const Route = createFileRoute("/tajweed/")({
  head: () => ({
    meta: [
      { title: "مكتبة التجويد — رواية ورش عن نافع" },
      { name: "description", content: "دروس تجويد برواية ورش عن نافع مع أمثلة قرآنية ملوّنة وشرح صوتي واختبارات قصيرة." },
      { property: "og:title", content: "مكتبة التجويد — رواية ورش عن نافع" },
      { property: "og:type", content: "website" },
    ],
  }),
  component: TajweedLibrary,
});

function TajweedLibrary() {
  const [progress, setProgress] = useState<ProgressMap>({});
  useEffect(() => setProgress(loadProgress()), []);
  const percent = completionPercent(progress);
  const total = LESSONS.filter((l) => !l.pending).length;
  const passed = LESSONS.filter((l) => progress[l.id]?.passed).length;

  return (
    <div dir="rtl" className="min-h-screen bg-[#fff8ee] font-body text-foreground">
      <header className="mx-auto max-w-5xl px-4 pt-6">
        <Link to="/" className="inline-flex items-center gap-1 text-sm font-bold text-rose-600">
          <ArrowRight className="size-4" /> الرئيسية
        </Link>
        <div className="mt-3 rounded-[2rem] border-2 border-amber-200 bg-gradient-to-br from-rose-50 via-[#fff8ee] to-emerald-50 p-6 text-center shadow">
          <p className="text-4xl" aria-hidden>
            🕌
          </p>
          <h1 className="mt-1 font-display text-3xl font-bold text-rose-700 md:text-4xl">مكتبة التجويد</h1>
          <p className="mt-1 text-lg font-bold text-emerald-800">رواية ورش عن نافع</p>
          <p className="mx-auto mt-2 max-w-xl text-sm text-muted-foreground">
            تعلّمي أحكام التجويد درسًا درسًا: شرح مبسّط، أمثلة من المصحف بخط ورش مع تلوين موضع الحكم، شرح صوتي، واختبار قصير.
          </p>
          <div className="mx-auto mt-4 max-w-md" aria-label="نسبة إنجاز الدروس">
            <div className="flex justify-between text-sm font-bold">
              <span>
                إنجازك: {passed} من {total} درسًا
              </span>
              <span>{percent}%</span>
            </div>
            <div className="mt-1 h-3 overflow-hidden rounded-full bg-white shadow-inner" role="progressbar" aria-valuenow={percent} aria-valuemin={0} aria-valuemax={100}>
              <div className="h-full rounded-full bg-gradient-to-l from-emerald-400 to-amber-300" style={{ width: `${percent}%` }} />
            </div>
            <p className="mt-1 text-xs text-muted-foreground">يُحسب الدرس منجزًا عند اجتياز اختباره بنسبة ٧٠٪ فأكثر.</p>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-8 px-4 py-8">
        {CATEGORIES.map((c) => (
          <section key={c.id} aria-labelledby={`cat-${c.id}`}>
            <h2 id={`cat-${c.id}`} className="flex items-center gap-2 text-xl font-bold">
              <span aria-hidden>{c.emoji}</span> {c.title}
            </h2>
            <p className="mb-3 text-sm text-muted-foreground">{c.blurb}</p>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {lessonsOf(c.id).map((l) => {
                const p = progress[l.id];
                return (
                  <Link key={l.id} to="/tajweed/$lessonId" params={{ lessonId: l.id }} className={`block rounded-3xl border-2 p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${c.tone}`}>
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-lg font-bold">{l.title}</h3>
                      {p?.passed && <Check className="size-5 shrink-0 text-emerald-600" aria-label="منجز" />}
                    </div>
                    <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{l.definition}</p>
                    <div className="mt-2 flex flex-wrap gap-1 text-xs font-bold">
                      {l.warshSpecific && <span className="rounded-full bg-emerald-600 px-2 py-0.5 text-white">خاص بورش</span>}
                      {l.pending && <span className="rounded-full bg-amber-500 px-2 py-0.5 text-white">قيد المراجعة</span>}
                      {l.review && !l.pending && <span className="rounded-full bg-amber-100 px-2 py-0.5 text-amber-900">يحتاج مراجعة مقرئة</span>}
                      {p?.score !== undefined && p.total ? <span className="rounded-full bg-white px-2 py-0.5">أفضل نتيجة {p.score}/{p.total}</span> : null}
                    </div>
                  </Link>
                );
              })}
            </div>
          </section>
        ))}
        <footer className="rounded-2xl border border-amber-200 bg-white/70 p-4 text-sm">
          <p className="flex items-center gap-2 font-bold">
            <BookOpenCheck className="size-4 text-emerald-700" /> ملاحظة علمية
          </p>
          <p className="mt-1 text-muted-foreground">
            النص القرآني من مصحف مجمع الملك فهد برواية ورش، والأحكام الخاصة بها مأخوذة من مصادر أداء ورش (طريق الأزرق). الدروس الموسومة «يحتاج مراجعة» تُعرض بتحفّظ، وننصح بمراجعتها مع مقرئة مجازة برواية ورش.
          </p>
          <button type="button" onClick={() => { resetProgress(); setProgress({}); }} className="mt-3 inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs font-bold">
            <Sparkles className="size-3" /> مسح التقدّم المحفوظ
          </button>
        </footer>
      </main>
    </div>
  );
}
